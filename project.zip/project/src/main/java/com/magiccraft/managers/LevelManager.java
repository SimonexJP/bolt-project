package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.api.events.PlayerGainXPEvent;
import com.magiccraft.api.events.PlayerLevelUpEvent;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.factions.Faction;
import com.magiccraft.factions.FactionManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Handles XP addition, level-up detection, and the level-up celebration
 * (sound, particles, title, broadcast, unlocks).
 */
public class LevelManager {

    private final MagicPlugin plugin;

    public LevelManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public YamlConfig config() { return plugin.getConfigManager().main(); }

    public int maxLevel() { return config().get().getInt("leveling.max-level", 100); }
    public int baseXp() { return config().get().getInt("leveling.base-xp", 100); }
    public double growth() { return config().get().getDouble("leveling.growth-factor", 1.12); }

    /** XP required to advance FROM the given level TO the next level. */
    public int xpForLevel(int level) {
        return (int) Math.floor(baseXp() * Math.pow(growth(), Math.max(0, level - 1)));
    }

    public void addXp(@NotNull Player player, int amount, @NotNull String source) {
        if (amount <= 0) return;
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();

        PlayerGainXPEvent gainEvent = new PlayerGainXPEvent(player, amount, source);
        Bukkit.getPluginManager().callEvent(gainEvent);
        if (gainEvent.isCancelled()) return;
        amount = gainEvent.getAmount();

        data.setXp(data.getXp() + amount);
        data.getStatistics().addXp(amount);

        // Level up loop in case multiple levels are gained at once.
        while (data.getLevel() < maxLevel() && data.getXp() >= xpForLevel(data.getLevel())) {
            data.setXp(data.getXp() - xpForLevel(data.getLevel()));
            int oldLevel = data.getLevel();
            data.setLevel(oldLevel + 1);
            int newMax = plugin.getManaManager().maxManaForLevel(data.getLevel());
            data.setMaxMana(newMax);
            data.setMana(data.getMana() + (newMax - plugin.getManaManager().maxManaForLevel(oldLevel)));
            onLevelUp(player, data, oldLevel, data.getLevel());
        }

        if (data.getLevel() >= maxLevel()) {
            data.setLevel(maxLevel());
            data.setXp(0);
        }
    }

    public void setLevel(@NotNull Player player, int level) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        int old = data.getLevel();
        level = Math.max(1, Math.min(maxLevel(), level));
        data.setLevel(level);
        data.setXp(0);
        data.setMaxMana(plugin.getManaManager().maxManaForLevel(level));
        if (level > old) {
            onLevelUp(player, data, old, level);
        }
        refreshUnlocks(player.getUniqueId(), data);
    }

    public void refreshUnlocks(@NotNull UUID uuid, @NotNull PlayerData data) {
        if (data.getFaction() == null) return;
        plugin.getFactionManager().get(data.getFaction()).ifPresent(faction -> {
            for (String spellId : plugin.getFactionManager().unlockedSpellsUpTo(data.getFaction(), data.getLevel())) {
                data.unlockSpell(spellId);
            }
        });
    }

    private void onLevelUp(@NotNull Player player, @NotNull PlayerData data, int oldLevel, int newLevel) {
        Bukkit.getPluginManager().callEvent(new PlayerLevelUpEvent(player, oldLevel, newLevel, data));

        String rank = Rank.fromLevel(newLevel).getDisplayName();
        player.sendTitle(
                plugin.getMessages().raw("level-up-title"),
                plugin.getMessages().raw("level-up-subtitle", newLevel, rank),
                10, 60, 20);

        Location loc = player.getLocation();
        player.getWorld().playSound(loc, org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
        player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, loc.clone().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);

        String broadcast = plugin.getMessages().raw("level-up-broadcast", player.getName(), newLevel, rank);
        Bukkit.broadcastMessage(broadcast);

        // Faction-specific sound + unlock notice.
        if (data.getFaction() != null) {
            FactionManager fm = plugin.getFactionManager();
            fm.get(data.getFaction()).ifPresent(f -> f.playSound(loc));
            // Notify newly unlocked spells at this exact level.
            for (String spellId : fm.getSlotSpells(data.getFaction(), newLevel)) {
                if (!spellId.equalsIgnoreCase("none")) {
                    player.sendMessage(plugin.getMessages().get("level-up-locked-spell",
                            plugin.getSpellManager().displayName(spellId)));
                }
            }
        }
    }

    public Rank rank(@NotNull UUID uuid) {
        return Rank.fromLevel(plugin.getPlayerManager().get(uuid)
                .map(mp -> mp.getData().getLevel()).orElse(1));
    }
}
