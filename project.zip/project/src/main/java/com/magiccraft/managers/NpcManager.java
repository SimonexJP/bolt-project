package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Manages magic NPCs: Magic Master, Quest Master, Spell Vendor, Mana Bank
 * and Tutorial NPC. If Citizens is installed, NPCs are spawned via its API;
 * otherwise a fallback message informs the player that Citizens is required.
 */
public class NpcManager {

    private final MagicPlugin plugin;
    private boolean citizensEnabled;

    public static final String MAGIC_MASTER = "magic_master";
    public static final String QUEST_MASTER = "quest_master";
    public static final String SPELL_VENDOR = "spell_vendor";
    public static final String MANA_BANK = "mana_bank";
    public static final String TUTORIAL = "tutorial";

    public NpcManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        citizensEnabled = Bukkit.getPluginManager().getPlugin("Citizens") != null;
        if (!citizensEnabled) {
            plugin.getLogger().info("Citizens not found — NPC features will use fallback mode.");
        }
    }

    public boolean isCitizensEnabled() { return citizensEnabled; }

    /** NPC display names from config. */
    public Map<String, String> npcNames() {
        Map<String, String> names = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("npcs");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                names.put(key, section.getString(key + ".name", key));
            }
        }
        return names;
    }

    /** Handles a player interacting with an NPC by id. */
    public void onInteract(@NotNull Player player, @NotNull String npcId) {
        switch (npcId) {
            case MAGIC_MASTER -> player.sendMessage(plugin.getMessages().get("npc-magic-master"));
            case QUEST_MASTER -> {
                player.sendMessage(plugin.getMessages().get("npc-quest-master"));
                player.performCommand("magic missions");
            }
            case SPELL_VENDOR -> {
                player.sendMessage(plugin.getMessages().get("npc-spell-vendor"));
                player.performCommand("magic shop");
            }
            case MANA_BANK -> {
                player.sendMessage(plugin.getMessages().get("npc-mana-bank"));
                player.performCommand("magic mana");
            }
            case TUTORIAL -> player.sendMessage(plugin.getMessages().get("npc-tutorial"));
        }
    }

    /** Attempts to find an NPC id from a clicked entity (fallback: always empty). */
    public Optional<String> npcIdFromEntity(@Nullable Entity entity) {
        return Optional.empty();
    }

    /** Spawns NPCs at configured locations ( Citizens integration point). */
    public void spawnNpcs() {
        if (!citizensEnabled) return;
        // Citizens API integration would go here
    }
}
