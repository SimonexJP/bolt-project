package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Creates and identifies spell book items. A spell book is a physical item
 * a player right-clicks to learn the contained spell (delegated to
 * {@link SpellBookManager}).
 */
public class SpellBookItemManager {

    public static final String BOOK_KEY = "magic_spellbook_spell";

    private final MagicPlugin plugin;
    private final NamespacedKey spellKey;

    public SpellBookItemManager(MagicPlugin plugin) {
        this.plugin = plugin;
        this.spellKey = new NamespacedKey(plugin, BOOK_KEY);
    }

    public NamespacedKey spellKey() { return spellKey; }

    @NotNull
    public ItemStack createBook(@NotNull String spellId) {
        String display = plugin.getSpellManager().displayName(spellId);
        String desc = plugin.getSpellManager().description(spellId);
        ItemStack item = new ItemStack(Material.BOOK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextUtil.color("&5&lSpell Book: &d" + display));
            List<String> lore = new ArrayList<>();
            lore.add(TextUtil.color("&7Right-click to study and learn this spell."));
            lore.add("");
            lore.add(TextUtil.color("&7Spell: &f" + display));
            if (!desc.isEmpty()) {
                lore.add(TextUtil.color("&8" + desc));
            }
            meta.setLore(lore);
            meta.getPersistentDataContainer().set(spellKey, PersistentDataType.STRING, spellId);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isSpellBook(@Nullable ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(spellKey, PersistentDataType.STRING);
    }

    public @Nullable String spellId(@Nullable ItemStack item) {
        if (!isSpellBook(item)) return null;
        return item.getItemMeta().getPersistentDataContainer().get(spellKey, PersistentDataType.STRING);
    }
}
