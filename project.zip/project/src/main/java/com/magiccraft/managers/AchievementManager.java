package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Tracks persistent achievements. Achievements are earned once and stored
 * in the player's data. Each achievement has configurable criteria checked
 * by game events (mob kills, spell casts, PvP wins, prestige, etc.).
 */
public class AchievementManager {

    private final MagicPlugin plugin;

    public AchievementManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /** Achievement id -> display name from config. */
    public Map<String, String> achievementNames() {
        Map<String, String> names = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("achievements");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                names.put(key, section.getString(key + ".name", key));
            }
        }
        return names;
    }

    public String description(@NotNull String id) {
        return plugin.getConfigManager().main().get().getString("achievements." + id + ".description", "");
    }

    public int xpReward(@NotNull String id) {
        return plugin.getConfigManager().main().get().getInt("achievements." + id + ".xp-reward", 50);
    }

    public int prestigePointReward(@NotNull String id) {
        return plugin.getConfigManager().main().get().getInt("achievements." + id + ".prestige-points", 0);
    }

    /** Attempts to grant an achievement. Returns true if newly earned. */
    public boolean grant(@NotNull Player player, @NotNull String id) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (data.hasAchievement(id)) return false;

        data.earnAchievement(id);
        String name = achievementNames().getOrDefault(id, id);
        player.sendMessage(plugin.getMessages().get("achievement-unlocked", name));
        player.sendTitle(
                plugin.getMessages().raw("achievement-title"),
                plugin.getMessages().raw("achievement-subtitle", name),
                10, 60, 20);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.8f, 1.5f);

        int xp = xpReward(id);
        if (xp > 0) plugin.getLevelManager().addXp(player, xp, "achievement");
        int pp = prestigePointReward(id);
        if (pp > 0) data.addPrestigePoints(pp);
        return true;
    }

    /** Checks stat-based achievements after statistics update. */
    public void checkStatAchievements(@NotNull Player player, @NotNull PlayerData data) {
        var stats = data.getStatistics();
        if (stats.getMobsKilled() >= 100) grant(player, "monster_slayer");
        if (stats.getMobsKilled() >= 500) grant(player, "monster_master");
        if (stats.getSpellsCast() >= 500) grant(player, "spellcaster");
        if (stats.getSpellsCast() >= 2000) grant(player, "archmage");
        if (data.getPrestigeLevel() >= 1) grant(player, "first_prestige");
        if (data.getPrestigeLevel() >= 5) grant(player, "prestige_master");
    }
}
