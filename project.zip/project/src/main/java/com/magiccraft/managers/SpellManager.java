package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.api.events.ManaChangeEvent;
import com.magiccraft.api.events.SpellCastEvent;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.core.enums.CastCombo;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.spells.Spell;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Registry + casting engine for spells. Validates mana, cooldown, unlock
 * status, fires {@link SpellCastEvent}, then delegates to the {@link Spell}.
 */
public class SpellManager {

    private final MagicPlugin plugin;
    private final Map<String, Spell> spells = new HashMap<>();

    public SpellManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(@NotNull Spell spell) {
        spells.put(spell.getId().toLowerCase(), spell);
    }

    public Optional<Spell> get(@Nullable String id) {
        if (id == null) return Optional.empty();
        return Optional.ofNullable(spells.get(id.toLowerCase()));
    }

    public Map<String, Spell> all() { return spells; }

    public int manaCost(@NotNull String spellId) {
        return plugin.getConfigManager().spells().get().getInt("spells." + spellId + ".mana-cost", 10);
    }

    public int cooldownSeconds(@NotNull String spellId) {
        int cd = plugin.getConfigManager().spells().get().getInt("spells." + spellId + ".cooldown-seconds", 5);
        int min = plugin.getConfigManager().cooldowns().get().getInt("cooldowns.global-minimum", 1);
        return Math.max(min, cd);
    }

    public String displayName(@NotNull String spellId) {
        return plugin.getConfigManager().spells().get().getString("spells." + spellId + ".display-name", spellId);
    }

    public String description(@NotNull String spellId) {
        return plugin.getConfigManager().spells().get().getString("spells." + spellId + ".description", "");
    }

    public org.bukkit.Material icon(@NotNull String spellId) {
        String mat = plugin.getConfigManager().spells().get().getString("spells." + spellId + ".material", "STICK");
        try {
            return org.bukkit.Material.valueOf(mat.toUpperCase());
        } catch (IllegalArgumentException e) {
            return org.bukkit.Material.STICK;
        }
    }

    /**
     * Attempts to cast the spell for the given player. Handles all preflight
     * checks (faction, unlock, cooldown, mana) and fires the API event.
     *
     * @return true if the spell was cast successfully
     */
    public boolean cast(@NotNull Player player, @NotNull String spellId, @NotNull CastCombo combo) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (data.getFaction() == null) return false;

        Spell spell = spells.get(spellId.toLowerCase());
        if (spell == null) {
            player.sendMessage(plugin.getMessages().get("spell-not-found"));
            return false;
        }
        if (spell.getFaction() != data.getFaction()) return false;

        if (!data.hasSpell(spellId)) {
            player.sendMessage(plugin.getMessages().get("spell-locked", displayName(spellId), unlockLevel(spellId, data.getFaction())));
            return false;
        }

        if (plugin.getCooldownManager().isOnCooldown(player.getUniqueId(), spellId)) {
            int remaining = plugin.getCooldownManager().remainingSeconds(player.getUniqueId(), spellId);
            player.sendMessage(plugin.getMessages().get("spell-on-cooldown", displayName(spellId), remaining));
            return false;
        }

        int cost = manaCost(spellId);
        if (data.getMana() < cost) {
            player.sendMessage(plugin.getMessages().get("spell-no-mana", cost, data.getMana()));
            return false;
        }

        SpellCastEvent event = new SpellCastEvent(player, spell, combo);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) return false;

        boolean success = spell.cast(player);
        if (!success) return false;

        plugin.getManaManager().consume(player, cost, ManaChangeEvent.Cause.CAST);
        plugin.getCooldownManager().set(player.getUniqueId(), spellId, cooldownSeconds(spellId) * 1000L);
        data.getStatistics().addSpellCast();
        plugin.getLevelManager().addXp(player, plugin.getXPManager().spellCastXp(), "spell_cast");
        return true;
    }

    public int unlockLevel(@NotNull String spellId, @NotNull FactionType faction) {
        var section = plugin.getConfigManager().factions().get().getConfigurationSection("factions." + faction.name() + ".spells");
        if (section == null) return 1;
        for (String key : section.getKeys(false)) {
            String val = section.getString(key);
            if (spellId.equalsIgnoreCase(val)) {
                try { return Integer.parseInt(key); } catch (NumberFormatException ignored) {}
            }
        }
        return 1;
    }
}
