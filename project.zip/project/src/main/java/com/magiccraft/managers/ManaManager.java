package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.api.events.ManaChangeEvent;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.util.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Handles mana values, regeneration, and the action-bar display.
 */
public class ManaManager {

    private final MagicPlugin plugin;

    public ManaManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public YamlConfig config() { return plugin.getConfigManager().mana(); }

    public int baseMaxMana() { return config().get().getInt("mana.base-max-mana", 100); }
    public int manaPerLevel() { return config().get().getInt("mana.mana-per-level", 5); }
    public int maxManaCap() { return config().get().getInt("mana.max-mana-cap", 600); }
    public int regenPerSecond() { return config().get().getInt("mana.regen-per-second", 2); }
    public int regenPeriodTicks() { return config().get().getInt("mana.regen-period-ticks", 20); }
    public boolean stopWhenFull() { return config().get().getBoolean("mana.stop-when-full", false); }

    public int maxManaForLevel(int level) {
        int raw = baseMaxMana() + manaPerLevel() * Math.max(0, level - 1);
        return Math.min(raw, maxManaCap());
    }

    public boolean hasMana(@NotNull UUID uuid, int amount) {
        return plugin.getPlayerManager().get(uuid)
                .map(mp -> mp.getData().getMana() >= amount)
                .orElse(false);
    }

    public boolean consume(@NotNull Player player, int amount, @NotNull ManaChangeEvent.Cause cause) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (data.getMana() < amount) return false;
        int old = data.getMana();
        int next = Math.max(0, old - amount);
        ManaChangeEvent event = new ManaChangeEvent(player, old, next, cause);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) return false;
        data.setMana(event.getNewMana());
        return true;
    }

    public void regen(@NotNull UUID uuid) {
        var mp = plugin.getPlayerManager().get(uuid);
        if (mp.isEmpty()) return;
        PlayerData data = mp.get().getData();
        int max = data.getMaxMana();
        if (stopWhenFull() && data.getMana() >= max) return;
        int old = data.getMana();
        int next = Math.min(max, old + regenPerSecond());
        if (next == old) return;
        Player player = mp.get().getPlayer();
        ManaChangeEvent event = new ManaChangeEvent(player, old, next, ManaChangeEvent.Cause.REGEN);
        Bukkit.getPluginManager().callEvent(event);
        if (!event.isCancelled()) data.setMana(event.getNewMana());
    }

    public void regenAll() {
        for (var mp : plugin.getPlayerManager().all()) {
            regen(mp.getUuid());
        }
    }

    public String actionBar(@NotNull UUID uuid) {
        var mp = plugin.getPlayerManager().get(uuid);
        if (mp.isEmpty()) return "";
        PlayerData d = mp.get().getData();
        return TextUtil.format(
                plugin.getConfigManager().get(ConfigManager.MESSAGES).get().getString("mana-bar", "&bMana: &f{0}&7/&f{1}"),
                "", d.getMana(), d.getMaxMana());
    }
}
