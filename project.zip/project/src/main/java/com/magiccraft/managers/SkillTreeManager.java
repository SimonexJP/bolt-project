package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * GUI-driven skill trees with five branches: Offense, Defense, Mana,
 * Support, and Ultimate. Players spend skill points earned through
 * leveling and prestige to unlock nodes in each branch.
 */
public class SkillTreeManager {

    public static final String OFFENSE = "offense";
    public static final String DEFENSE = "defense";
    public static final String MANA = "mana";
    public static final String SUPPORT = "support";
    public static final String ULTIMATE = "ultimate";

    private final MagicPlugin plugin;

    public SkillTreeManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /** Returns all branches with their node definitions. */
    public Map<String, Map<String, SkillNode>> branches() {
        Map<String, Map<String, SkillNode>> result = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("skill-tree");
        if (section != null) {
            for (String branch : section.getKeys(false)) {
                Map<String, SkillNode> nodes = new LinkedHashMap<>();
                var branchSection = section.getConfigurationSection(branch + ".nodes");
                if (branchSection != null) {
                    for (String nodeId : branchSection.getKeys(false)) {
                        String name = branchSection.getString(nodeId + ".name", nodeId);
                        int cost = branchSection.getInt(nodeId + ".cost", 1);
                        int maxRank = branchSection.getInt(nodeId + ".max-rank", 1);
                        nodes.put(nodeId, new SkillNode(nodeId, branch, name, cost, maxRank));
                    }
                }
                result.put(branch, nodes);
            }
        }
        return result;
    }

    /** Returns the player's current rank in a node (0 = unspent). */
    public int nodeRank(@NotNull PlayerData data, @NotNull String branch, @NotNull String nodeId) {
        return plugin.getConfigManager().main().get().getInt(
                "skill-tree-cache." + data.getUuid() + "." + branch + "." + nodeId, 0);
    }

    /** Attempts to spend a skill point on a node. Returns true on success. */
    public boolean spendPoint(@NotNull Player player, @NotNull String branch, @NotNull String nodeId) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();

        Map<String, Map<String, SkillNode>> all = branches();
        Map<String, SkillNode> branchNodes = all.get(branch);
        if (branchNodes == null) return false;
        SkillNode node = branchNodes.get(nodeId);
        if (node == null) return false;

        int currentRank = nodeRank(data, branch, nodeId);
        if (currentRank >= node.maxRank) {
            player.sendMessage(plugin.getMessages().get("skilltree-maxed"));
            return false;
        }
        if (!data.spendSkillPoints(node.cost)) {
            player.sendMessage(plugin.getMessages().get("skilltree-no-points"));
            return false;
        }

        // Store rank in player data via a simple key convention
        String key = "skill_" + branch + "_" + nodeId + "_" + (currentRank + 1);
        data.learnTalent(key);
        player.sendMessage(plugin.getMessages().get("skilltree-purchased", node.name));
        return true;
    }

    /** Returns total skill points spent across all branches. */
    public int spentPoints(@NotNull PlayerData data) {
        int count = 0;
        for (String talent : data.getLearnedTalents()) {
            if (talent.startsWith("skill_")) count++;
        }
        return count;
    }

    public static final class SkillNode {
        public final String id;
        public final String branch;
        public final String name;
        public final int cost;
        public final int maxRank;

        SkillNode(String id, String branch, String name, int cost, int maxRank) {
            this.id = id;
            this.branch = branch;
            this.name = name;
            this.cost = cost;
            this.maxRank = maxRank;
        }
    }
}
