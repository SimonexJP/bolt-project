package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.util.TextUtil;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Manages unlockable floating titles such as Apprentice, Mage, Archmage,
 * Grand Wizard and Magic Wanderer. Titles are unlocked by level or
 * achievement and displayed via TAB / PlaceholderAPI integration.
 */
public class TitleManager {

    private final MagicPlugin plugin;

    public TitleManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /** Title id -> display text from config. */
    public Map<String, String> titles() {
        Map<String, String> result = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("titles");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                result.put(key, section.getString(key + ".display", key));
            }
        }
        return result;
    }

    public int unlockLevel(@NotNull String titleId) {
        return plugin.getConfigManager().main().get().getInt("titles." + titleId + ".unlock-level", 10);
    }

    /** Returns the titles the player has unlocked based on level. */
    public Map<String, String> unlockedFor(@NotNull PlayerData data) {
        Map<String, String> available = new LinkedHashMap<>();
        for (var entry : titles().entrySet()) {
            if (data.getLevel() >= unlockLevel(entry.getKey())) {
                available.put(entry.getKey(), entry.getValue());
            }
        }
        return available;
    }

    /** Sets the player's active title. */
    public boolean setActive(@NotNull Player player, @NotNull String titleId) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        Map<String, String> unlocked = unlockedFor(data);
        if (!unlocked.containsKey(titleId)) {
            player.sendMessage(plugin.getMessages().get("title-not-unlocked"));
            return false;
        }
        data.setActiveTitle(titleId);
        player.sendMessage(plugin.getMessages().get("title-set", TextUtil.color(unlocked.get(titleId))));
        return true;
    }

    /** Clears the player's active title. */
    public void clear(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        mp.getData().setActiveTitle(null);
        player.sendMessage(plugin.getMessages().get("title-cleared"));
    }

    /** Returns the colored display text of the player's active title, or null. */
    public String activeDisplay(@NotNull PlayerData data) {
        if (data.getActiveTitle() == null) return null;
        String display = titles().get(data.getActiveTitle());
        return display != null ? TextUtil.color(display) : null;
    }
}
