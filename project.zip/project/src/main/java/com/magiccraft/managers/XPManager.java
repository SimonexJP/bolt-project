package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import org.bukkit.entity.EntityType;

/**
 * Reads XP rewards from xp.yml and resolves per-mob values.
 */
public class XPManager {

    private final MagicPlugin plugin;

    public XPManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public YamlConfig config() { return plugin.getConfigManager().xp(); }

    public int forMob(@org.jetbrains.annotations.Nullable EntityType type) {
        if (type == null) return defaultXp();
        return config().get().getInt("xp." + type.name(), defaultXp());
    }

    public int defaultXp() { return config().get().getInt("default-xp", 5); }

    public int spellCastXp() { return config().get().getInt("spell-cast-xp", 2); }
}
