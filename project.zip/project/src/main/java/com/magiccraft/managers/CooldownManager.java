package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks per-spell cooldowns per player using wall-clock timestamps.
 * Intentionally simple and lock-free via ConcurrentHashMap.
 */
public class CooldownManager {

    private final MagicPlugin plugin;
    // key = uuid + ":" + spellId, value = expiry epoch millis
    private final Map<String, Long> cooldowns = new ConcurrentHashMap<>();

    public CooldownManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void set(UUID uuid, String spellId, long cooldownMillis) {
        if (cooldownMillis <= 0) return;
        cooldowns.put(key(uuid, spellId), System.currentTimeMillis() + cooldownMillis);
    }

    public boolean isOnCooldown(UUID uuid, String spellId) {
        Long expiry = cooldowns.get(key(uuid, spellId));
        if (expiry == null) return false;
        if (System.currentTimeMillis() >= expiry) {
            cooldowns.remove(key(uuid, spellId));
            return false;
        }
        return true;
    }

    public long remainingMillis(UUID uuid, String spellId) {
        Long expiry = cooldowns.get(key(uuid, spellId));
        if (expiry == null) return 0;
        long remaining = expiry - System.currentTimeMillis();
        if (remaining <= 0) {
            cooldowns.remove(key(uuid, spellId));
            return 0;
        }
        return remaining;
    }

    public int remainingSeconds(UUID uuid, String spellId) {
        return (int) Math.ceil(remainingMillis(uuid, spellId) / 1000.0);
    }

    public void clear(UUID uuid) {
        String prefix = uuid.toString() + ":";
        cooldowns.keySet().removeIf(k -> k.startsWith(prefix));
    }

    private String key(UUID uuid, String spellId) {
        return uuid.toString() + ":" + spellId.toLowerCase();
    }
}
