package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Handles the prestige system: after level 100, players may prestige to
 * reset level/XP/spell progression in exchange for permanent bonuses,
 * prestige stars, cosmetics, titles and future unlocks.
 */
public class PrestigeManager {

    private final MagicPlugin plugin;

    public PrestigeManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public int prestigeLevel(@NotNull PlayerData data) { return data.getPrestigeLevel(); }
    public int prestigePoints(@NotNull PlayerData data) { return data.getPrestigePoints(); }

    public boolean canPrestige(@NotNull PlayerData data) {
        int maxLevel = plugin.getLevelManager().maxLevel();
        return data.getLevel() >= maxLevel;
    }

    public boolean prestige(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (!canPrestige(data)) {
            player.sendMessage(plugin.getMessages().get("prestige-not-ready"));
            return false;
        }

        data.setPrestigeLevel(data.getPrestigeLevel() + 1);
        int rewardPoints = plugin.getConfigManager().main().get().getInt("prestige.points-per-prestige", 5);
        data.addPrestigePoints(rewardPoints);
        data.addSkillPoints(plugin.getConfigManager().main().get().getInt("prestige.skill-points-per-prestige", 10));

        // Reset progression
        data.setLevel(1);
        data.setXp(0);
        data.setMana(plugin.getManaManager().baseMaxMana());
        data.setMaxMana(plugin.getManaManager().baseMaxMana());
        // Lock all non-default spells, then re-evaluate unlocks
        if (data.getFaction() != null) {
            for (var spell : plugin.getSpellManager().all().values()) {
                if (spell.getFaction() == data.getFaction()) {
                    data.lockSpell(spell.getId());
                }
            }
            plugin.getLevelManager().refreshUnlocks(player.getUniqueId(), data);
        }

        player.sendTitle(
                plugin.getMessages().raw("prestige-title"),
                plugin.getMessages().raw("prestige-subtitle", data.getPrestigeLevel()),
                10, 80, 20);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 0.8f);
        player.getWorld().spawnParticle(org.bukkit.Particle.END_ROD, player.getLocation().add(0, 1, 0), 60, 1, 2, 1, 0.1);
        player.sendMessage(plugin.getMessages().get("prestige-success", data.getPrestigeLevel(), rewardPoints));
        return true;
    }

    /** Admin shortcut to force-prestige a player regardless of level. */
    public void adminPrestige(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        data.setPrestigeLevel(data.getPrestigeLevel() + 1);
        data.addPrestigePoints(plugin.getConfigManager().main().get().getInt("prestige.points-per-prestige", 5));
        data.addSkillPoints(plugin.getConfigManager().main().get().getInt("prestige.skill-points-per-prestige", 10));
        player.sendMessage(plugin.getMessages().get("prestige-success", data.getPrestigeLevel(),
                plugin.getConfigManager().main().get().getInt("prestige.points-per-prestige", 5)));
    }
}
