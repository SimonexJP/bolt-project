package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Generates leaderboards from in-memory player data. Supports sorting by
 * level, XP, prestige, kills, spells cast, and achievements. Results are
 * consumed by the leaderboard GUI and PlaceholderAPI integration.
 */
public class LeaderboardManager {

    private final MagicPlugin plugin;

    public LeaderboardManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public enum Category {
        LEVEL,
        XP,
        PRESTIGE,
        SPELLS_CAST,
        ACHIEVEMENTS
    }

    /** Returns the top N entries for the given category. */
    public List<LeaderboardEntry> top(@NotNull Category category, int limit) {
        List<LeaderboardEntry> entries = new ArrayList<>();
        for (MagicPlayer mp : plugin.getPlayerManager().all()) {
            PlayerData data = mp.getData();
            entries.add(new LeaderboardEntry(
                    mp.getPlayer().getName(),
                    mp.getUuid(),
                    valueFor(category, data)
            ));
        }
        entries.sort(Comparator.comparingInt(LeaderboardEntry::value).reversed());
        return entries.stream().limit(limit).collect(Collectors.toList());
    }

    private int valueFor(@NotNull Category category, @NotNull PlayerData data) {
        return switch (category) {
            case LEVEL -> data.getLevel();
            case XP -> data.getXp() + data.getStatistics().getXpGained();
            case PRESTIGE -> data.getPrestigeLevel();
            case SPELLS_CAST -> data.getStatistics().getSpellsCast();
            case ACHIEVEMENTS -> data.getEarnedAchievements().size();
        };
    }

    public String categoryName(@NotNull Category category) {
        return switch (category) {
            case LEVEL -> "Level";
            case XP -> "Total XP";
            case PRESTIGE -> "Prestige";
            case SPELLS_CAST -> "Spells Cast";
            case ACHIEVEMENTS -> "Achievements";
        };
    }

    public record LeaderboardEntry(String name, java.util.UUID uuid, int value) {}
}
