package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.spells.Spell;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/**
 * Handles spell learning through configurable spell books.
 *
 * <p>Players learn spells by "studying" a spell book item (right-click).
 * A spell book teaches a specific spell if the player meets the faction
 * and level requirements. Admins with {@code magic.admin.allspells}
 * bypass all requirements.
 */
public class SpellBookManager {

    private final MagicPlugin plugin;

    public SpellBookManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Attempts to teach a spell to the player.
     *
     * @return true if the spell was learned (or already known)
     */
    public boolean learn(@NotNull Player player, @NotNull String spellId) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();

        if (data.hasSpell(spellId)) {
            player.sendMessage(plugin.getMessages().get("spellbook-already-known",
                    plugin.getSpellManager().displayName(spellId)));
            return true;
        }

        boolean adminBypass = player.hasPermission("magic.admin.allspells");
        Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
        if (spell == null) {
            player.sendMessage(plugin.getMessages().get("spell-not-found"));
            return false;
        }

        if (!adminBypass) {
            if (data.getFaction() == null || spell.getFaction() != data.getFaction()) {
                player.sendMessage(plugin.getMessages().get("spellbook-wrong-faction",
                        plugin.getSpellManager().displayName(spellId)));
                return false;
            }
            int unlockLevel = plugin.getSpellManager().unlockLevel(spellId, spell.getFaction());
            if (data.getLevel() < unlockLevel) {
                player.sendMessage(plugin.getMessages().get("spellbook-low-level",
                        plugin.getSpellManager().displayName(spellId), unlockLevel));
                return false;
            }
        }

        data.unlockSpell(spellId);
        player.sendMessage(plugin.getMessages().get("spellbook-learned",
                plugin.getSpellManager().displayName(spellId)));
        plugin.getFactionManager().get(spell.getFaction()).ifPresent(f ->
                f.playSound(player.getLocation()));
        return true;
    }

    /** Removes a learned spell from the player (admin tool). */
    public boolean unlearn(@NotNull Player player, @NotNull String spellId) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (!data.hasSpell(spellId)) return false;
        data.lockSpell(spellId);
        player.sendMessage(plugin.getMessages().get("spellbook-removed",
                plugin.getSpellManager().displayName(spellId)));
        return true;
    }

    /** Unlocks every spell for the player's faction (admin bypass). */
    public void unlockAll(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        FactionType faction = data.getFaction();
        if (faction == null) {
            player.sendMessage(plugin.getMessages().get("faction-none"));
            return;
        }
        for (Spell spell : plugin.getSpellManager().all().values()) {
            if (spell.getFaction() == faction) {
                data.unlockSpell(spell.getId());
            }
        }
        player.sendMessage(plugin.getMessages().get("spellbook-unlock-all"));
    }

    /** Removes all non-default spells from the player's faction (admin tool). */
    public void lockAll(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        FactionType faction = data.getFaction();
        if (faction == null) return;
        for (Spell spell : plugin.getSpellManager().all().values()) {
            if (spell.getFaction() == faction) {
                data.lockSpell(spell.getId());
            }
        }
        plugin.getLevelManager().refreshUnlocks(player.getUniqueId(), data);
        player.sendMessage(plugin.getMessages().get("spellbook-lock-all"));
    }
}
