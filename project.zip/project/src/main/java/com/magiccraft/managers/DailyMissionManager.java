package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Generates and tracks configurable daily missions. Each player gets a
 * set of daily quests that refresh every 24 hours. Completing missions
 * rewards XP, coins, prestige points and cosmetics.
 */
public class DailyMissionManager {

    private final MagicPlugin plugin;
    private final Map<UUID, PlayerMissions> activeMissions = new ConcurrentHashMap<>();
    private long lastRefresh;

    public DailyMissionManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /** Available mission templates from config. */
    public Map<String, MissionTemplate> missionTemplates() {
        Map<String, MissionTemplate> templates = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("daily-missions.missions");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                String name = section.getString(key + ".name", key);
                int target = section.getInt(key + ".target", 10);
                int xpReward = section.getInt(key + ".xp-reward", 100);
                int ppReward = section.getInt(key + ".pp-reward", 1);
                templates.put(key, new MissionTemplate(key, name, target, xpReward, ppReward));
            }
        }
        return templates;
    }

    public int missionsPerDay() {
        return plugin.getConfigManager().main().get().getInt("daily-missions.missions-per-day", 3);
    }

    /** Gets or generates the player's daily missions. */
    public PlayerMissions get(@NotNull Player player) {
        checkRefresh();
        return activeMissions.computeIfAbsent(player.getUniqueId(), uuid -> generate(uuid));
    }

    private PlayerMissions generate(UUID uuid) {
        Map<String, MissionTemplate> all = missionTemplates();
        PlayerMissions pm = new PlayerMissions(uuid);
        int count = Math.min(missionsPerDay(), all.size());
        int i = 0;
        for (var entry : all.entrySet()) {
            if (i >= count) break;
            pm.missions.add(new MissionProgress(entry.getValue(), 0, false));
            i++;
        }
        return pm;
    }

    private void checkRefresh() {
        long refreshInterval = 24 * 60 * 60 * 1000L;
        if (System.currentTimeMillis() - lastRefresh > refreshInterval) {
            activeMissions.clear();
            lastRefresh = System.currentTimeMillis();
        }
    }

    /** Records progress toward a mission type (e.g. "mob_kills", "spell_casts"). */
    public void recordProgress(@NotNull Player player, @NotNull String missionType, int amount) {
        PlayerMissions pm = get(player);
        for (MissionProgress mp : pm.missions) {
            if (mp.template.id.equals(missionType) && !mp.completed) {
                mp.progress += amount;
                if (mp.progress >= mp.template.target) {
                    mp.completed = true;
                    completeMission(player, mp);
                }
            }
        }
    }

    private void completeMission(@NotNull Player player, @NotNull MissionProgress mission) {
        player.sendMessage(plugin.getMessages().get("daily-mission-complete", mission.template.name));
        plugin.getLevelManager().addXp(player, mission.template.xpReward, "daily_mission");
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp != null) mp.getData().addPrestigePoints(mission.template.ppReward);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.4f);
    }

    public static final class MissionTemplate {
        public final String id;
        public final String name;
        public final int target;
        public final int xpReward;
        public final int ppReward;

        MissionTemplate(String id, String name, int target, int xpReward, int ppReward) {
            this.id = id;
            this.name = name;
            this.target = target;
            this.xpReward = xpReward;
            this.ppReward = ppReward;
        }
    }

    public static final class MissionProgress {
        public final MissionTemplate template;
        public int progress;
        public boolean completed;

        MissionProgress(MissionTemplate template, int progress, boolean completed) {
            this.template = template;
            this.progress = progress;
            this.completed = completed;
        }
    }

    public static final class PlayerMissions {
        public final UUID uuid;
        public final List<MissionProgress> missions;

        PlayerMissions(UUID uuid) {
            this.uuid = uuid;
            this.missions = new java.util.ArrayList<>();
        }
    }
}
