package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.SpellType;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.spells.PassiveSpell;
import com.magiccraft.spells.Spell;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks which passive spells are currently active per player and ticks
 * them on a regular interval. Passives are applied when learned and
 * removed when unlearned or on quit.
 */
public class PassiveManager {

    private final MagicPlugin plugin;
    private final Set<UUID> activePlayers = ConcurrentHashMap.newKeySet();
    private BukkitRunnable tickTask;

    public PassiveManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        int interval = plugin.getConfigManager().main().get().getInt("passive.tick-interval-ticks", 40);
        tickTask = new BukkitRunnable() {
            @Override public void run() { tickAll(); }
        };
        tickTask.runTaskTimer(plugin, interval, interval);
    }

    public void stop() {
        if (tickTask != null) tickTask.cancel();
    }

    /** Re-evaluates which passives should be active for a player (call on join / spell learn / level up). */
    public void refresh(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        activePlayers.add(player.getUniqueId());
        applyNew(player, data);
        removeLost(player, data);
    }

    private void applyNew(@NotNull Player player, @NotNull PlayerData data) {
        for (String spellId : data.getUnlockedSpells()) {
            Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
            if (spell instanceof PassiveSpell passive && !data.isPassiveActive(spellId)) {
                passive.onPassiveApply(player);
                data.setPassiveActive(spellId, true);
            }
        }
    }

    private void removeLost(@NotNull Player player, @NotNull PlayerData data) {
        for (String spellId : new HashSet<>(data.getActivePassives())) {
            if (!data.hasSpell(spellId)) {
                Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
                if (spell instanceof PassiveSpell passive) {
                    passive.onPassiveRemove(player);
                }
                data.setPassiveActive(spellId, false);
            }
        }
    }

    public void clear(@NotNull Player player) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        PlayerData data = mp.getData();
        for (String spellId : new HashSet<>(data.getActivePassives())) {
            Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
            if (spell instanceof PassiveSpell passive) {
                passive.onPassiveRemove(player);
            }
            data.setPassiveActive(spellId, false);
        }
        activePlayers.remove(player.getUniqueId());
    }

    private void tickAll() {
        for (MagicPlayer mp : plugin.getPlayerManager().all()) {
            Player player = mp.getPlayer();
            if (player == null || !player.isOnline()) continue;
            for (String spellId : mp.getData().getActivePassives()) {
                Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
                if (spell instanceof PassiveSpell passive) {
                    passive.tickPassive(player);
                }
            }
        }
    }
}
