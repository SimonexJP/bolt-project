package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.data.database.DatabaseManager;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory cache of {@link PlayerData} keyed by UUID.
 * Loads on join, saves on quit, and exposes typed accessors.
 */
public class PlayerManager {

    private final MagicPlugin plugin;
    private final Map<UUID, MagicPlayer> cache = new ConcurrentHashMap<>();

    public PlayerManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void onJoin(@NotNull Player player) {
        DatabaseManager db = plugin.getDatabaseManager();
        db.load(player.getUniqueId()).thenAccept(loaded -> {
            PlayerData data = loaded != null ? loaded : new PlayerData(player.getUniqueId());
            data.setLastLogin(System.currentTimeMillis());
            // Recompute max mana from current level (in case config changed).
            int max = plugin.getManaManager().maxManaForLevel(data.getLevel());
            data.setMaxMana(max);
            if (data.getMana() > max) data.setMana(max);
            plugin.sync(() -> {
                cache.put(player.getUniqueId(), new MagicPlayer(player, data));
                plugin.getLevelManager().refreshUnlocks(player.getUniqueId(), data);
            });
        });
    }

    public void onQuit(@NotNull Player player) {
        MagicPlayer mp = cache.remove(player.getUniqueId());
        if (mp != null) {
            plugin.getDatabaseManager().save(mp.getData());
        }
    }

    public Optional<MagicPlayer> get(@NotNull UUID uuid) {
        return Optional.ofNullable(cache.get(uuid));
    }

    public Optional<MagicPlayer> get(@NotNull Player player) {
        return get(player.getUniqueId());
    }

    public @Nullable MagicPlayer getOrNull(@NotNull Player player) {
        return cache.get(player.getUniqueId());
    }

    public Collection<MagicPlayer> all() { return cache.values(); }

    public int onlineWizards() {
        return (int) cache.values().stream().filter(MagicPlayer::hasFaction).count();
    }

    public void save(@NotNull UUID uuid) {
        get(uuid).ifPresent(mp -> plugin.getDatabaseManager().save(mp.getData()));
    }

    public void saveAll() {
        for (MagicPlayer mp : cache.values()) {
            plugin.getDatabaseManager().save(mp.getData());
        }
    }

    public void reset(@NotNull UUID uuid) {
        cache.remove(uuid);
        plugin.getDatabaseManager().delete(uuid);
    }

    public Rank getRank(@NotNull UUID uuid) {
        return get(uuid).map(MagicPlayer::getRank).orElse(Rank.APPRENTICE);
    }
}
