package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.factions.Faction;
import com.magiccraft.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Builds and identifies faction wands. Wands are unbreakable, carry the
 * owner UUID in PersistentDataContainer, and optionally cannot be dropped.
 */
public class WandManager {

    public static final String WAND_KEY = "magic_wand_owner";
    public static final String WAND_FACTION_KEY = "magic_wand_faction";

    private final MagicPlugin plugin;
    private final NamespacedKey ownerKey;
    private final NamespacedKey factionKey;

    public WandManager(MagicPlugin plugin) {
        this.plugin = plugin;
        this.ownerKey = new NamespacedKey(plugin, WAND_KEY);
        this.factionKey = new NamespacedKey(plugin, WAND_FACTION_KEY);
    }

    public NamespacedKey ownerKey() { return ownerKey; }
    public NamespacedKey factionKey() { return factionKey; }

    public boolean preventDrop() {
        return plugin.getConfigManager().main().get().getBoolean("wands.prevent-drop", true);
    }

    @NotNull
    public ItemStack createWand(@NotNull FactionType type, @NotNull UUID owner) {
        Faction faction = plugin.getFactionManager().get(type).orElseThrow();
        Material material = safeMaterial(faction.getWandMaterial());
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextUtil.color(faction.getWandDisplayName()));
            List<String> lore = new ArrayList<>();
            for (String line : faction.getWandLore()) {
                lore.add(TextUtil.color(line.replace("{owner}", owner.toString())));
            }
            meta.setLore(lore);
            meta.setUnbreakable(true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE);
            int cmd = faction.getWandCustomModelData();
            if (cmd > 0) meta.setCustomModelData(cmd);
            meta.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, owner.toString());
            meta.getPersistentDataContainer().set(factionKey, PersistentDataType.STRING, type.name());
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isWand(@Nullable ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(ownerKey, PersistentDataType.STRING);
    }

    public @Nullable UUID owner(@Nullable ItemStack item) {
        if (!isWand(item)) return null;
        String raw = item.getItemMeta().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        if (raw == null) return null;
        try { return UUID.fromString(raw); } catch (IllegalArgumentException e) { return null; }
    }

    public @Nullable FactionType faction(@Nullable ItemStack item) {
        if (!isWand(item)) return null;
        String raw = item.getItemMeta().getPersistentDataContainer().get(factionKey, PersistentDataType.STRING);
        return FactionType.fromId(raw).orElse(null);
    }

    public boolean isOwner(@Nullable ItemStack item, @NotNull UUID uuid) {
        UUID owner = owner(item);
        return owner != null && owner.equals(uuid);
    }

    public void giveWand(@NotNull org.bukkit.entity.Player player, @NotNull FactionType type) {
        ItemStack wand = createWand(type, player.getUniqueId());
        PlayerInventory inv = player.getInventory();
        // Avoid stacking duplicates: only give if the player lacks this wand.
        for (ItemStack it : inv.getContents()) {
            if (isWand(it) && type == faction(it) && player.getUniqueId().equals(owner(it))) {
                return;
            }
        }
        inv.addItem(wand);
    }

    private Material safeMaterial(String name) {
        try { return Material.valueOf(name.toUpperCase()); }
        catch (IllegalArgumentException e) { return Material.STICK; }
    }
}
