package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.ElementAffinity;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.Particle;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Manages element affinity progression. Casting a spell of an element
 * increases affinity for that element. Crossing configured thresholds
 * grants bonuses (damage / mana / cooldown) and cosmetic particle effects.
 */
public class AffinityManager {

    public static final int AFFINITY_PER_CAST = 3;

    private final MagicPlugin plugin;

    public AffinityManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public double maxBonusPercent() {
        return plugin.getConfigManager().main().get().getDouble("affinity.max-bonus-percent", 0.20);
    }

    public int gainPerCast() {
        return plugin.getConfigManager().main().get().getInt("affinity.gain-per-cast", AFFINITY_PER_CAST);
    }

    /** Records a spell cast, increasing affinity for the spell's faction. */
    public void recordCast(@NotNull Player player, @NotNull FactionType element) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;
        ElementAffinity aff = mp.getData().getAffinity();
        int before = aff.get(element);
        aff.add(element, gainPerCast());
        int after = aff.get(element);
        checkThreshold(player, element, before, after);
    }

    /** Returns the damage multiplier contributed by affinity for the element (1.0 + bonus). */
    public double damageMultiplier(@NotNull PlayerData data, @NotNull FactionType element) {
        return 1.0 + data.getAffinity().get(element) / (double) ElementAffinity.MAX_AFFINITY * maxBonusPercent();
    }

    /** Returns the mana cost reduction (0.0 to maxBonus) from affinity. */
    public double manaReduction(@NotNull PlayerData data, @NotNull FactionType element) {
        return data.getAffinity().get(element) / (double) ElementAffinity.MAX_AFFINITY * maxBonusPercent() * 0.5;
    }

    private void checkThreshold(@NotNull Player player, @NotNull FactionType element, int before, int after) {
        int[] thresholds = {250, 500, 750, 1000};
        for (int threshold : thresholds) {
            if (before < threshold && after >= threshold) {
                onThresholdReached(player, element, threshold);
            }
        }
    }

    private void onThresholdReached(@NotNull Player player, @NotNull FactionType element, int threshold) {
        String key = "affinity.threshold-" + threshold;
        String msg = plugin.getMessages().raw(key, element.name(), threshold);
        if (!msg.equals(key)) {
            player.sendMessage(msg);
        }
        Particle particle = plugin.getFactionManager().get(element)
                .map(f -> f.getParticle())
                .orElse(Particle.END_ROD);
        player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1, 0), 30, 0.5, 1, 0.5, 0.05);
        player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.3f);
    }

    /** Applies ambient cosmetic particles for high-affinity players. Called periodically. */
    public void tickAmbient(@NotNull MagicPlayer mp) {
        Player player = mp.getPlayer();
        if (player == null || !player.isOnline()) return;
        for (FactionType type : FactionType.values()) {
            int value = mp.getData().getAffinity().get(type);
            if (value >= 750) {
                plugin.getFactionManager().get(type).ifPresent(f -> f.spawnAmbientParticles(player));
            }
        }
    }
}
