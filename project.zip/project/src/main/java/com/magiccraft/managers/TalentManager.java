package com.magiccraft.managers;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Manages passive talents unlocked every few levels. Talents provide
 * cooldown reduction, mana regeneration, spell critical chance, bonus
 * damage, and max mana bonuses.
 */
public class TalentManager {

    private final MagicPlugin plugin;

    public TalentManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /** Talent id -> display name. Loaded from config. */
    public Map<String, String> talentNames() {
        Map<String, String> names = new LinkedHashMap<>();
        var section = plugin.getConfigManager().main().get().getConfigurationSection("talents");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                names.put(key, section.getString(key + ".name", key));
            }
        }
        return names;
    }

    /** Unlock level for a talent. */
    public int unlockLevel(@NotNull String talentId) {
        return plugin.getConfigManager().main().get().getInt("talents." + talentId + ".unlock-level", 10);
    }

    /** Gives all talents that the player meets the level requirement for. */
    public void refresh(@NotNull Player player, @NotNull PlayerData data) {
        for (String talentId : talentNames().keySet()) {
            if (data.getLevel() >= unlockLevel(talentId) && !data.hasTalent(talentId)) {
                data.learnTalent(talentId);
                player.sendMessage(plugin.getMessages().get("talent-unlocked",
                        talentNames().get(talentId)));
            }
        }
    }

    /** Admin: gives all talents regardless of level. */
    public void giveAll(@NotNull Player player, @NotNull PlayerData data) {
        for (String talentId : talentNames().keySet()) {
            data.learnTalent(talentId);
        }
    }

    /** Aggregate cooldown reduction from all learned talents (0.0 to 1.0). */
    public double cooldownReduction(@NotNull PlayerData data) {
        double total = 0;
        for (String talentId : data.getLearnedTalents()) {
            total += plugin.getConfigManager().main().get().getDouble("talents." + talentId + ".cooldown-reduction", 0);
        }
        return Math.min(0.75, total);
    }

    /** Aggregate mana regen bonus from all learned talents. */
    public double manaRegenBonus(@NotNull PlayerData data) {
        double total = 0;
        for (String talentId : data.getLearnedTalents()) {
            total += plugin.getConfigManager().main().get().getDouble("talents." + talentId + ".mana-regen-bonus", 0);
        }
        return total;
    }

    /** Aggregate spell critical chance from all learned talents (0.0 to 1.0). */
    public double spellCritChance(@NotNull PlayerData data) {
        double total = 0;
        for (String talentId : data.getLearnedTalents()) {
            total += plugin.getConfigManager().main().get().getDouble("talents." + talentId + ".spell-crit-chance", 0);
        }
        return Math.min(0.5, total);
    }

    /** Aggregate bonus damage multiplier from all learned talents. */
    public double bonusDamageMultiplier(@NotNull PlayerData data) {
        double total = 0;
        for (String talentId : data.getLearnedTalents()) {
            total += plugin.getConfigManager().main().get().getDouble("talents." + talentId + ".bonus-damage", 0);
        }
        return 1.0 + total;
    }

    /** Aggregate max mana bonus from all learned talents. */
    public int maxManaBonus(@NotNull PlayerData data) {
        int total = 0;
        for (String talentId : data.getLearnedTalents()) {
            total += plugin.getConfigManager().main().get().getInt("talents." + talentId + ".max-mana-bonus", 0);
        }
        return total;
    }
}
