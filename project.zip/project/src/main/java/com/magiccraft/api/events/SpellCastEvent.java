package com.magiccraft.api.events;

import com.magiccraft.core.enums.CastCombo;
import com.magiccraft.spells.Spell;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player casts a spell, before mana/cooldown are consumed.
 * Cancellable.
 */
public class SpellCastEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList handlers = new HandlerList();
    private final Spell spell;
    private final CastCombo combo;
    private boolean cancelled;

    public SpellCastEvent(@NotNull Player player, @NotNull Spell spell, @NotNull CastCombo combo) {
        super(player);
        this.spell = spell;
        this.combo = combo;
    }

    public Spell getSpell() { return spell; }
    public CastCombo getCombo() { return combo; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @NotNull
    @Override public HandlerList getHandlers() { return handlers; }
    public static HandlerList getHandlerList() { return handlers; }
}
