package com.magiccraft.api.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Fired before XP is added to a player. Cancellable.
 */
public class PlayerGainXPEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList handlers = new HandlerList();
    private int amount;
    private final String source;
    private boolean cancelled;

    public PlayerGainXPEvent(@NotNull Player player, int amount, @NotNull String source) {
        super(player);
        this.amount = amount;
        this.source = source;
    }

    public int getAmount() { return amount; }
    public void setAmount(int amount) { this.amount = amount; }
    public String getSource() { return source; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @NotNull
    @Override public HandlerList getHandlers() { return handlers; }
    public static HandlerList getHandlerList() { return handlers; }
}
