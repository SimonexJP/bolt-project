package com.magiccraft.api.events;

import com.magiccraft.core.enums.FactionType;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player joins a faction. Cancellable.
 */
public class FactionJoinEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList handlers = new HandlerList();
    private final FactionType faction;
    private boolean cancelled;

    public FactionJoinEvent(@NotNull Player player, @NotNull FactionType faction) {
        super(player);
        this.faction = faction;
    }

    public FactionType getFaction() { return faction; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @NotNull
    @Override public HandlerList getHandlers() { return handlers; }
    public static HandlerList getHandlerList() { return handlers; }
}
