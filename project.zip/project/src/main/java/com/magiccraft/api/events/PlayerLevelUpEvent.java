package com.magiccraft.api.events;

import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Fired after a player levels up. Not cancellable (state already applied).
 */
public class PlayerLevelUpEvent extends PlayerEvent {

    private static final HandlerList handlers = new HandlerList();
    private final int oldLevel;
    private final int newLevel;
    private final PlayerData data;

    public PlayerLevelUpEvent(@NotNull Player player, int oldLevel, int newLevel, @NotNull PlayerData data) {
        super(player);
        this.oldLevel = oldLevel;
        this.newLevel = newLevel;
        this.data = data;
    }

    public int getOldLevel() { return oldLevel; }
    public int getNewLevel() { return newLevel; }
    public PlayerData getData() { return data; }

    @NotNull
    @Override public HandlerList getHandlers() { return handlers; }
    public static HandlerList getHandlerList() { return handlers; }
}
