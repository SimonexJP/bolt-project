package com.magiccraft.api.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Fired when a player's mana changes (cast, regen, admin set).
 */
public class ManaChangeEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList handlers = new HandlerList();
    private final int oldMana;
    private int newMana;
    private final Cause cause;
    private boolean cancelled;

    public enum Cause { CAST, REGEN, ADMIN, OTHER }

    public ManaChangeEvent(@NotNull Player player, int oldMana, int newMana, @NotNull Cause cause) {
        super(player);
        this.oldMana = oldMana;
        this.newMana = newMana;
        this.cause = cause;
    }

    public int getOldMana() { return oldMana; }
    public int getNewMana() { return newMana; }
    public void setNewMana(int newMana) { this.newMana = newMana; }
    public Cause getCause() { return cause; }

    @Override public boolean isCancelled() { return cancelled; }
    @Override public void setCancelled(boolean cancelled) { this.cancelled = cancelled; }

    @NotNull
    @Override public HandlerList getHandlers() { return handlers; }
    public static HandlerList getHandlerList() { return handlers; }
}
