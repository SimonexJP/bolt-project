package com.magiccraft;

import com.magiccraft.capitalpunishment.CapitalPunishmentCommand;
import com.magiccraft.capitalpunishment.CapitalPunishmentListener;
import com.magiccraft.capitalpunishment.CapitalPunishmentManager;
import com.magiccraft.commands.*;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.Messages;
import com.magiccraft.data.database.DatabaseManager;
import com.magiccraft.duel.DuelCommand;
import com.magiccraft.duel.DuelListener;
import com.magiccraft.duel.DuelManager;
import com.magiccraft.factions.FactionManager;
import com.magiccraft.factions.system.FactionSystemCommand;
import com.magiccraft.factions.system.FactionSystemListener;
import com.magiccraft.factions.system.FactionSystemManager;
import com.magiccraft.gui.GuiManager;
import com.magiccraft.gui.guis.*;
import com.magiccraft.listeners.*;
import com.magiccraft.managers.*;
import com.magiccraft.placeholder.MagicPlaceholderExpansion;
import com.magiccraft.scoreboard.MagicScoreboard;
import com.magiccraft.services.FactionService;
import com.magiccraft.spells.SpellFactory;
import com.magiccraft.tasks.TaskScheduler;
import com.magiccraft.tournament.TournamentCommand;
import com.magiccraft.tournament.TournamentListener;
import com.magiccraft.tournament.TournamentManager;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

/**
 * Main plugin entry point. Wires up all managers, services, listeners,
 * commands, and GUIs using constructor-based dependency injection.
 */
public class MagicPlugin extends JavaPlugin {

    // Config
    private ConfigManager configManager;
    private Messages messages;

    // Data
    private DatabaseManager databaseManager;

    // Managers
    private PlayerManager playerManager;
    private ManaManager manaManager;
    private XPManager xpManager;
    private LevelManager levelManager;
    private CooldownManager cooldownManager;
    private SpellManager spellManager;
    private WandManager wandManager;
    private FactionManager factionManager;
    private AffinityManager affinityManager;
    private SpellBookManager spellBookManager;
    private SpellBookItemManager spellBookItemManager;
    private PassiveManager passiveManager;
    private PrestigeManager prestigeManager;
    private TalentManager talentManager;
    private AchievementManager achievementManager;
    private DailyMissionManager dailyMissionManager;
    private TitleManager titleManager;
    private LeaderboardManager leaderboardManager;
    private SkillTreeManager skillTreeManager;
    private NpcManager npcManager;

    // Capital Punishment
    private CapitalPunishmentManager capitalPunishmentManager;

    // Faction Systems
    private FactionSystemManager factionSystemManager;

    // Duel
    private DuelManager duelManager;

    // Tournament
    private TournamentManager tournamentManager;

    // Services
    private FactionService factionService;

    // GUI
    private GuiManager guiManager;

    // Scoreboard
    private MagicScoreboard scoreboard;

    // Tasks
    private TaskScheduler taskScheduler;

    // PlaceholderAPI
    private MagicPlaceholderExpansion placeholderExpansion;

    @Override
    public void onEnable() {
        configManager = new ConfigManager(this);
        configManager.loadAll();
        messages = new Messages(this);

        databaseManager = new DatabaseManager(this);
        databaseManager.startup();

        playerManager = new PlayerManager(this);
        manaManager = new ManaManager(this);
        xpManager = new XPManager(this);
        levelManager = new LevelManager(this);
        cooldownManager = new CooldownManager(this);
        spellManager = new SpellManager(this);
        wandManager = new WandManager(this);
        factionManager = new FactionManager(this);
        factionManager.registerDefaults();

        affinityManager = new AffinityManager(this);
        spellBookManager = new SpellBookManager(this);
        spellBookItemManager = new SpellBookItemManager(this);
        passiveManager = new PassiveManager(this);
        prestigeManager = new PrestigeManager(this);
        talentManager = new TalentManager(this);
        achievementManager = new AchievementManager(this);
        dailyMissionManager = new DailyMissionManager(this);
        titleManager = new TitleManager(this);
        leaderboardManager = new LeaderboardManager(this);
        skillTreeManager = new SkillTreeManager(this);
        npcManager = new NpcManager(this);
        npcManager.start();

        SpellFactory.registerAll(this);

        factionService = new FactionService(this);

        capitalPunishmentManager = new CapitalPunishmentManager(this);

        factionSystemManager = new FactionSystemManager(this);
        factionSystemManager.init();

        duelManager = new DuelManager(this);

        tournamentManager = new TournamentManager(this);

        guiManager = new GuiManager(this);
        registerGuis();

        scoreboard = new MagicScoreboard(this);
        scoreboard.loadConfig();

        registerListeners();
        registerCommands();

        taskScheduler = new TaskScheduler(this);
        taskScheduler.start();
        passiveManager.start();

        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            placeholderExpansion = new MagicPlaceholderExpansion(this);
            placeholderExpansion.register();
        }

        for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) {
            playerManager.onJoin(p);
        }

        getLogger().info("MagicPlugin enabled successfully.");
    }

    @Override
    public void onDisable() {
        if (passiveManager != null) passiveManager.stop();
        if (playerManager != null) playerManager.saveAll();
        if (factionSystemManager != null) factionSystemManager.saveAll();
        if (databaseManager != null) databaseManager.close();
        if (placeholderExpansion != null) placeholderExpansion.unregister();
        getLogger().info("MagicPlugin disabled.");
    }

    private void registerGuis() {
        guiManager.register(GuiManager.MAIN, MainGui::new);
        guiManager.register(GuiManager.PROFILE, ProfileGui::new);
        guiManager.register(GuiManager.SPELLS, SpellsGui::new);
        guiManager.register(GuiManager.FACTION, FactionGui::new);
        guiManager.register(GuiManager.ADMIN, AdminGui::new);
        guiManager.register(GuiManager.PROGRESSION, ProgressionGui::new);
        guiManager.register(GuiManager.STATISTICS, StatisticsGui::new);
    }

    private void registerListeners() {
        register(new PlayerConnectionListener(this));
        register(new MobDeathListener(this));
        register(new WandInteractListener(this));
        register(new WandProtectionListener(this));
        register(new SpellProjectileListener(this));
        register(new PlayerDeathListener(this));
        register(new CapitalPunishmentListener(this));
        register(new FactionSystemListener(this, factionSystemManager));
        register(new DuelListener(this));
        register(new TournamentListener(this));
        register(guiManager);
    }

    private void register(@NotNull Listener listener) {
        Bukkit.getPluginManager().registerEvents(listener, this);
    }

    private void registerCommands() {
        registerCommand("magic", new MagicCommand(this));
        registerCommand("faction", new FactionCommand(this));
        registerCommand("wand", new WandCommand(this));
        registerCommand("spells", new SpellsCommand(this));
        registerCommand("magicadmin", new MagicAdminCommand(this));
        registerCommand("penacapitale", new CapitalPunishmentCommand(this));
        registerCommand("fazione", new FactionSystemCommand(this, factionSystemManager));
        registerCommand("duello", new DuelCommand(this));
        registerCommand("torneo", new TournamentCommand(this));
    }

    private void registerCommand(String name, CommandExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd != null) {
            cmd.setExecutor(executor);
            if (executor instanceof TabCompleter tc) cmd.setTabCompleter(tc);
        } else {
            getLogger().warning("Command '" + name + "' not found in plugin.yml!");
        }
    }

    /** Runs a task on the main thread. */
    public void sync(@NotNull Runnable runnable) {
        Bukkit.getScheduler().runTask(this, runnable);
    }

    // --- Accessors ---
    public ConfigManager getConfigManager() { return configManager; }
    public Messages getMessages() { return messages; }
    public DatabaseManager getDatabaseManager() { return databaseManager; }
    public PlayerManager getPlayerManager() { return playerManager; }
    public ManaManager getManaManager() { return manaManager; }
    public XPManager getXPManager() { return xpManager; }
    public LevelManager getLevelManager() { return levelManager; }
    public LeaderboardManager getLeaderboardManager() { return leaderboardManager; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public SpellManager getSpellManager() { return spellManager; }
    public WandManager getWandManager() { return wandManager; }
    public FactionManager getFactionManager() { return factionManager; }
    public FactionService getFactionService() { return factionService; }
    public GuiManager getGuiManager() { return guiManager; }
    public MagicScoreboard getScoreboard() { return scoreboard; }
    public CapitalPunishmentManager getCapitalPunishmentManager() { return capitalPunishmentManager; }
    public FactionSystemManager getFactionSystemManager() { return factionSystemManager; }
    public DuelManager getDuelManager() { return duelManager; }
    public TournamentManager getTournamentManager() { return tournamentManager; }
    public AffinityManager getAffinityManager() { return affinityManager; }
    public SpellBookManager getSpellBookManager() { return spellBookManager; }
    public PassiveManager getPassiveManager() { return passiveManager; }
    public SpellBookItemManager getSpellBookItemManager() { return spellBookItemManager; }
    public PrestigeManager getPrestigeManager() { return prestigeManager; }
    public TalentManager getTalentManager() { return talentManager; }
}
