package com.magiccraft.services;

import com.magiccraft.MagicPlugin;
import com.magiccraft.api.events.FactionJoinEvent;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Encapsulates the faction-join workflow: event firing, data update,
 * spell unlock refresh, and optional wand delivery.
 */
public class FactionService {

    private final MagicPlugin plugin;

    public FactionService(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Joins a faction. Respects the "cannot change" rule unless {@code force} is true.
     *
     * @return true if the join succeeded
     */
    public boolean joinFaction(@NotNull Player player, @NotNull FactionType type) {
        return joinFaction(player, type, false);
    }

    public boolean joinFaction(@NotNull Player player, @NotNull FactionType type, boolean force) {
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return false;
        PlayerData data = mp.getData();
        if (data.getFaction() != null && !force) {
            player.sendMessage(plugin.getMessages().get("faction-already-joined",
                    data.getFaction().name()));
            return false;
        }

        FactionJoinEvent event = new FactionJoinEvent(player, type);
        Bukkit.getPluginManager().callEvent(event);
        if (event.isCancelled()) return false;

        data.setFaction(type);
        plugin.getLevelManager().refreshUnlocks(player.getUniqueId(), data);

        var faction = plugin.getFactionManager().get(type);
        faction.ifPresent(f -> f.playSound(player.getLocation()));

        if (plugin.getConfigManager().main().get().getBoolean("wands.give-on-join", true)) {
            plugin.getWandManager().giveWand(player, type);
        }

        player.sendMessage(plugin.getMessages().get("faction-joined", type.name()));
        return true;
    }
}
