package com.magiccraft.scoreboard;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.util.TextUtil;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-player scoreboard with fully configurable lines, title, and footer.
 * Reads its layout from config.yml → scoreboard section.
 */
public class MagicScoreboard {

    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.legacyAmpersand();

    private final MagicPlugin plugin;
    private boolean enabled;
    private String title;
    private String footer;
    private List<String> lineTemplates;
    private int refreshTicks;

    public MagicScoreboard(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadConfig() {
        ConfigurationSection cfg = plugin.getConfigManager().main().get().getConfigurationSection("scoreboard");
        enabled = cfg != null && cfg.getBoolean("enabled", true);
        title = cfg != null ? cfg.getString("title", "&d&l✨ Magic ✨") : "&d&l✨ Magic ✨";
        footer = cfg != null ? cfg.getString("footer", "") : "";
        lineTemplates = cfg != null ? cfg.getStringList("lines") : List.of();
        if (lineTemplates.isEmpty()) {
            lineTemplates = List.of(
                    "&bFaction: &f{faction}",
                    "&bLevel: &f{level}",
                    "&bRank: &f{rank}",
                    "&bXP: &f{xp} / {xp_needed}",
                    "&bMana: &f{mana} / {max_mana}"
            );
        }
        refreshTicks = cfg != null ? cfg.getInt("refresh-ticks", 20) : 20;
    }

    public boolean isEnabled() { return enabled; }
    public int getRefreshTicks() { return refreshTicks; }

    public void apply(@NotNull Player player) {
        if (!enabled) return;
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("magic", "dummy", SERIALIZER.deserialize(title));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        var mp = plugin.getPlayerManager().getOrNull(player);
        List<String> lines = resolveLines(mp);
        int score = lines.size();
        for (int i = 0; i < lines.size(); i++) {
            String entryName = padEntry(i);
            Team team = board.registerNewTeam("line" + i);
            team.addEntry(entryName);
            team.prefix(SERIALIZER.deserialize(lines.get(i)));
            obj.getScore(entryName).setScore(score - i);
        }
        player.setScoreboard(board);
    }

    private List<String> resolveLines(MagicPlayer mp) {
        List<String> result = new ArrayList<>(lineTemplates.size());
        for (String template : lineTemplates) {
            result.add(TextUtil.color(replacePlaceholders(template, mp)));
        }
        if (footer != null && !footer.isEmpty()) {
            result.add("");
            result.add(TextUtil.color(footer));
        }
        return result;
    }

    private String replacePlaceholders(String template, MagicPlayer mp) {
        if (mp == null) {
            return template
                    .replace("{faction}", "None")
                    .replace("{level}", "1")
                    .replace("{rank}", "Apprentice")
                    .replace("{xp}", "0")
                    .replace("{xp_needed}", "100")
                    .replace("{mana}", "100")
                    .replace("{max_mana}", "100")
                    .replace("{online}", "0");
        }
        PlayerData d = mp.getData();
        Rank rank = Rank.fromLevel(d.getLevel());
        int xpNeeded = plugin.getLevelManager().xpForLevel(d.getLevel());
        return template
                .replace("{faction}", d.getFaction() == null ? "None" : d.getFaction().name())
                .replace("{level}", String.valueOf(d.getLevel()))
                .replace("{rank}", rank.getDisplayName())
                .replace("{xp}", String.format("%,d", d.getXp()))
                .replace("{xp_needed}", String.format("%,d", xpNeeded))
                .replace("{mana}", String.valueOf(d.getMana()))
                .replace("{max_mana}", String.valueOf(d.getMaxMana()))
                .replace("{online}", String.valueOf(plugin.getPlayerManager().onlineWizards()));
    }

    private String padEntry(int i) {
        return String.format("%02d", i) + "§r";
    }

    public void refreshAll() {
        if (!enabled) return;
        for (var mp : plugin.getPlayerManager().all()) {
            Player p = mp.getPlayer();
            if (p != null && p.isOnline()) apply(p);
        }
    }

    public void clear(@NotNull Player player) {
        player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }
}
