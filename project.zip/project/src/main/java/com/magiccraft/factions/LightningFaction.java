package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Particle;
import org.bukkit.Sound;

/** Lightning faction. */
public class LightningFaction extends AbstractFaction {
    public LightningFaction(MagicPlugin plugin) {
        super(plugin, FactionType.LIGHTNING, Particle.ELECTRIC_SPARK, Sound.ENTITY_LIGHTNING_BOLT_THUNDER);
    }
}
