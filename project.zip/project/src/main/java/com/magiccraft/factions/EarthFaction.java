package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Particle;
import org.bukkit.Sound;

/** Earth faction. */
public class EarthFaction extends AbstractFaction {
    public EarthFaction(MagicPlugin plugin) {
        super(plugin, FactionType.EARTH, Particle.HAPPY_VILLAGER, Sound.BLOCK_STONE_PLACE);
    }
}
