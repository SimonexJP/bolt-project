package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Shared base for config-driven factions. Reads display name, description,
 * wand, particles, sounds, and the level→spells progression from factions.yml.
 *
 * <p>Subclasses only declare their {@link FactionType} and default
 * particle/sound fallbacks; all behavior comes from config.
 */
public abstract class AbstractFaction implements Faction {

    private final MagicPlugin plugin;
    private final FactionType type;
    private final Particle defaultParticle;
    private final Sound defaultSound;

    protected AbstractFaction(MagicPlugin plugin, FactionType type, Particle defaultParticle, Sound defaultSound) {
        this.plugin = plugin;
        this.type = type;
        this.defaultParticle = defaultParticle;
        this.defaultSound = defaultSound;
    }

    protected ConfigurationSection section() {
        return plugin.getFactionManager().section(type);
    }

    @Override
    public @NotNull FactionType getType() { return type; }

    @Override
    public @NotNull String getDisplayName() {
        return section().getString("display-name", type.name());
    }

    @Override
    public @NotNull String getDescription() {
        return section().getString("description", "");
    }

    @Override
    public @NotNull Particle getParticle() {
        return FactionManager.particle(section().getString("particle", ""), defaultParticle);
    }

    @Override
    public @NotNull Sound getSound() {
        return FactionManager.sound(section().getString("sound", ""), defaultSound);
    }

    @Override
    public @NotNull String getWandMaterial() {
        return section().getString("wand.material", "STICK");
    }

    @Override
    public @NotNull String getWandDisplayName() {
        return section().getString("wand.display-name", type.name() + " Wand");
    }

    @Override
    public int getWandCustomModelData() {
        return section().getInt("wand.custom-model-data", 0);
    }

    @Override
    public @NotNull List<String> getWandLore() {
        return section().getStringList("wand.lore");
    }

    @Override
    public @NotNull List<String> getSpellsAtLevel(int level) {
        ConfigurationSection spells = section().getConfigurationSection("spells");
        if (spells == null) return List.of();
        Map<Integer, String> sorted = new TreeMap<>();
        for (String key : spells.getKeys(false)) {
            try {
                int lvl = Integer.parseInt(key);
                if (lvl <= level) sorted.put(lvl, spells.getString(key));
            } catch (NumberFormatException ignored) {}
        }
        return new ArrayList<>(sorted.values());
    }

    @Override
    public void spawnAmbientParticles(@NotNull Player player) {
        Particle particle = getParticle();
        try {
            player.getWorld().spawnParticle(particle, player.getLocation().add(0, 1, 0), 3, 0.4, 0.6, 0.4, 0.01);
        } catch (Exception ignored) {
            // Some particle types require extra data; swallow to avoid spam.
        }
    }

    @Override
    public void playSound(@NotNull Location location) {
        location.getWorld().playSound(location, getSound(), 1f, 1f);
    }
}
