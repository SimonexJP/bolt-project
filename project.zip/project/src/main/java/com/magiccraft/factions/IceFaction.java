package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Particle;
import org.bukkit.Sound;

/** Ice faction. */
public class IceFaction extends AbstractFaction {
    public IceFaction(MagicPlugin plugin) {
        super(plugin, FactionType.ICE, Particle.SNOWFLAKE, Sound.BLOCK_GLASS_BREAK);
    }
}
