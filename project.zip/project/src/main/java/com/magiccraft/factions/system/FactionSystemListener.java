package com.magiccraft.factions.system;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Bukkit {@link Listener} that integrates the faction systems with the game:
 * <ul>
 *   <li><b>Faction chat</b> — intercepts {@link AsyncPlayerChatEvent} for players
 *       who have toggled faction chat mode and routes the message to faction
 *       members only.</li>
 *   <li><b>War kill tracking</b> — on {@link PlayerDeathEvent}, records kills
 *       in active faction wars and the monthly event.</li>
 *   <li><b>Territory bonuses</b> — provides a hook for applying territory
 *       bonus multipliers (e.g., to XP or mana gains).</li>
 * </ul>
 */
public class FactionSystemListener implements Listener {

    private final MagicPlugin plugin;
    private final FactionSystemManager manager;

    public FactionSystemListener(@NotNull MagicPlugin plugin, @NotNull FactionSystemManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    // ── Faction chat ──

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(@NotNull AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!manager.isInFactionChat(player.getUniqueId())) return;

        MagicPlayer mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) return;

        PlayerData data = mp.getData();
        FactionType faction = data.getFaction();
        if (faction == null) {
            // Player has no faction — remove from faction chat and let normal chat proceed
            manager.removeFromFactionChat(player.getUniqueId());
            player.sendMessage(plugin.getMessages().get("factionsystem.chat-no-faction"));
            return;
        }

        // Cancel the normal chat event and route to faction members only
        event.setCancelled(true);

        String formatted = manager.formatFactionChat(faction, player.getName(), event.getMessage());
        if (formatted == null) return;

        // Send to all online faction members
        for (Player member : manager.getOnlineFactionMembers(faction)) {
            member.sendMessage(formatted);
        }

        // Log to console
        plugin.getLogger().info("[FactionChat/" + faction.name() + "] " + player.getName() + ": " + event.getMessage());
    }

    // ── War kill tracking ──

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDeath(@NotNull PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        if (killer == null || killer.equals(victim)) return;

        MagicPlayer victimMp = plugin.getPlayerManager().getOrNull(victim);
        MagicPlayer killerMp = plugin.getPlayerManager().getOrNull(killer);

        if (victimMp == null || killerMp == null) return;

        FactionType victimFaction = victimMp.getData().getFaction();
        FactionType killerFaction = killerMp.getData().getFaction();

        if (victimFaction == null || killerFaction == null) return;
        if (victimFaction == killerFaction) return; // same faction — no war tracking

        // Record kill in active war
        boolean recorded = manager.recordWarKill(killerFaction, victimFaction);
        if (recorded) {
            // Also record in monthly event if active
            if (manager.isMonthlyEventActive()) {
                manager.recordMonthlyKill(killerFaction);
            }
        }
    }

    // ── Cleanup on quit ──

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(@NotNull PlayerQuitEvent event) {
        Player player = event.getPlayer();
        // Remove from faction chat mode on disconnect
        manager.removeFromFactionChat(player.getUniqueId());
    }

    // ── Territory bonus hook ──

    /**
     * Returns the territory bonus multiplier for a player at their current location.
     * This can be called by other systems (e.g., XP, mana) to apply the bonus.
     *
     * <p>If the player is in a faction's territory, returns that faction's bonus
     * multiplier. Otherwise returns 1.0.
     *
     * @param player the player to check
     * @return the bonus multiplier (1.0 = no bonus)
     */
    public double getTerritoryBonusForPlayer(@NotNull Player player) {
        if (!plugin.getConfigManager().get("factionsystem.yml").get().getBoolean("territory.enabled", true)) {
            return 1.0;
        }

        FactionType owner = manager.getTerritoryOwner(player.getLocation());
        if (owner == null) return 1.0;

        return manager.getTerritoryBonus(owner);
    }

    /**
     * Applies the territory bonus to a base value for a player.
     * Convenience method for other systems.
     *
     * @param player the player
     * @param baseValue the base value (e.g., XP amount)
     * @return the value multiplied by the territory bonus
     */
    public double applyTerritoryBonus(@NotNull Player player, double baseValue) {
        return baseValue * getTerritoryBonusForPlayer(player);
    }
}
