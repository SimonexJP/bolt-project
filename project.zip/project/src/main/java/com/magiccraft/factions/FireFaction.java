package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Particle;
import org.bukkit.Sound;

/** Fire faction. */
public class FireFaction extends AbstractFaction {
    public FireFaction(MagicPlugin plugin) {
        super(plugin, FactionType.FIRE, Particle.FLAME, Sound.ENTITY_BLAZE_SHOOT);
    }
}
