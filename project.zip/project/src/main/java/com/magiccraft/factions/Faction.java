package com.magiccraft.factions;

import com.magiccraft.core.enums.FactionType;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Contract for a magical faction. Each faction defines its flavor
 * (particles, sounds, wand) and the spell ids it unlocks per level.
 *
 * <p>To add a new faction, implement this interface, register it in
 * {@code FactionManager}, and add an entry to {@code factions.yml}.
 */
public interface Faction {

    @NotNull FactionType getType();

    /** Display name with color codes, e.g. {@code "&bIce"}. */
    @NotNull String getDisplayName();

    /** Short lore-style description shown in the faction selection GUI. */
    @NotNull String getDescription();

    /** The particle used for faction effects. */
    @NotNull Particle getParticle();

    /** The sound played on faction-specific events (join, level up). */
    @NotNull Sound getSound();

    /** Wand material name (Bukkit Material name). */
    @NotNull String getWandMaterial();

    /** Wand display name with color codes. */
    @NotNull String getWandDisplayName();

    /** Custom model data for resource-pack support, or 0 for none. */
    int getWandCustomModelData();

    /** Wand lore lines (already color-coded; {owner} replaced at creation). */
    @NotNull List<String> getWandLore();

    /**
     * Returns the list of spell ids unlocked at the given level (inclusive).
     * The order defines slot assignment for click combinations.
     */
    @NotNull List<String> getSpellsAtLevel(int level);

    /** Spawns ambient faction particles at the player's location. */
    void spawnAmbientParticles(@NotNull Player player);

    /** Plays the faction sound at the given location. */
    void playSound(@NotNull Location location);
}
