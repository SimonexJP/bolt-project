package com.magiccraft.factions.system;

import com.magiccraft.MagicPlugin;
import com.magiccraft.commands.SafeCommandExecutor;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Command executor for {@code /fazione} — the faction systems command.
 *
 * <p>Subcommands:
 * <ul>
 *   <li>{@code /fazione hq} — teleport to faction HQ</li>
 *   <li>{@code /fazione chat} — toggle faction chat mode</li>
 *   <li>{@code /fazione war <faction>} — declare war (leader only)</li>
 *   <li>{@code /fazione war end <faction>} — end war (leader only)</li>
 *   <li>{@code /fazione officer <add|remove> <player>} — manage officers (leader only)</li>
 *   <li>{@code /fazione info} — show faction system info</li>
 *   <li>{@code /fazione sethq} — set HQ location (leader only)</li>
 * </ul>
 */
public class FactionSystemCommand extends SafeCommandExecutor {

    private final FactionSystemManager manager;

    public FactionSystemCommand(@NotNull MagicPlugin plugin, @NotNull FactionSystemManager manager) {
        super(plugin);
        this.manager = manager;
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }

        if (args.length == 0) {
            sendHelp(player);
            return;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "hq" -> handleHq(player);
            case "chat" -> handleChat(player);
            case "war" -> handleWar(player, args);
            case "officer" -> handleOfficer(player, args);
            case "info" -> handleInfo(player);
            case "sethq" -> handleSetHq(player);
            default -> sendHelp(player);
        }
    }

    // ── Subcommand handlers ──

    private void handleHq(@NotNull Player player) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;
        manager.teleportToHQ(player, faction);
    }

    private void handleChat(@NotNull Player player) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;

        boolean enabled = manager.toggleFactionChat(player.getUniqueId());
        if (enabled) {
            player.sendMessage(plugin.getMessages().get("factionsystem.chat-enabled"));
        } else {
            player.sendMessage(plugin.getMessages().get("factionsystem.chat-disabled"));
        }
    }

    private void handleWar(@NotNull Player player, @NotNull String[] args) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;

        if (args.length < 2) {
            player.sendMessage(plugin.getMessages().get("factionsystem.war-usage"));
            return;
        }

        // /fazione war end <faction>
        if (args[1].equalsIgnoreCase("end")) {
            if (args.length < 3) {
                player.sendMessage(plugin.getMessages().get("factionsystem.war-end-usage"));
                return;
            }
            if (!manager.hasAuthority(player, faction, FactionSystemManager.OfficerAction.END_WAR)) {
                player.sendMessage(plugin.getMessages().get("factionsystem.no-authority"));
                return;
            }

            Optional<FactionType> target = FactionType.fromId(args[2]);
            if (target.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("unknown-faction", args[2]));
                return;
            }

            if (!manager.isAtWar(faction, target.get())) {
                player.sendMessage(plugin.getMessages().get("factionsystem.not-at-war", target.get().name()));
                return;
            }

            manager.endWar(faction, target.get(), false);
            return;
        }

        // /fazione war <faction>
        if (!manager.hasAuthority(player, faction, FactionSystemManager.OfficerAction.DECLARE_WAR)) {
            player.sendMessage(plugin.getMessages().get("factionsystem.no-authority"));
            return;
        }

        Optional<FactionType> target = FactionType.fromId(args[1]);
        if (target.isEmpty()) {
            player.sendMessage(plugin.getMessages().get("unknown-faction", args[1]));
            return;
        }

        if (target.get() == faction) {
            player.sendMessage(plugin.getMessages().get("factionsystem.war-self"));
            return;
        }

        if (manager.isAtWar(faction, target.get())) {
            player.sendMessage(plugin.getMessages().get("factionsystem.already-at-war", target.get().name()));
            return;
        }

        if (manager.declareWar(faction, target.get())) {
            player.sendMessage(plugin.getMessages().get("factionsystem.war-declared-success", target.get().name()));
        }
    }

    private void handleOfficer(@NotNull Player player, @NotNull String[] args) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;

        if (!manager.hasAuthority(player, faction, FactionSystemManager.OfficerAction.MANAGE_OFFICERS)) {
            player.sendMessage(plugin.getMessages().get("factionsystem.no-authority"));
            return;
        }

        if (args.length < 3) {
            player.sendMessage(plugin.getMessages().get("factionsystem.officer-usage"));
            return;
        }

        String action = args[1].toLowerCase();
        String targetName = args[2];

        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            player.sendMessage(plugin.getMessages().get("player-not-found", targetName));
            return;
        }

        // Verify target is in the same faction
        MagicPlayer targetMp = plugin.getPlayerManager().getOrNull(target);
        if (targetMp == null || targetMp.getData().getFaction() != faction) {
            player.sendMessage(plugin.getMessages().get("factionsystem.officer-not-in-faction", targetName));
            return;
        }

        UUID targetUuid = target.getUniqueId();

        switch (action) {
            case "add" -> {
                // Can't add the leader as an officer
                if (manager.isLeader(target, faction)) {
                    player.sendMessage(plugin.getMessages().get("factionsystem.officer-is-leader", targetName));
                    return;
                }
                if (manager.addOfficer(faction, targetUuid)) {
                    player.sendMessage(plugin.getMessages().get("factionsystem.officer-added", targetName));
                    target.sendMessage(plugin.getMessages().get("factionsystem.officer-promoted", faction.name()));
                } else {
                    player.sendMessage(plugin.getMessages().get("factionsystem.officer-max-reached"));
                }
            }
            case "remove" -> {
                if (manager.removeOfficer(faction, targetUuid)) {
                    player.sendMessage(plugin.getMessages().get("factionsystem.officer-removed", targetName));
                    target.sendMessage(plugin.getMessages().get("factionsystem.officer-demoted", faction.name()));
                } else {
                    player.sendMessage(plugin.getMessages().get("factionsystem.officer-not-officer", targetName));
                }
            }
            default -> player.sendMessage(plugin.getMessages().get("factionsystem.officer-usage"));
        }
    }

    private void handleInfo(@NotNull Player player) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;

        player.sendMessage(plugin.getMessages().raw("factionsystem.info-header", faction.name()));

        // Leader
        UUID leader = manager.getLeader(faction);
        String leaderName = leader != null ? Bukkit.getOfflinePlayer(leader).getName() : "None";
        player.sendMessage(plugin.getMessages().raw("factionsystem.info-leader",
                leaderName != null ? leaderName : "Unknown"));

        // Officers
        var officerUuids = manager.getOfficers(faction);
        List<String> officerNames = new ArrayList<>();
        for (UUID u : officerUuids) {
            String name = Bukkit.getOfflinePlayer(u).getName();
            officerNames.add(name != null ? name : u.toString().substring(0, 8));
        }
        player.sendMessage(plugin.getMessages().raw("factionsystem.info-officers",
                officerNames.isEmpty() ? "None" : String.join(", ", officerNames)));

        // HQ
        FactionSystemManager.HQLocation hq = manager.getHQLocation(faction);
        if (hq != null) {
            player.sendMessage(plugin.getMessages().raw("factionsystem.info-hq",
                    hq.world, hq.x, hq.y, hq.z));
        } else {
            player.sendMessage(plugin.getMessages().raw("factionsystem.info-hq-none"));
        }

        // Territory bonus
        double bonus = manager.getTerritoryBonus(faction);
        player.sendMessage(plugin.getMessages().raw("factionsystem.info-territory", bonus));

        // Active wars
        var wars = manager.getActiveWars();
        if (wars.isEmpty()) {
            player.sendMessage(plugin.getMessages().raw("factionsystem.info-wars-none"));
        } else {
            for (var war : wars) {
                if (war.attacker == faction || war.defender == faction) {
                    FactionType opponent = war.attacker == faction ? war.defender : war.attacker;
                    int myKills = war.attacker == faction ? war.attackerKills : war.defenderKills;
                    int enemyKills = war.attacker == faction ? war.defenderKills : war.attackerKills;
                    player.sendMessage(plugin.getMessages().raw("factionsystem.info-war",
                            opponent.name(), myKills, enemyKills));
                }
            }
        }

        // Monthly event
        if (manager.isMonthlyEventActive()) {
            int score = manager.getMonthlyScore(faction);
            player.sendMessage(plugin.getMessages().raw("factionsystem.info-monthly", score));
        } else {
            player.sendMessage(plugin.getMessages().raw("factionsystem.info-monthly-inactive"));
        }
    }

    private void handleSetHq(@NotNull Player player) {
        FactionType faction = getFactionOrWarn(player);
        if (faction == null) return;

        if (!manager.hasAuthority(player, faction, FactionSystemManager.OfficerAction.SET_HQ)) {
            player.sendMessage(plugin.getMessages().get("factionsystem.no-authority"));
            return;
        }

        manager.setHQLocation(faction, player.getLocation());
        player.sendMessage(plugin.getMessages().get("factionsystem.sethq-success"));
    }

    // ── Helpers ──

    /**
     * Gets the player's faction or sends an error message and returns null.
     */
    private @Nullable FactionType getFactionOrWarn(@NotNull Player player) {
        MagicPlayer mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) {
            player.sendMessage(plugin.getMessages().get("player-data-loading"));
            return null;
        }
        PlayerData data = mp.getData();
        if (data.getFaction() == null) {
            player.sendMessage(plugin.getMessages().get("factionsystem.no-faction"));
            return null;
        }
        return data.getFaction();
    }

    private void sendHelp(@NotNull Player player) {
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-header"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-hq"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-chat"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-war"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-war-end"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-officer"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-info"));
        player.sendMessage(plugin.getMessages().raw("factionsystem.help-sethq"));
    }

    // ── Tab completion ──

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return filter(Arrays.asList("hq", "chat", "war", "officer", "info", "sethq"), args[0]);
        }

        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "war" -> filter(Arrays.asList("end"), args[1]);
                case "officer" -> filter(Arrays.asList("add", "remove"), args[1]);
                default -> List.of();
            };
        }

        if (args.length == 3) {
            if (args[0].equalsIgnoreCase("war") && !args[1].equalsIgnoreCase("end")) {
                // /fazione war <faction>
                return filter(factionNames(), args[2]);
            }
            if (args[0].equalsIgnoreCase("war") && args[1].equalsIgnoreCase("end")) {
                // /fazione war end <faction>
                return filter(factionNames(), args[2]);
            }
            if (args[0].equalsIgnoreCase("officer")) {
                // /fazione officer <add|remove> <player>
                return filter(onlinePlayerNames(), args[2]);
            }
        }

        return List.of();
    }

    private @NotNull List<String> filter(@NotNull List<String> options, @NotNull String prefix) {
        String lower = prefix.toLowerCase();
        return options.stream()
                .filter(s -> s.toLowerCase().startsWith(lower))
                .collect(Collectors.toList());
    }

    private @NotNull List<String> factionNames() {
        return Arrays.stream(FactionType.values())
                .map(Enum::name)
                .map(String::toLowerCase)
                .collect(Collectors.toList());
    }

    private @NotNull List<String> onlinePlayerNames() {
        return Bukkit.getOnlinePlayers().stream()
                .map(Player::getName)
                .collect(Collectors.toList());
    }
}
