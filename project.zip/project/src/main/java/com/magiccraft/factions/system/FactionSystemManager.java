package com.magiccraft.factions.system;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.MagicPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages all advanced faction systems: HQ locations, private faction chat,
 * faction wars, territory bonuses, leaders/officers, and monthly events.
 *
 * <p>All in-memory state is stored in {@link ConcurrentHashMap}s for thread safety.
 * Persistent data (leaders, officers, HQ locations, war stats) is stored in a
 * dedicated SQLite table ({@code faction_systems}) within the same database file
 * used by the rest of the plugin.
 *
 * <p>Async DB operations use a daemon thread pool. Any Bukkit API access
 * (teleporting, broadcasting) is dispatched to the main thread via
 * {@link MagicPlugin#sync(Runnable)}.
 */
public class FactionSystemManager {

    private final MagicPlugin plugin;
    private final Logger logger;

    // ── In-memory state (thread-safe) ──

    /** Faction leader UUID per faction type. */
    private final Map<FactionType, UUID> leaders = new ConcurrentHashMap<>();

    /** Set of officer UUIDs per faction type. */
    private final Map<FactionType, Set<UUID>> officers = new ConcurrentHashMap<>();

    /** HQ location per faction type. */
    private final Map<FactionType, HQLocation> hqLocations = new ConcurrentHashMap<>();

    /** Active wars keyed by a composite key "FACTION_A|FACTION_B". */
    private final Map<String, WarData> activeWars = new ConcurrentHashMap<>();

    /** Players currently in faction chat mode. */
    private final Set<UUID> factionChatToggled = ConcurrentHashMap.newKeySet();

    /** HQ teleport cooldowns per player UUID → expiry epoch millis. */
    private final Map<UUID, Long> hqCooldowns = new ConcurrentHashMap<>();

    /** Territory bonus multipliers per faction type. */
    private final Map<FactionType, Double> territoryBonuses = new ConcurrentHashMap<>();

    /** Monthly event scores per faction type. */
    private final Map<FactionType, Integer> monthlyScores = new ConcurrentHashMap<>();

    /** Whether the monthly event is currently active. */
    private volatile boolean monthlyEventActive = false;

    /** Monthly event end epoch millis (0 if not running). */
    private volatile long monthlyEventEnd = 0L;

    // ── SQL constants ──

    private static final String CREATE_TABLE_SQL = """
            CREATE TABLE IF NOT EXISTS faction_systems (
                faction VARCHAR(32) PRIMARY KEY,
                leader_uuid VARCHAR(36) NOT NULL DEFAULT '',
                officers TEXT NOT NULL DEFAULT '',
                hq_world VARCHAR(64) NOT NULL DEFAULT '',
                hq_x DOUBLE NOT NULL DEFAULT 0,
                hq_y DOUBLE NOT NULL DEFAULT 0,
                hq_z DOUBLE NOT NULL DEFAULT 0,
                hq_yaw FLOAT NOT NULL DEFAULT 0,
                hq_pitch FLOAT NOT NULL DEFAULT 0,
                war_kills INT NOT NULL DEFAULT 0,
                war_deaths INT NOT NULL DEFAULT 0
            )
            """;

    private static final String LOAD_ALL_SQL = "SELECT * FROM faction_systems";

    private static final String UPSERT_SQL = """
            INSERT INTO faction_systems
                (faction, leader_uuid, officers, hq_world, hq_x, hq_y, hq_z, hq_yaw, hq_pitch, war_kills, war_deaths)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(faction) DO UPDATE SET
                leader_uuid=excluded.leader_uuid, officers=excluded.officers,
                hq_world=excluded.hq_world, hq_x=excluded.hq_x, hq_y=excluded.hq_y,
                hq_z=excluded.hq_z, hq_yaw=excluded.hq_yaw, hq_pitch=excluded.hq_pitch,
                war_kills=excluded.war_kills, war_deaths=excluded.war_deaths
            """;

    // ── Inner types ──

    /** Lightweight serializable HQ location. */
    public static final class HQLocation {
        public final String world;
        public final double x, y, z;
        public final float yaw, pitch;

        public HQLocation(String world, double x, double y, double z, float yaw, float pitch) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
        }

        public @Nullable Location toBukkit() {
            World w = Bukkit.getWorld(world);
            if (w == null) return null;
            return new Location(w, x, y, z, yaw, pitch);
        }

        public static @Nullable HQLocation fromBukkit(@NotNull Location loc) {
            if (loc.getWorld() == null) return null;
            return new HQLocation(loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ(),
                    loc.getYaw(), loc.getPitch());
        }
    }

    /** War data tracking kills for both sides. */
    public static final class WarData {
        public final FactionType attacker;
        public final FactionType defender;
        public int attackerKills;
        public int defenderKills;
        public final long startTime;

        public WarData(FactionType attacker, FactionType defender) {
            this.attacker = attacker;
            this.defender = defender;
            this.attackerKills = 0;
            this.defenderKills = 0;
            this.startTime = System.currentTimeMillis();
        }

        public String key() {
            return warKey(attacker, defender);
        }
    }

    // ── Constructor & initialization ──

    public FactionSystemManager(@NotNull MagicPlugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }

    /**
     * Initializes the manager: creates the DB table and loads all persisted data.
     * Must be called on enable (async-safe).
     */
    public CompletableFuture<Void> init() {
        return CompletableFuture.runAsync(() -> {
            createTable();
            loadAllFromDb();
            loadTerritoryBonuses();
            logger.info("FactionSystemManager initialized.");
        }).exceptionally(ex -> {
            logger.log(Level.SEVERE, "Failed to initialize FactionSystemManager", ex);
            return null;
        });
    }

    // ── Config access ──

    public YamlConfig config() {
        return plugin.getConfigManager().get(ConfigManager.FACTION_SYSTEM);
    }

    private double hqTeleportCost() {
        return config().get().getDouble("hq.teleport-cost", 0.0);
    }

    private int hqCooldownSeconds() {
        return config().get().getInt("hq.cooldown-seconds", 60);
    }

    private boolean hqInstantTeleport() {
        return config().get().getBoolean("hq.instant-teleport", false);
    }

    private int hqWarmupTicks() {
        return config().get().getInt("hq.warmup-ticks", 60);
    }

    private boolean hqCancelOnDamage() {
        return config().get().getBoolean("hq.cancel-on-damage", true);
    }

    private boolean chatEnabled() {
        return config().get().getBoolean("chat.enabled", true);
    }

    private String chatFormat() {
        return config().get().getString("chat.format", "&8[&7{faction}&8] &r{player}&8: &f{message}");
    }

    private int warDurationHours() {
        return config().get().getInt("war.duration-hours", 24);
    }

    private int warKillPoints() {
        return config().get().getInt("war.kill-points", 10);
    }

    private double warReward() {
        return config().get().getDouble("war.reward", 100.0);
    }

    private int warMinKillsForReward() {
        return config().get().getInt("war.min-kills-for-reward", 5);
    }

    private boolean warBroadcast() {
        return config().get().getBoolean("war.broadcast", true);
    }

    private boolean territoryEnabled() {
        return config().get().getBoolean("territory.enabled", true);
    }

    private double defaultTerritoryMultiplier() {
        return config().get().getDouble("territory.default-multiplier", 1.0);
    }

    private int territoryRadius() {
        return config().get().getInt("territory.territory-radius", 128);
    }

    private int maxOfficers() {
        return config().get().getInt("officer.max-officers", 3);
    }

    private boolean officerCanDeclareWar() {
        return config().get().getBoolean("officer.permissions.declare-war", false);
    }

    private boolean officerCanEndWar() {
        return config().get().getBoolean("officer.permissions.end-war", false);
    }

    private boolean officerCanSetHq() {
        return config().get().getBoolean("officer.permissions.set-hq", false);
    }

    private boolean officerCanManageOfficers() {
        return config().get().getBoolean("officer.permissions.manage-officers", false);
    }

    private boolean monthlyEventEnabled() {
        return config().get().getBoolean("monthly-event.enabled", true);
    }

    private int monthlyEventDurationDays() {
        return config().get().getInt("monthly-event.duration-days", 7);
    }

    private int monthlyEventKillPoints() {
        return config().get().getInt("monthly-event.kill-points", 15);
    }

    private double monthlyEventWinnerReward() {
        return config().get().getDouble("monthly-event.winner-reward", 500.0);
    }

    private boolean monthlyEventBroadcast() {
        return config().get().getBoolean("monthly-event.broadcast", true);
    }

    // ── Leader management ──

    public @Nullable UUID getLeader(@NotNull FactionType faction) {
        return leaders.get(faction);
    }

    public boolean isLeader(@NotNull Player player, @NotNull FactionType faction) {
        UUID leader = leaders.get(faction);
        return leader != null && leader.equals(player.getUniqueId());
    }

    public void setLeader(@NotNull FactionType faction, @NotNull UUID uuid) {
        leaders.put(faction, uuid);
        saveFactionAsync(faction);
    }

    // ── Officer management ──

    public @NotNull Set<UUID> getOfficers(@NotNull FactionType faction) {
        return officers.computeIfAbsent(faction, k -> ConcurrentHashMap.newKeySet());
    }

    public boolean isOfficer(@NotNull Player player, @NotNull FactionType faction) {
        return getOfficers(faction).contains(player.getUniqueId());
    }

    public boolean addOfficer(@NotNull FactionType faction, @NotNull UUID uuid) {
        Set<UUID> set = getOfficers(faction);
        if (set.size() >= maxOfficers()) return false;
        boolean added = set.add(uuid);
        if (added) saveFactionAsync(faction);
        return added;
    }

    public boolean removeOfficer(@NotNull FactionType faction, @NotNull UUID uuid) {
        Set<UUID> set = getOfficers(faction);
        boolean removed = set.remove(uuid);
        if (removed) saveFactionAsync(faction);
        return removed;
    }

    /**
     * Checks if a player has leader-level authority (is the leader, or has the
     * specific officer permission for the given action).
     */
    public boolean hasAuthority(@NotNull Player player, @NotNull FactionType faction, @NotNull OfficerAction action) {
        if (isLeader(player, faction)) return true;
        if (!isOfficer(player, faction)) return false;
        return switch (action) {
            case DECLARE_WAR -> officerCanDeclareWar();
            case END_WAR -> officerCanEndWar();
            case SET_HQ -> officerCanSetHq();
            case MANAGE_OFFICERS -> officerCanManageOfficers();
        };
    }

    public enum OfficerAction {
        DECLARE_WAR, END_WAR, SET_HQ, MANAGE_OFFICERS
    }

    // ── HQ management ──

    public @Nullable HQLocation getHQLocation(@NotNull FactionType faction) {
        return hqLocations.get(faction);
    }

    public void setHQLocation(@NotNull FactionType faction, @NotNull Location loc) {
        HQLocation hq = HQLocation.fromBukkit(loc);
        if (hq != null) {
            hqLocations.put(faction, hq);
            saveFactionAsync(faction);
        }
    }

    /**
     * Teleports a player to their faction's HQ. Handles cooldown and warm-up.
     * Must be called on the main thread.
     *
     * @return true if the teleport was initiated (or scheduled with warm-up).
     */
    public boolean teleportToHQ(@NotNull Player player, @NotNull FactionType faction) {
        HQLocation hq = hqLocations.get(faction);
        if (hq == null) {
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-not-set"));
            return false;
        }

        Location dest = hq.toBukkit();
        if (dest == null) {
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-world-unloaded"));
            return false;
        }

        // Cooldown check
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long expiry = hqCooldowns.get(uuid);
        if (expiry != null && expiry > now) {
            long remaining = (expiry - now) / 1000;
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-cooldown", remaining));
            return false;
        }

        // Set cooldown
        int cd = hqCooldownSeconds();
        if (cd > 0) {
            hqCooldowns.put(uuid, now + (cd * 1000L));
        }

        if (hqInstantTeleport()) {
            player.teleport(dest);
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-teleported"));
            return true;
        }

        // Warm-up teleport
        int warmup = hqWarmupTicks();
        if (warmup <= 0) {
            player.teleport(dest);
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-teleported"));
            return true;
        }

        player.sendMessage(plugin.getMessages().get("factionsystem.hq-warmup", warmup / 20.0));
        final Location finalDest = dest;
        final UUID finalUuid = uuid;
        final boolean cancelOnDamage = hqCancelOnDamage();
        final double healthBefore = player.getHealth();

        // Schedule the actual teleport after warm-up delay
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            if (cancelOnDamage && player.getHealth() < healthBefore) {
                // Player took damage during warm-up — cancel
                player.sendMessage(plugin.getMessages().get("factionsystem.hq-cancelled-damage"));
                // Refund cooldown
                hqCooldowns.remove(finalUuid);
                return;
            }
            player.teleport(finalDest);
            player.sendMessage(plugin.getMessages().get("factionsystem.hq-teleported"));
        }, warmup);

        return true;
    }

    // ── Faction chat ──

    public boolean toggleFactionChat(@NotNull UUID uuid) {
        if (!chatEnabled()) return false;
        if (factionChatToggled.contains(uuid)) {
            factionChatToggled.remove(uuid);
            return false;
        }
        factionChatToggled.add(uuid);
        return true;
    }

    public boolean isInFactionChat(@NotNull UUID uuid) {
        return factionChatToggled.contains(uuid);
    }

    public void removeFromFactionChat(@NotNull UUID uuid) {
        factionChatToggled.remove(uuid);
    }

    /**
     * Sends a faction chat message to all online members of the faction.
     * @return the formatted message, or null if chat is disabled.
     */
    public @Nullable String formatFactionChat(@NotNull FactionType faction, @NotNull String playerName, @NotNull String message) {
        if (!chatEnabled()) return null;
        String factionName = plugin.getFactionManager().get(faction)
                .map(f -> f.getDisplayName())
                .orElse(faction.name());
        String formatted = chatFormat()
                .replace("{faction}", factionName)
                .replace("{player}", playerName)
                .replace("{message}", message);
        return com.magiccraft.util.TextUtil.color(formatted);
    }

    /**
     * Broadcasts a message to all online members of a faction.
     */
    public void broadcastToFaction(@NotNull FactionType faction, @NotNull String message) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            MagicPlayer mp = plugin.getPlayerManager().getOrNull(p);
            if (mp != null && mp.getData().getFaction() == faction) {
                p.sendMessage(message);
            }
        }
    }

    /**
     * Gets all online players in a faction.
     */
    public @NotNull List<Player> getOnlineFactionMembers(@NotNull FactionType faction) {
        List<Player> members = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            MagicPlayer mp = plugin.getPlayerManager().getOrNull(p);
            if (mp != null && mp.getData().getFaction() == faction) {
                members.add(p);
            }
        }
        return members;
    }

    // ── War management ──

    /**
     * Creates a composite war key. The key is always ordered so that
     * the lexicographically smaller faction comes first, ensuring
     * A-vs-B and B-vs-A produce the same key.
     */
    public static String warKey(@NotNull FactionType a, @NotNull FactionType b) {
        return a.name().compareTo(b.name()) <= 0
                ? a.name() + "|" + b.name()
                : b.name() + "|" + a.name();
    }

    public boolean isAtWar(@NotNull FactionType a, @NotNull FactionType b) {
        return activeWars.containsKey(warKey(a, b));
    }

    public @Nullable WarData getWar(@NotNull FactionType a, @NotNull FactionType b) {
        return activeWars.get(warKey(a, b));
    }

    /**
     * Declares war between two factions.
     * @return true if the war was declared, false if already at war or same faction.
     */
    public boolean declareWar(@NotNull FactionType attacker, @NotNull FactionType defender) {
        if (attacker == defender) return false;
        String key = warKey(attacker, defender);
        if (activeWars.containsKey(key)) return false;

        WarData war = new WarData(attacker, defender);
        activeWars.put(key, war);

        if (warBroadcast()) {
            String msg = plugin.getMessages().raw("factionsystem.war-declared",
                    attacker.name(), defender.name());
            Bukkit.broadcastMessage(msg);
        }

        // Schedule auto-end if duration > 0
        int durationHours = warDurationHours();
        if (durationHours > 0) {
            long durationTicks = durationHours * 72000L; // 1 hour = 72000 ticks
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                WarData w = activeWars.get(key);
                if (w != null) {
                    endWar(attacker, defender, true);
                }
            }, durationTicks);
        }

        logger.info("War declared: " + attacker + " vs " + defender);
        return true;
    }

    /**
     * Ends a war between two factions.
     * @param autoEnd true if ended by timeout, false if ended manually.
     * @return true if the war was ended, false if no war existed.
     */
    public boolean endWar(@NotNull FactionType a, @NotNull FactionType b, boolean autoEnd) {
        String key = warKey(a, b);
        WarData war = activeWars.remove(key);
        if (war == null) return false;

        // Determine winner
        FactionType winner;
        if (war.attackerKills > war.defenderKills) {
            winner = war.attacker;
        } else if (war.defenderKills > war.attackerKills) {
            winner = war.defender;
        } else {
            winner = null; // tie
        }

        if (warBroadcast()) {
            String winnerName = winner != null ? winner.name() : "Tie";
            String msg = plugin.getMessages().raw("factionsystem.war-ended",
                    a.name(), b.name(), winnerName);
            Bukkit.broadcastMessage(msg);
        }

        // Distribute rewards
        if (winner != null) {
            int totalKills = war.attackerKills + war.defenderKills;
            if (totalKills >= warMinKillsForReward()) {
                double reward = warReward();
                for (Player p : getOnlineFactionMembers(winner)) {
                    plugin.getLogger().info("War reward for " + p.getName() + ": " + reward);
                    p.sendMessage(plugin.getMessages().get("factionsystem.war-reward", reward));
                }
            }
        }

        logger.info("War ended (" + (autoEnd ? "auto" : "manual") + "): " + a + " vs " + b
                + " — Attacker kills: " + war.attackerKills + ", Defender kills: " + war.defenderKills);
        return true;
    }

    /**
     * Records a kill in an active war. The killer's faction gains kill points.
     * @return true if the kill was recorded in a war.
     */
    public boolean recordWarKill(@NotNull FactionType killerFaction, @NotNull FactionType victimFaction) {
        WarData war = getWar(killerFaction, victimFaction);
        if (war == null) return false;

        if (war.attacker == killerFaction) {
            war.attackerKills++;
        } else {
            war.defenderKills++;
        }

        // Notify faction members
        int points = warKillPoints();
        String killMsg = plugin.getMessages().raw("factionsystem.war-kill",
                killerFaction.name(), victimFaction.name(), points);
        broadcastToFaction(killerFaction, killMsg);

        return true;
    }

    public @NotNull Collection<WarData> getActiveWars() {
        return Collections.unmodifiableCollection(activeWars.values());
    }

    // ── Territory bonuses ──

    /**
     * Loads territory bonus multipliers from config.
     */
    private void loadTerritoryBonuses() {
        territoryBonuses.clear();
        if (!territoryEnabled()) return;

        ConfigurationSection multipliers = config().get().getConfigurationSection("territory.bonus-multipliers");
        if (multipliers != null) {
            for (FactionType ft : FactionType.values()) {
                double mult = multipliers.getDouble(ft.name(), defaultTerritoryMultiplier());
                territoryBonuses.put(ft, mult);
            }
        } else {
            for (FactionType ft : FactionType.values()) {
                territoryBonuses.put(ft, defaultTerritoryMultiplier());
            }
        }
    }

    /**
     * Returns the territory bonus multiplier for a faction (1.0 = no bonus).
     */
    public double getTerritoryBonus(@NotNull FactionType faction) {
        if (!territoryEnabled()) return 1.0;
        return territoryBonuses.getOrDefault(faction, defaultTerritoryMultiplier());
    }

    /**
     * Sets the territory bonus multiplier for a faction (admin override).
     */
    public void setTerritoryBonus(@NotNull FactionType faction, double multiplier) {
        territoryBonuses.put(faction, multiplier);
    }

    /**
     * Checks if a location is within a faction's territory (around their HQ).
     */
    public boolean isInTerritory(@NotNull Location loc, @NotNull FactionType faction) {
        HQLocation hq = hqLocations.get(faction);
        if (hq == null) return false;
        World hqWorld = Bukkit.getWorld(hq.world);
        if (hqWorld == null || !hqWorld.equals(loc.getWorld())) return false;
        double dx = loc.getX() - hq.x;
        double dz = loc.getZ() - hq.z;
        double distanceSq = dx * dx + dz * dz;
        int radius = territoryRadius();
        return distanceSq <= radius * (double) radius;
    }

    /**
     * Returns the faction whose territory the location is in, or null.
     */
    public @Nullable FactionType getTerritoryOwner(@NotNull Location loc) {
        for (FactionType ft : FactionType.values()) {
            if (isInTerritory(loc, ft)) return ft;
        }
        return null;
    }

    // ── Monthly events ──

    /**
     * Starts the monthly faction event.
     */
    public void startMonthlyEvent() {
        if (!monthlyEventEnabled()) return;
        if (monthlyEventActive) return;

        monthlyScores.clear();
        for (FactionType ft : FactionType.values()) {
            monthlyScores.put(ft, 0);
        }
        monthlyEventActive = true;
        int durationDays = monthlyEventDurationDays();
        monthlyEventEnd = System.currentTimeMillis() + (durationDays * 24L * 60L * 60L * 1000L);

        if (monthlyEventBroadcast()) {
            Bukkit.broadcastMessage(plugin.getMessages().raw("factionsystem.monthly-start", durationDays));
        }

        // Schedule auto-end
        long durationTicks = durationDays * 24L * 72000L;
        Bukkit.getScheduler().runTaskLater(plugin, this::endMonthlyEvent, durationTicks);

        logger.info("Monthly faction event started (" + durationDays + " days).");
    }

    /**
     * Ends the monthly faction event and rewards the winning faction.
     */
    public void endMonthlyEvent() {
        if (!monthlyEventActive) return;
        monthlyEventActive = false;

        FactionType winner = null;
        int maxScore = -1;
        for (var entry : monthlyScores.entrySet()) {
            if (entry.getValue() > maxScore) {
                maxScore = entry.getValue();
                winner = entry.getKey();
            }
        }

        if (winner != null && maxScore > 0) {
            double reward = monthlyEventWinnerReward();
            for (Player p : getOnlineFactionMembers(winner)) {
                p.sendMessage(plugin.getMessages().get("factionsystem.monthly-reward", reward));
            }
            if (monthlyEventBroadcast()) {
                Bukkit.broadcastMessage(plugin.getMessages().raw("factionsystem.monthly-winner",
                        winner.name(), maxScore));
            }
        }

        logger.info("Monthly faction event ended. Winner: " + (winner != null ? winner : "None"));
    }

    public boolean isMonthlyEventActive() {
        return monthlyEventActive;
    }

    public int getMonthlyScore(@NotNull FactionType faction) {
        return monthlyScores.getOrDefault(faction, 0);
    }

    /**
     * Adds points to a faction's monthly event score.
     */
    public void addMonthlyScore(@NotNull FactionType faction, int points) {
        if (!monthlyEventActive) return;
        monthlyScores.merge(faction, points, Integer::sum);
    }

    /**
     * Records a kill for the monthly event.
     */
    public void recordMonthlyKill(@NotNull FactionType killerFaction) {
        if (!monthlyEventActive) return;
        addMonthlyScore(killerFaction, monthlyEventKillPoints());
    }

    public @NotNull Map<FactionType, Integer> getMonthlyScores() {
        return Collections.unmodifiableMap(monthlyScores);
    }

    // ── SQLite persistence ──

    /**
     * Gets a JDBC connection from the underlying SQLiteDatabase.
     */
    private @Nullable Connection getConnection() {
        var dbManager = plugin.getDatabaseManager();
        try {
            // Use reflection-free approach: the DatabaseManager wraps SQLiteDatabase
            // We access the connection via the SQLiteDatabase's connection() method.
            var field = com.magiccraft.data.database.DatabaseManager.class.getDeclaredField("backend");
            field.setAccessible(true);
            Object backend = field.get(dbManager);
            if (backend instanceof com.magiccraft.data.database.SQLiteDatabase sqlite) {
                var connMethod = com.magiccraft.data.database.SQLiteDatabase.class.getDeclaredMethod("connection");
                connMethod.setAccessible(true);
                return (Connection) connMethod.invoke(sqlite);
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to obtain SQLite connection for FactionSystemManager", e);
        }
        return null;
    }

    private void createTable() {
        Connection conn = getConnection();
        if (conn == null) return;
        try (Statement st = conn.createStatement()) {
            st.executeUpdate(CREATE_TABLE_SQL);
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to create faction_systems table", e);
        }
    }

    private void loadAllFromDb() {
        Connection conn = getConnection();
        if (conn == null) return;
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(LOAD_ALL_SQL)) {
            while (rs.next()) {
                String factionName = rs.getString("faction");
                FactionType ft;
                try {
                    ft = FactionType.valueOf(factionName);
                } catch (IllegalArgumentException e) {
                    continue;
                }

                // Leader
                String leaderStr = rs.getString("leader_uuid");
                if (leaderStr != null && !leaderStr.isEmpty()) {
                    try {
                        leaders.put(ft, UUID.fromString(leaderStr));
                    } catch (IllegalArgumentException ignored) {}
                }

                // Officers
                String officersStr = rs.getString("officers");
                if (officersStr != null && !officersStr.isEmpty()) {
                    Set<UUID> set = ConcurrentHashMap.newKeySet();
                    for (String s : officersStr.split(",")) {
                        s = s.trim();
                        if (!s.isEmpty()) {
                            try {
                                set.add(UUID.fromString(s));
                            } catch (IllegalArgumentException ignored) {}
                        }
                    }
                    officers.put(ft, set);
                }

                // HQ location
                String hqWorld = rs.getString("hq_world");
                if (hqWorld != null && !hqWorld.isEmpty()) {
                    hqLocations.put(ft, new HQLocation(
                            hqWorld,
                            rs.getDouble("hq_x"),
                            rs.getDouble("hq_y"),
                            rs.getDouble("hq_z"),
                            rs.getFloat("hq_yaw"),
                            rs.getFloat("hq_pitch")
                    ));
                }
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to load faction_systems data", e);
        }
    }

    /**
     * Saves a single faction's data to the database asynchronously.
     */
    public void saveFactionAsync(@NotNull FactionType faction) {
        CompletableFuture.runAsync(() -> saveFactionSync(faction)).exceptionally(ex -> {
            logger.log(Level.SEVERE, "Failed to save faction data for " + faction, ex);
            return null;
        });
    }

    private void saveFactionSync(@NotNull FactionType faction) {
        Connection conn = getConnection();
        if (conn == null) return;

        UUID leader = leaders.get(faction);
        String leaderStr = leader != null ? leader.toString() : "";

        Set<UUID> officerSet = officers.get(faction);
        String officersStr = "";
        if (officerSet != null && !officerSet.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (UUID u : officerSet) {
                if (sb.length() > 0) sb.append(",");
                sb.append(u.toString());
            }
            officersStr = sb.toString();
        }

        HQLocation hq = hqLocations.get(faction);
        String hqWorld = hq != null ? hq.world : "";
        double hqX = hq != null ? hq.x : 0;
        double hqY = hq != null ? hq.y : 0;
        double hqZ = hq != null ? hq.z : 0;
        float hqYaw = hq != null ? hq.yaw : 0;
        float hqPitch = hq != null ? hq.pitch : 0;

        // Aggregate war stats for this faction
        int totalKills = 0;
        int totalDeaths = 0;
        for (WarData war : activeWars.values()) {
            if (war.attacker == faction) {
                totalKills += war.attackerKills;
                totalDeaths += war.defenderKills;
            } else if (war.defender == faction) {
                totalKills += war.defenderKills;
                totalDeaths += war.attackerKills;
            }
        }

        try (PreparedStatement ps = conn.prepareStatement(UPSERT_SQL)) {
            ps.setString(1, faction.name());
            ps.setString(2, leaderStr);
            ps.setString(3, officersStr);
            ps.setString(4, hqWorld);
            ps.setDouble(5, hqX);
            ps.setDouble(6, hqY);
            ps.setDouble(7, hqZ);
            ps.setFloat(8, hqYaw);
            ps.setFloat(9, hqPitch);
            ps.setInt(10, totalKills);
            ps.setInt(11, totalDeaths);
            ps.executeUpdate();
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "Failed to save faction_systems row for " + faction, e);
        }
    }

    /**
     * Saves all faction data to the database. Called on disable.
     */
    public void saveAll() {
        for (FactionType ft : FactionType.values()) {
            saveFactionSync(ft);
        }
        logger.info("FactionSystemManager data saved.");
    }
}
