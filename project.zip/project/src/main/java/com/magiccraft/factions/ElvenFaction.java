package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Particle;
import org.bukkit.Sound;

/** Elven faction. */
public class ElvenFaction extends AbstractFaction {
    public ElvenFaction(MagicPlugin plugin) {
        super(plugin, FactionType.ELVEN, Particle.CHERRY_LEAVES, Sound.BLOCK_AMETHYST_BLOCK_CHIME);
    }
}
