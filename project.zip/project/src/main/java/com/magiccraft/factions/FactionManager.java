package com.magiccraft.factions;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Registry/factory for factions. Reads faction definitions from factions.yml
 * and binds them to {@link Faction} implementations.
 *
 * <p>To add a new faction: implement {@link Faction}, register it in
 * {@link #register(Faction)}, and add a config entry.
 */
public class FactionManager {

    private final MagicPlugin plugin;
    private final Map<FactionType, Faction> factions = new EnumMap<>(FactionType.class);

    public FactionManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(@NotNull Faction faction) {
        factions.put(faction.getType(), faction);
    }

    public void registerDefaults() {
        register(new IceFaction(plugin));
        register(new FireFaction(plugin));
        register(new EarthFaction(plugin));
        register(new LightningFaction(plugin));
        register(new ElvenFaction(plugin));
    }

    public Optional<Faction> get(@Nullable FactionType type) {
        if (type == null) return Optional.empty();
        return Optional.ofNullable(factions.get(type));
    }

    public Collection<Faction> all() {
        return factions.values();
    }

    /** Returns the spell ids for a faction assigned to the four click slots at a level. */
    public List<String> getSlotSpells(@NotNull FactionType type, int level) {
        return get(type).map(f -> f.getSpellsAtLevel(level)).orElse(List.of());
    }

    /** Returns the spell id assigned to a specific slot (1-4) at a level. */
    public Optional<String> getSlotSpell(@NotNull FactionType type, int level, int slot) {
        List<String> spells = getSlotSpells(type, level);
        if (slot < 1 || slot > spells.size()) return Optional.empty();
        return Optional.of(spells.get(slot - 1));
    }

    public YamlConfig factionsConfig() {
        return plugin.getConfigManager().factions();
    }

    /** Helper used by Faction implementations to read their config section. */
    public org.bukkit.configuration.ConfigurationSection section(@NotNull FactionType type) {
        return factionsConfig().get().getConfigurationSection("factions." + type.name());
    }

    /** Resolves a Particle enum from a config string, with a safe default. */
    public static Particle particle(@NotNull String name, @NotNull Particle fallback) {
        try {
            return Particle.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    /** Resolves a Sound enum from a config string, with a safe default. */
    public static Sound sound(@NotNull String name, @NotNull Sound fallback) {
        try {
            return Sound.valueOf(name.toUpperCase());
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }

    public List<String> unlockedSpellsUpTo(@NotNull FactionType type, int level) {
        List<String> result = new ArrayList<>();
        for (int lvl = 1; lvl <= level; lvl++) {
            result.addAll(getSlotSpells(type, lvl));
        }
        return result;
    }
}
