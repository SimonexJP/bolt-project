package com.magiccraft.tasks;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerStatistics;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Central scheduler for periodic tasks: mana regen, action bar, scoreboard,
 * autosave, and playtime tracking. Consolidated to minimize task count.
 */
public class TaskScheduler {

    private final MagicPlugin plugin;
    private long lastPlaytimeTick;

    public TaskScheduler(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        startManaRegen();
        startActionBar();
        startScoreboard();
        startAutosave();
        startPlaytime();
        startTournamentSchedule();
    }

    private void startManaRegen() {
        int period = plugin.getManaManager().regenPeriodTicks();
        new BukkitRunnable() {
            @Override public void run() { plugin.getManaManager().regenAll(); }
        }.runTaskTimer(plugin, period, period);
    }

    private void startActionBar() {
        if (!plugin.getConfigManager().main().get().getBoolean("actionbar.show-mana", true)) return;
        int ticks = plugin.getConfigManager().main().get().getInt("actionbar.refresh-ticks", 10);
        new BukkitRunnable() {
            @Override public void run() {
                for (MagicPlayer mp : plugin.getPlayerManager().all()) {
                    Player p = mp.getPlayer();
                    if (p == null || !p.isOnline()) continue;
                    String bar = plugin.getManaManager().actionBar(p.getUniqueId());
                    if (!bar.isEmpty()) p.sendActionBar(com.magiccraft.util.TextUtil.color(bar));
                }
            }
        }.runTaskTimer(plugin, ticks, ticks);
    }

    private void startScoreboard() {
        if (!plugin.getScoreboard().isEnabled()) return;
        int ticks = plugin.getScoreboard().getRefreshTicks();
        new BukkitRunnable() {
            @Override public void run() { plugin.getScoreboard().refreshAll(); }
        }.runTaskTimer(plugin, ticks, ticks);
    }

    private void startAutosave() {
        int seconds = plugin.getConfigManager().main().get().getInt("general.auto-save-interval-seconds", 120);
        if (seconds <= 0) return;
        new BukkitRunnable() {
            @Override public void run() { plugin.getPlayerManager().saveAll(); }
        }.runTaskTimer(plugin, seconds * 20L, seconds * 20L);
    }

    private void startPlaytime() {
        lastPlaytimeTick = System.currentTimeMillis();
        new BukkitRunnable() {
            @Override public void run() {
                long now = System.currentTimeMillis();
                long delta = now - lastPlaytimeTick;
                lastPlaytimeTick = now;
                for (MagicPlayer mp : plugin.getPlayerManager().all()) {
                    Player p = mp.getPlayer();
                    if (p != null && p.isOnline()) {
                        PlayerStatistics stats = mp.getData().getStatistics();
                        stats.addPlaytime(delta);
                    }
                }
            }
        }.runTaskTimer(plugin, 600L, 600L); // every 30 seconds
    }

    private void startTournamentSchedule() {
        new BukkitRunnable() {
            @Override public void run() {
                try {
                    plugin.getTournamentManager().checkSchedule();
                } catch (Exception e) {
                    plugin.getLogger().warning("Tournament schedule check failed: " + e.getMessage());
                }
            }
        }.runTaskTimer(plugin, 1200L, 1200L); // every minute
    }
}
