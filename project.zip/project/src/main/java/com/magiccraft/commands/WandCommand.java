package com.magiccraft.commands;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** /wand - receive your faction wand. */
public class WandCommand extends SafeCommandExecutor {

    public WandCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null || !mp.hasFaction()) {
            player.sendMessage(plugin.getMessages().get("wand-no-faction"));
            return;
        }
        FactionType type = mp.getData().getFaction();
        plugin.getWandManager().giveWand(player, type);
        player.sendMessage(plugin.getMessages().get("wand-received", type.name()));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        return List.of();
    }
}
