package com.magiccraft.commands;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.gui.GuiManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/** /faction - view or select a faction. */
public class FactionCommand extends SafeCommandExecutor {

    public FactionCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        if (args.length == 0) {
            plugin.getGuiManager().open(player, GuiManager.FACTION);
            return;
        }
        if (args[0].equalsIgnoreCase("select") && args.length == 2) {
            var type = FactionType.fromId(args[1]);
            if (type.isEmpty()) {
                player.sendMessage(plugin.getMessages().get("unknown-faction", args[1]));
                return;
            }
            plugin.getFactionService().joinFaction(player, type.get());
            return;
        }
        if (args[0].equalsIgnoreCase("list")) {
            player.sendMessage(plugin.getMessages().get("faction-list-header"));
            for (var f : plugin.getFactionManager().all()) {
                player.sendMessage(plugin.getMessages().raw("faction-list-entry",
                        f.getDisplayName(), f.getDescription()));
            }
            return;
        }
        plugin.getGuiManager().open(player, GuiManager.FACTION);
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) return List.of("select", "list");
        if (args.length == 2 && args[0].equalsIgnoreCase("select")) {
            return Arrays.stream(FactionType.values()).map(Enum::name).map(String::toLowerCase).collect(Collectors.toList());
        }
        return List.of();
    }
}
