package com.magiccraft.commands;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/** /magicadmin - admin operations. */
public class MagicAdminCommand extends SafeCommandExecutor {

    private static final List<String> SUBS = List.of(
            "reload", "givewand", "setlevel", "addxp", "resetplayer", "setfaction",
            "unlockall", "lockall", "givespell", "removespell",
            "givespellbook", "givetalents", "resettalents", "prestige", "help");

    public MagicAdminCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("magiccraft.admin")) {
            sender.sendMessage(plugin.getMessages().get("no-permission"));
            return;
        }
        if (args.length == 0) {
            if (sender instanceof Player p) plugin.getGuiManager().open(p, "admin");
            else sendHelp(sender);
            return;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.getConfigManager().reloadAll();
                plugin.getMessages().refresh();
                sender.sendMessage(plugin.getMessages().get("reloaded"));
            }
            case "givewand" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                var mp = plugin.getPlayerManager().getOrNull(target);
                if (mp == null || !mp.hasFaction()) {
                    sender.sendMessage(plugin.getMessages().get("wand-no-faction"));
                    return;
                }
                plugin.getWandManager().giveWand(target, mp.getData().getFaction());
                sender.sendMessage(plugin.getMessages().get("admin-give-wand", target.getName(), mp.getData().getFaction().name()));
            }
            case "setlevel" -> {
                Player target = requirePlayer(sender, args);
                int level = requireInt(sender, args, 2);
                if (target == null || level < 0) return;
                plugin.getLevelManager().setLevel(target, level);
                sender.sendMessage(plugin.getMessages().get("admin-set-level", target.getName(), level));
            }
            case "addxp" -> {
                Player target = requirePlayer(sender, args);
                int xp = requireInt(sender, args, 2);
                if (target == null || xp < 0) return;
                plugin.getLevelManager().addXp(target, xp, "admin");
                sender.sendMessage(plugin.getMessages().get("admin-add-xp", xp, target.getName()));
            }
            case "resetplayer" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                plugin.getPlayerManager().reset(target.getUniqueId());
                plugin.getPlayerManager().onJoin(target);
                sender.sendMessage(plugin.getMessages().get("admin-reset", target.getName()));
            }
            case "setfaction" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                if (args.length < 3) {
                    sender.sendMessage(plugin.getMessages().get("unknown-command"));
                    return;
                }
                var type = FactionType.fromId(args[2]);
                if (type.isEmpty()) {
                    sender.sendMessage(plugin.getMessages().get("unknown-faction", args[2]));
                    return;
                }
                plugin.getFactionService().joinFaction(target, type.get(), true);
                sender.sendMessage(plugin.getMessages().get("faction-changed-admin", target.getName(), type.get().name()));
            }
            default -> sendHelp(sender);
        }
        switchExtra(sender, args);

    private void switchExtra(CommandSender sender, String[] args) {
        switch (args[0].toLowerCase()) {
            case "unlockall" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                plugin.getSpellBookManager().unlockAll(target);
                sender.sendMessage(plugin.getMessages().get("admin-unlock-all", target.getName()));
            }
            case "lockall" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                plugin.getSpellBookManager().lockAll(target);
                sender.sendMessage(plugin.getMessages().get("admin-lock-all", target.getName()));
            }
            case "givespell" -> {
                Player target = requirePlayer(sender, args);
                if (target == null || args.length < 3) return;
                plugin.getSpellBookManager().learn(target, args[2]);
                sender.sendMessage(plugin.getMessages().get("admin-give-spell", target.getName(), args[2]));
            }
            case "removespell" -> {
                Player target = requirePlayer(sender, args);
                if (target == null || args.length < 3) return;
                plugin.getSpellBookManager().unlearn(target, args[2]);
                sender.sendMessage(plugin.getMessages().get("admin-remove-spell", target.getName(), args[2]));
            }
            case "givespellbook" -> {
                Player target = requirePlayer(sender, args);
                if (target == null || args.length < 3) return;
                if (plugin.getSpellManager().get(args[2]).isEmpty()) {
                    sender.sendMessage(plugin.getMessages().get("spell-not-found"));
                    return;
                }
                target.getInventory().addItem(plugin.getSpellBookItemManager().createBook(args[2]));
                sender.sendMessage(plugin.getMessages().get("admin-give-spellbook", target.getName(), args[2]));
            }
            case "givetalents" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                var mp = plugin.getPlayerManager().getOrNull(target);
                if (mp == null) return;
                if (plugin.getTalentManager() != null) {
                    plugin.getTalentManager().giveAll(target, mp.getData());
                }
                sender.sendMessage(plugin.getMessages().get("admin-give-talents", target.getName()));
            }
            case "resettalents" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                var mp = plugin.getPlayerManager().getOrNull(target);
                if (mp == null) return;
                mp.getData().clearTalents();
                sender.sendMessage(plugin.getMessages().get("admin-reset-talents", target.getName()));
            }
            case "prestige" -> {
                Player target = requirePlayer(sender, args);
                if (target == null) return;
                if (plugin.getPrestigeManager() != null) {
                    plugin.getPrestigeManager().prestige(target);
                }
                sender.sendMessage(plugin.getMessages().get("admin-prestige", target.getName()));
            }
        }
    }
        for (String line : plugin.getConfigManager().get(ConfigManager.MESSAGES).msgList("admin-help")) {
            sender.sendMessage(line);
        }
    }

    private Player requirePlayer(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(plugin.getMessages().get("unknown-command"));
            return null;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getMessages().get("player-not-found", args[1]));
        }
        return target;
    }

    private int requireInt(CommandSender sender, String[] args, int index) {
        if (args.length <= index) {
            sender.sendMessage(plugin.getMessages().get("unknown-command"));
            return -1;
        }
        try {
            return Integer.parseInt(args[index]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getMessages().get("unknown-command"));
            return -1;
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) return filter(SUBS, args[0]);
        if (args.length == 2 && !args[0].equalsIgnoreCase("reload") && !args[0].equalsIgnoreCase("help")) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("setfaction")) {
            return Arrays.stream(FactionType.values()).map(Enum::name).map(String::toLowerCase)
                    .filter(n -> n.startsWith(args[2].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        return options.stream().filter(o -> o.toLowerCase().startsWith(prefix.toLowerCase())).collect(Collectors.toList());
    }
}
