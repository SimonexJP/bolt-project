package com.magiccraft.commands;

import com.magiccraft.MagicPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * Base class wrapping {@link CommandExecutor#onCommand} in a try-catch so
 * that Bukkit's generic "An unexpected error occurred" message never appears.
 *
 * <p>Subclasses implement {@link #safeExecute(CommandSender, Command, String, String[])}.
 * Any exception is caught, logged with context, and a user-friendly message is sent.
 */
public abstract class SafeCommandExecutor implements CommandExecutor, TabCompleter {

    protected final MagicPlugin plugin;

    protected SafeCommandExecutor(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    protected abstract void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                                        @NotNull String label, @NotNull String[] args);

    @Override
    public final boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                                   @NotNull String label, @NotNull String[] args) {
        try {
            safeExecute(sender, command, label, args);
        } catch (Exception e) {
            plugin.getLogger().severe("Error executing command /" + label + " for " + sender.getName() + ": " + e.getMessage());
            e.printStackTrace();
            sender.sendMessage(plugin.getMessages().get("command-error"));
        }
        return true;
    }

    @Override
    public abstract @Nullable java.util.List<String> onTabComplete(@NotNull CommandSender sender,
                                                                    @NotNull Command command,
                                                                    @NotNull String label,
                                                                    @NotNull String[] args);
}
