package com.magiccraft.commands;

import com.magiccraft.MagicPlugin;
import com.magiccraft.gui.GuiManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;

/** /magic - opens the main menu GUI. */
public class MagicCommand extends SafeCommandExecutor {

    public MagicCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof org.bukkit.entity.Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        plugin.getGuiManager().open(player, GuiManager.MAIN);
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        return Collections.emptyList();
    }
}
