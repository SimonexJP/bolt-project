package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Ice Prison: traps the target in a cage of ice, applying heavy slowness and a frost-walker-style effect. */
public class IcePrisonSpell extends AbstractSpell {

    public IcePrisonSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ice_prison"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().normalize();
        RayTraceResult result = caster.getWorld().rayTraceEntities(
                caster.getEyeLocation(), dir, 18.0, 0.6, e -> e instanceof LivingEntity && !e.equals(caster));
        if (result == null || result.getHitEntity() == null) {
            caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getEyeLocation(), 10, 0.3, 0.3, 0.3, 0.02);
            caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_SNOW_PLACE, 1f, 1f);
            return true;
        }
        LivingEntity target = (LivingEntity) result.getHitEntity();
        Location base = target.getLocation().getBlock().getLocation();

        // Frost-walker-style: freeze the ground around the target.
        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                Block b = base.clone().add(x, -1, z).getBlock();
                if (b.getType().isAir() && b.getRelative(BlockFace.DOWN).getType().isSolid()) {
                    b.setType(org.bukkit.Material.FROSTED_ICE);
                }
            }
        }

        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 6));
        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 200, 2));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 200, 1));

        for (int i = 0; i < 20; i++) {
            double angle = (Math.PI * 2 * i) / 20;
            double rx = base.getX() + 0.5 + Math.cos(angle) * 1.5;
            double rz = base.getZ() + 0.5 + Math.sin(angle) * 1.5;
            for (int y = 0; y <= 3; y++) {
                Location pillar = new Location(target.getWorld(), rx, base.getY() + y, rz);
                target.getWorld().spawnParticle(Particle.SNOWFLAKE, pillar, 3, 0.1, 0.5, 0.1, 0.0);
            }
        }
        target.getWorld().spawnParticle(Particle.CLOUD, target.getLocation().add(0, 2, 0), 30, 1.5, 0.5, 1.5, 0.02);
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_PLACE, 1.5f, 0.5f);
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.7f);
        return true;
    }
}
