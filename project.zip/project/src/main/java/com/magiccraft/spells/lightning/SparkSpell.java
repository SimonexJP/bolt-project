package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Spark: small lightning strike at the target entity. */
public class SparkSpell extends AbstractSpell {

    public SparkSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "spark"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getTargetBlockExact(30) != null
                ? caster.getTargetBlockExact(30).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(20));
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 40, 0.5, 1, 0.5, 0.1);
        caster.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.5f);
        for (var e : caster.getWorld().getNearbyEntities(loc, 2, 3, 2)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(6.0, caster);
            }
        }
        return true;
    }
}
