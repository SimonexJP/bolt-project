package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Frozen Spear: launches a fast snowball with an ice trail and high damage on hit. */
public class FrozenSpearSpell extends AbstractSpell {

    public FrozenSpearSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "frozen_spear"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(3.0);
        Snowball spear = caster.launchProjectile(Snowball.class, dir);
        spear.setShooter(caster);
        spear.setGravity(false);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (spear.isDead() || !spear.isValid() || ticks++ > 60) {
                    cancel();
                    return;
                }
                Location loc = spear.getLocation();
                spear.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 4, 0.1, 0.1, 0.1, 0.02);
                spear.getWorld().spawnParticle(Particle.FIREWORK, loc, 2, 0.05, 0.05, 0.05, 0.0);
                for (var e : loc.getWorld().getNearbyEntities(loc, 0.8, 0.8, 0.8)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(12.0, caster);
                        living.setVelocity(living.getVelocity().add(dir.clone().multiply(0.4)));
                        spear.getWorld().spawnParticle(Particle.SNOWBALL, loc, 20, 0.4, 0.4, 0.4, 0.1);
                        spear.getWorld().playSound(loc, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2f, 0.6f);
                        spear.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getEyeLocation(), 16, 0.3, 0.3, 0.3, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ITEM_TRIDENT_THROW, 1f, 1.8f);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 0.8f, 0.7f);
        return true;
    }
}
