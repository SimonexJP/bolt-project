package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Fire Shield: fire resistance + damage aura. */
public class FireShieldSpell extends AbstractSpell {

    public FireShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "fire_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 1));
        caster.getWorld().spawnParticle(Particle.FLAME, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1f, 1f);
        return true;
    }
}
