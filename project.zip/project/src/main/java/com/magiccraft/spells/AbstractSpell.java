package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;

/**
 * Shared helpers for spell implementations: particle/sound fx and
 * area-of-effect damage application.
 */
public abstract class AbstractSpell implements Spell {

    protected final MagicPlugin plugin;

    protected AbstractSpell(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    protected void spawnParticle(@NotNull Player player, @NotNull Particle particle, int count, double offsetX, double offsetY, double offsetZ, double speed) {
        player.getWorld().spawnParticle(particle, player.getEyeLocation(), count, offsetX, offsetY, offsetZ, speed);
    }

    protected void playSound(@NotNull Player player, @NotNull Sound sound, float pitch) {
        player.getWorld().playSound(player.getLocation(), sound, 1f, pitch);
    }

    /** Damages all living entities within radius of the player, excluding the caster. */
    protected void damageArea(@NotNull Player caster, double radius, double damage) {
        Collection<Entity> nearby = caster.getWorld().getNearbyEntities(caster.getLocation(), radius, radius, radius);
        for (Entity entity : nearby) {
            if (entity.equals(caster)) continue;
            if (entity instanceof LivingEntity living) {
                living.damage(damage, caster);
            }
        }
    }

    /** Launches a small projectile-like effect: spawns a fireball/snowball equivalent. */
    protected void launchProjectile(@NotNull Player caster, @NotNull org.bukkit.entity.SmallFireball projectile, double speed) {
        Vector dir = caster.getLocation().getDirection().multiply(speed);
        projectile.setVelocity(dir);
    }
}
