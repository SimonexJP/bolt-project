package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Healing Bloom: blooms healing flora, regen + health to caster and nearby allies. */
public class HealingBloomSpell extends AbstractSpell {

    public HealingBloomSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "healing_bloom"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 1, 0), 60, 3, 1, 3, 0.1);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 30, 3, 1, 3, 0.1);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.2f, 1.3f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 6, 4, 6)) {
            if (e instanceof Player ally && !e.equals(caster)) {
                ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 120, 1));
                ally.setHealth(Math.min(ally.getMaxHealth(), ally.getHealth() + 6.0));
            }
        }
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 120, 1));
        caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 6.0));
        return true;
    }
}
