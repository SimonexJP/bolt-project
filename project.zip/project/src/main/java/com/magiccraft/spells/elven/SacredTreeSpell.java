package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Sacred Tree: summons a sacred tree effect, healing all nearby allies over time. */
public class SacredTreeSpell extends AbstractSpell {

    public SacredTreeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "sacred_tree"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 4, 0), 150, 2, 4, 2, 0.15);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 60, 3, 4, 3, 0.1);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 0.9f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ >= 5) {
                    cancel();
                    return;
                }
                for (Entity e : caster.getWorld().getNearbyEntities(loc, 8, 6, 8)) {
                    if (e instanceof Player ally) {
                        ally.setHealth(Math.min(ally.getMaxHealth(), ally.getHealth() + 4.0));
                        ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 60, 0));
                    }
                }
                caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 3, 0), 30, 2, 3, 2, 0.1);
            }
        }.runTaskTimer(plugin, 20L, 20L);
        return true;
    }
}
