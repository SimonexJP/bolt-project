package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Glacier Wall: creates a wall of ice that blocks movement, then melts after a few seconds. */
public class GlacierWallSpell extends AbstractSpell {

    public GlacierWallSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "glacier_wall"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location origin = caster.getLocation();
        Vector forward = origin.getDirection().setY(0).normalize();
        Vector right = new Vector(-forward.getZ(), 0, forward.getX());

        int wallWidth = 7;
        int wallHeight = 4;
        int wallDistance = 4;

        for (int w = -wallWidth / 2; w <= wallWidth / 2; w++) {
            for (int h = 0; h < wallHeight; h++) {
                Location loc = origin.clone()
                        .add(forward.clone().multiply(wallDistance))
                        .add(right.clone().multiply(w))
                        .add(0, h, 0);
                Block b = loc.getBlock();
                if (b.getType().isAir()) {
                    b.setType(Material.PACKED_ICE);
                    b.getWorld().spawnParticle(Particle.SNOWFLAKE, b.getLocation().add(0.5, 0.5, 0.5), 4, 0.3, 0.3, 0.3, 0.02);
                }
            }
        }

        caster.getWorld().spawnParticle(Particle.CLOUD, origin.clone().add(forward.clone().multiply(wallDistance)).add(0, 1, 0), 50, 3, 2, 0.5, 0.05);
        caster.getWorld().playSound(origin, Sound.BLOCK_GLASS_PLACE, 1.5f, 0.5f);
        caster.getWorld().playSound(origin, Sound.BLOCK_GLASS_BREAK, 0.8f, 0.6f);

        new BukkitRunnable() {
            @Override
            public void run() {
                for (int w = -wallWidth / 2; w <= wallWidth / 2; w++) {
                    for (int h = 0; h < wallHeight; h++) {
                        Location loc = origin.clone()
                                .add(forward.clone().multiply(wallDistance))
                                .add(right.clone().multiply(w))
                                .add(0, h, 0);
                        Block b = loc.getBlock();
                        if (b.getType() == Material.PACKED_ICE) {
                            b.getWorld().spawnParticle(Particle.SNOWFLAKE, b.getLocation().add(0.5, 0.5, 0.5), 6, 0.3, 0.3, 0.3, 0.05);
                            b.setType(Material.AIR);
                        }
                    }
                }
                caster.getWorld().playSound(origin.clone().add(forward.clone().multiply(wallDistance)), Sound.BLOCK_GLASS_BREAK, 1f, 1.2f);
            }
        }.runTaskLater(plugin, 200L);

        return true;
    }
}
