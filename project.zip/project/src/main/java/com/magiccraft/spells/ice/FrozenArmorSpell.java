package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Frozen Armor: PASSIVE. Grants damage resistance while active, spawns snowflake particles, and slows nearby enemies. */
public class FrozenArmorSpell extends PassiveSpell {

    public FrozenArmorSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "frozen_armor"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1));
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation().add(0, 1, 0), 30, 1, 1.5, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_PLACE, 1f, 1.2f);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation().add(0, 1, 0), 8, 0.8, 1.2, 0.8, 0.02);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 4, 4, 4)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 0));
            }
        }
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.RESISTANCE);
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation().add(0, 1, 0), 20, 0.5, 1, 0.5, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.8f);
    }
}
