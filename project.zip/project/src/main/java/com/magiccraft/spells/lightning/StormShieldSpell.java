package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Storm Shield: speed + resistance buff. */
public class StormShieldSpell extends AbstractSpell {

    public StormShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "storm_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.5f);
        return true;
    }
}
