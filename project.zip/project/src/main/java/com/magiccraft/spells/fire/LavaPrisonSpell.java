package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Lava Prison: traps target entity in lava particles, sets them on fire and slows them. */
public class LavaPrisonSpell extends AbstractSpell {

    public LavaPrisonSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "lava_prison"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        LivingEntity target = null;
        double closestDistance = 20.0;
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 20, 20, 20)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double dist = living.getLocation().distance(caster.getLocation());
                if (dist < closestDistance) {
                    closestDistance = dist;
                    target = living;
                }
            }
        }
        if (target == null) return false;

        final LivingEntity trapped = target;
        Location center = trapped.getLocation();
        caster.getWorld().playSound(center, Sound.BLOCK_LAVA_AMBIENT, 1.5f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 100) {
                    cancel();
                    return;
                }
                Location tLoc = trapped.getLocation();
                double radius = 1.5;
                for (int i = 0; i < 12; i++) {
                    double angle = (2 * Math.PI * i) / 12 + (ticks * 0.1);
                    double x = tLoc.getX() + radius * Math.cos(angle);
                    double z = tLoc.getZ() + radius * Math.sin(angle);
                    Location particleLoc = new Location(caster.getWorld(), x, tLoc.getY() + 1, z);
                    caster.getWorld().spawnParticle(Particle.LAVA, particleLoc, 3, 0.1, 0.3, 0.1, 0.0);
                }
                trapped.setFireTicks(40);
                if (ticks % 20 == 0) {
                    trapped.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1));
                    trapped.damage(3.0, caster);
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
