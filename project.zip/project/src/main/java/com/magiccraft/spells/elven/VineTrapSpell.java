package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Vine Trap: ensnares the nearest target in vines, applying heavy slowness. */
public class VineTrapSpell extends AbstractSpell {

    public VineTrapSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "vine_trap"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : caster.getWorld().getNearbyEntities(loc, 12, 6, 12)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double d = living.getLocation().distanceSquared(loc);
                if (d < best) { best = d; target = living; }
            }
        }
        if (target == null) {
            caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 10, 2, 1, 2, 0.05);
            return false;
        }
        Location tloc = target.getLocation();
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 160, 3));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 160, 0));
        target.getWorld().spawnParticle(Particle.CHERRY_LEAVES, tloc, 50, 0.6, 2, 0.6, 0.1);
        target.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, tloc, 15, 0.6, 2, 0.6, 0.05);
        target.getWorld().playSound(tloc, Sound.BLOCK_ROOTED_DIRT_BREAK, 1f, 0.7f);
        return true;
    }
}
