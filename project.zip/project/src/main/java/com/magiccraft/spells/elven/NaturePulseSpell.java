package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Nature Pulse: a pulse of nature energy that damages enemies and heals allies. */
public class NaturePulseSpell extends AbstractSpell {

    public NaturePulseSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "nature_pulse"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        for (int i = 1; i <= 3; i++) {
            final double r = i * 3.0;
            caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 40, r, 1, r, 0.2);
            caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 30, r, 1, r, 0.15);
        }
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.4f, 0.9f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 9, 5, 9)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                if (e instanceof Player ally) {
                    ally.setHealth(Math.min(ally.getMaxHealth(), ally.getHealth() + 5.0));
                    ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 80, 0));
                } else {
                    living.damage(8.0, caster);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 80, 0));
                }
            }
        }
        caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 5.0));
        return true;
    }
}
