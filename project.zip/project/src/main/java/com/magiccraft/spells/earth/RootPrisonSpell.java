package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Root Prison: roots the target in place with slowness and mining fatigue. */
public class RootPrisonSpell extends AbstractSpell {

    public RootPrisonSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "root_prison"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(15) != null
                ? caster.getTargetBlockExact(15).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(10));
        caster.getWorld().playSound(target, Sound.BLOCK_ROOTED_DIRT_PLACE, 1.5f, 0.5f);
        caster.getWorld().playSound(target, Sound.BLOCK_ROOTS_BREAK, 1f, 0.6f);

        boolean hit = false;
        for (var e : caster.getWorld().getNearbyEntities(target, 2.5, 3, 2.5)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 160, 4));
                living.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 160, 2));
                living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 160, 1));
                living.damage(4.0, caster);
                living.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
                hit = true;

                for (int i = 0; i < 8; i++) {
                    Location ring = living.getLocation().add(0, 0.5 * (i % 4), 0);
                    caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, ring, 10, 0.8, 0.5, 0.8, 0.0);
                }
            }
        }

        if (!hit) {
            for (int i = 0; i < 3; i++) {
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, target.clone().add(0, i, 0), 15, 1, 0.3, 1, 0.02);
            }
        }

        return true;
    }
}
