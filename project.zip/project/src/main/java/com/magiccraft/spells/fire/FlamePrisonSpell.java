package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Flame Prison: surrounds target with fire particles, trapping and damaging over time. */
public class FlamePrisonSpell extends AbstractSpell {

    public FlamePrisonSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "flame_prison"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        LivingEntity target = null;
        double closestDistance = 20.0;
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 20, 20, 20)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double dist = living.getLocation().distance(caster.getLocation());
                if (dist < closestDistance) {
                    closestDistance = dist;
                    target = living;
                }
            }
        }
        if (target == null) return false;

        final LivingEntity imprisoned = target;
        caster.getWorld().playSound(imprisoned.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1.5f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 120 || imprisoned.isDead()) {
                    cancel();
                    return;
                }
                Location tLoc = imprisoned.getLocation();
                double radius = 2.0;
                double height = 3.0;

                // Cage of fire particles
                for (int i = 0; i < 16; i++) {
                    double angle = (2 * Math.PI * i) / 16;
                    for (double h = 0; h <= height; h += 0.5) {
                        double x = tLoc.getX() + radius * Math.cos(angle);
                        double z = tLoc.getZ() + radius * Math.sin(angle);
                        Location cagePoint = new Location(caster.getWorld(), x, tLoc.getY() + h, z);
                        caster.getWorld().spawnParticle(Particle.FLAME, cagePoint, 2, 0.05, 0.05, 0.05, 0.01);
                    }
                }

                imprisoned.setFireTicks(40);

                if (ticks % 20 == 0) {
                    imprisoned.damage(4.0, caster);
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
