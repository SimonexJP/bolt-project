package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Thunderbolt: calls down a real lightning bolt at the target. */
public class ThunderboltSpell extends AbstractSpell {

    public ThunderboltSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "thunderbolt"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(50) != null
                ? caster.getTargetBlockExact(50).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(40));
        caster.getWorld().strikeLightning(target);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target, 100, 2, 3, 2, 0.3);
        caster.getWorld().playSound(target, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.8f);
        for (var e : caster.getWorld().getNearbyEntities(target, 4, 6, 4)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(16.0, caster);
            }
        }
        return true;
    }
}
