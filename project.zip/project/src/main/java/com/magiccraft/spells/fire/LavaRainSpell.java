package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Lava Rain: rains lava particles over a wide area, damaging and igniting enemies. */
public class LavaRainSpell extends AbstractSpell {

    public LavaRainSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "lava_rain"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.4f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 100) {
                    cancel();
                    return;
                }

                double areaRadius = 8.0;
                for (int i = 0; i < 15; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double r = Math.random() * areaRadius;
                    double x = center.getX() + r * Math.cos(angle);
                    double z = center.getZ() + r * Math.sin(angle);
                    Location rainPoint = new Location(caster.getWorld(), x, center.getY() + 12, z);
                    caster.getWorld().spawnParticle(Particle.LAVA, rainPoint, 2, 0.2, 0.0, 0.2, 0.0);
                    caster.getWorld().spawnParticle(Particle.FALLING_LAVA, rainPoint, 1, 0.2, 0.0, 0.2, 0.0);
                }

                if (ticks % 20 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, areaRadius, 12, areaRadius)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(3.0, caster);
                            living.setFireTicks(60);
                        }
                    }
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
