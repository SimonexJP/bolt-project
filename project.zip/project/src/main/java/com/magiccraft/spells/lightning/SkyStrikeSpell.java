package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Sky Strike: calls lightning from above on all nearby enemies. */
public class SkyStrikeSpell extends AbstractSpell {

    private static final double AOE_RADIUS = 15.0;
    private static final double STRIKE_OFFSET = 20.0;
    private static final double DAMAGE = 14.0;
    private static final int STRIKE_DELAY_TICKS = 8;

    public SkyStrikeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "sky_strike"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.5f);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 50, AOE_RADIUS, 2, AOE_RADIUS, 0.1);

        int[] index = {0};
        for (var e : caster.getWorld().getNearbyEntities(center, AOE_RADIUS, AOE_RADIUS, AOE_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                final LivingEntity target = living;
                final int delay = index[0]++ * STRIKE_DELAY_TICKS;

                new BukkitRunnable() {
                    @Override
                    public void run() {
                        if (target.isDead() || !target.isValid()) {
                            cancel();
                            return;
                        }
                        Location strikeLoc = target.getLocation();
                        // Particle beam from sky down to target
                        for (int y = 0; y < STRIKE_OFFSET; y += 2) {
                            Location beam = strikeLoc.clone().add(0, y, 0);
                            caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, beam, 5, 0.1, 0.1, 0.1, 0.05);
                        }
                        caster.getWorld().strikeLightning(strikeLoc);
                        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, strikeLoc, 60, 1, 2, 1, 0.3);
                        caster.getWorld().playSound(strikeLoc, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.8f);
                        target.damage(DAMAGE, caster);
                        cancel();
                    }
                }.runTaskLater(plugin, delay);
            }
        }

        return true;
    }
}
