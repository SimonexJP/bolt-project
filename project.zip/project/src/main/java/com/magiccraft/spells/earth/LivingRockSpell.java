package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Living Rock: summons a rock golem-like effect that damages nearby enemies. */
public class LivingRockSpell extends AbstractSpell {

    public LivingRockSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "living_rock"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(3));
        caster.getWorld().playSound(center, Sound.BLOCK_STONE_PLACE, 2.0f, 0.3f);
        caster.getWorld().playSound(center, Sound.ENTITY_IRON_GOLEM_REPAIR, 1.5f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 200) {
                    cancel();
                    return;
                }

                // Golem body shape: 3x4 block of particles
                for (int x = -1; x <= 1; x++) {
                    for (int z = -1; z <= 1; z++) {
                        for (int y = 0; y <= 3; y++) {
                            Location body = center.clone().add(x, y, z);
                            caster.getWorld().spawnParticle(Particle.CRIT, body, 2, 0.15, 0.15, 0.15, 0.0);
                        }
                    }
                }
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, center.clone().add(0, 3.5, 0), 5, 0.5, 0.2, 0.5, 0.0);

                if (ticks % 15 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 5, 4, 5)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(8.0, caster);
                            Vector away = living.getLocation().toVector().subtract(center.toVector()).normalize().multiply(1.0);
                            living.setVelocity(away.setY(0.5));
                        }
                    }
                    caster.getWorld().playSound(center, Sound.ENTITY_IRON_GOLEM_ATTACK, 1.0f, 0.6f);
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
