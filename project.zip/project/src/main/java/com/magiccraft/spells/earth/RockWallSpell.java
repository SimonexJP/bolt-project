package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Rock Wall: creates a wall of stone particles in front of the caster that blocks enemies. */
public class RockWallSpell extends AbstractSpell {

    public RockWallSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "rock_wall"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location base = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(3));
        Vector right = caster.getLocation().getDirection().setY(0).normalize().crossProduct(new Vector(0, 1, 0));

        caster.getWorld().playSound(base, Sound.BLOCK_STONE_PLACE, 1.5f, 0.5f);

        for (int i = -3; i <= 3; i++) {
            for (int y = 0; y < 4; y++) {
                Location wall = base.clone().add(right.clone().multiply(i)).add(0, y, 0);
                caster.getWorld().spawnParticle(Particle.CLOUD, wall, 10, 0.2, 0.2, 0.2, 0.0);
            }
        }

        new org.bukkit.scheduler.BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 100) {
                    cancel();
                    return;
                }
                for (int i = -3; i <= 3; i++) {
                    for (int y = 0; y < 4; y++) {
                        Location wall = base.clone().add(right.clone().multiply(i)).add(0, y, 0);
                        caster.getWorld().spawnParticle(Particle.CLOUD, wall, 2, 0.1, 0.1, 0.1, 0.0);
                    }
                }
                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(base, 4, 4, 4)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(3.0, caster);
                            living.setVelocity(living.getVelocity().setY(0.3));
                        }
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
