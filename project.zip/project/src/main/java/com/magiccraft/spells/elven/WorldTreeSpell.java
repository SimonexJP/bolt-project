package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.UltimateSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

/** World Tree: ultimate. A massive tree of life heals all allies in a huge radius,
 *  damages all enemies, and triggers a nature explosion. */
public class WorldTreeSpell extends UltimateSpell {

    public WorldTreeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "world_tree"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    protected boolean executeUltimate(@NotNull Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 8, 0), 500, 10, 8, 10, 0.3);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 200, 12, 6, 12, 0.2);
        caster.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 10, 0), 100, 8, 10, 8, 0.1);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 2.0f, 0.6f);
        caster.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.2f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 20, 12, 20)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                if (e instanceof Player ally) {
                    ally.setHealth(Math.min(ally.getMaxHealth(), ally.getHealth() + 20.0));
                    ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 400, 2));
                    ally.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 400, 1));
                } else {
                    living.damage(25.0, caster);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 200, 1));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 200, 0));
                }
            }
        }
        caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 20.0));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 400, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 400, 1));

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 10) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc.clone().add(0, 5, 0), 80, 8, 6, 8, 0.2);
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 40, 10, 5, 10, 0.1);
            }
        }.runTaskTimer(plugin, 10L, 10L);
        return true;
    }
}
