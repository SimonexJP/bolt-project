package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Freeze: freezes the target entity in place with heavy slowness and frost particles. */
public class FreezeSpell extends AbstractSpell {

    public FreezeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "freeze"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().normalize();
        RayTraceResult result = caster.getWorld().rayTraceEntities(
                caster.getEyeLocation(), dir, 16.0, 0.5, e -> e instanceof LivingEntity && !e.equals(caster));
        if (result == null || result.getHitEntity() == null) {
            caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getEyeLocation(), 8, 0.2, 0.2, 0.2, 0.02);
            caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_SNOW_PLACE, 1f, 1.2f);
            return true;
        }
        LivingEntity target = (LivingEntity) result.getHitEntity();
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 140, 5));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 140, -128));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 140, 1));
        target.getWorld().spawnParticle(Particle.SNOWFLAKE, target.getLocation().add(0, 1, 0), 40, 0.5, 1.0, 0.5, 0.1);
        target.getWorld().spawnParticle(Particle.FIREWORK, target.getLocation().add(0, 1, 0), 6, 0.3, 0.6, 0.3, 0.0);
        target.getWorld().playSound(target.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.6f);
        target.getWorld().playSound(target.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2f, 0.8f);
        return true;
    }
}
