package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.util.Vector;

/** Fireball: launches a small fireball. */
public class FireballSpell extends AbstractSpell {

    public FireballSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "fireball"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.0);
        SmallFireball fireball = caster.launchProjectile(SmallFireball.class, dir);
        fireball.setShooter(caster);
        fireball.setIsIncendiary(true);
        caster.getWorld().spawnParticle(Particle.FLAME, caster.getEyeLocation(), 15, 0.3, 0.3, 0.3, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 1f);
        return true;
    }
}
