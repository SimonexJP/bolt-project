package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Fire Tornado: creates a spiraling column of fire particles that moves forward. */
public class FireTornadoSpell extends AbstractSpell {

    public FireTornadoSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "fire_tornado"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector direction = caster.getLocation().getDirection().normalize();
        direction.setY(0);
        Location start = caster.getLocation().add(direction.clone().multiply(2));
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.8f);

        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                if (step > 40) {
                    cancel();
                    return;
                }
                Location base = start.clone().add(direction.clone().multiply(step * 0.5));
                double spiralRadius = 2.0;

                for (int y = 0; y <= 6; y++) {
                    double angle = (step * 0.3) + (y * 0.8);
                    double x = spiralRadius * Math.cos(angle);
                    double z = spiralRadius * Math.sin(angle);
                    Location particleLoc = base.clone().add(x, y, z);
                    caster.getWorld().spawnParticle(Particle.FLAME, particleLoc, 4, 0.1, 0.1, 0.1, 0.02);
                    if (y % 2 == 0) {
                        caster.getWorld().spawnParticle(Particle.LAVA, particleLoc, 1, 0.05, 0.05, 0.05, 0.0);
                    }
                }

                for (var e : caster.getWorld().getNearbyEntities(base, 3.0, 6.0, 3.0)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(4.0, caster);
                        living.setFireTicks(60);
                    }
                }
                step++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
