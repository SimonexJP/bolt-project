package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Meteor Shower: strikes multiple meteor explosions in an area ahead. */
public class MeteorShowerSpell extends AbstractSpell {

    public MeteorShowerSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "meteor_shower"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector direction = caster.getLocation().getDirection().normalize();
        Location baseCenter = caster.getLocation().add(direction.multiply(15));
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.7f);

        new BukkitRunnable() {
            int strikes = 0;

            @Override
            public void run() {
                if (strikes >= 5) {
                    cancel();
                    return;
                }
                double offsetX = (Math.random() - 0.5) * 10;
                double offsetZ = (Math.random() - 0.5) * 10;
                Location strike = baseCenter.clone().add(offsetX, 0, offsetZ);

                caster.getWorld().spawnParticle(Particle.FLAME, strike, 120, 2, 3, 2, 0.3);
                caster.getWorld().spawnParticle(Particle.LAVA, strike, 30, 1, 1, 1, 0.1);
                caster.getWorld().playSound(strike, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.6f);
                caster.getWorld().createExplosion(strike, 3f, false, false);

                for (var e : caster.getWorld().getNearbyEntities(strike, 5, 5, 5)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(12.0, caster);
                        living.setFireTicks(120);
                    }
                }
                strikes++;
            }
        }.runTaskTimer(plugin, 0L, 10L);

        return true;
    }
}
