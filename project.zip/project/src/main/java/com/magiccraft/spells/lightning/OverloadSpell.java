package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Overload: charges up and releases a burst of electricity, AoE damage. */
public class OverloadSpell extends AbstractSpell {

    private static final double CHARGE_TICKS = 40;
    private static final double BURST_RADIUS = 8.0;
    private static final double BURST_DAMAGE = 20.0;

    public OverloadSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "overload"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.4f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= CHARGE_TICKS) {
                    // Release burst
                    Location center = caster.getLocation();
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 200, BURST_RADIUS, BURST_RADIUS, BURST_RADIUS, 0.5);
                    caster.getWorld().spawnParticle(Particle.FLASH, center, 10, 1, 1, 1, 0);
                    caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2f, 1.5f);
                    caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.8f);

                    for (var e : caster.getWorld().getNearbyEntities(center, BURST_RADIUS, BURST_RADIUS, BURST_RADIUS)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(BURST_DAMAGE, caster);
                            // Knockback
                            org.bukkit.util.Vector knock = living.getLocation().toVector()
                                    .subtract(center.toVector()).normalize().multiply(1.5);
                            knock.setY(0.5);
                            living.setVelocity(knock);
                        }
                    }
                    cancel();
                    return;
                }
                ticks++;

                // Charging particles — spiral inward
                double progress = (double) ticks / CHARGE_TICKS;
                double radius = (1.0 - progress) * 3.0 + 0.5;
                for (int i = 0; i < 4; i++) {
                    double angle = (ticks * 0.3) + (i * Math.PI / 2);
                    Location p = caster.getLocation().add(0, 1, 0).add(
                            Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.05, 0.05, 0.05, 0.02);
                }

                if (ticks % 10 == 0) {
                    caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.3f, 0.5f + (float) progress * 1.5f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
