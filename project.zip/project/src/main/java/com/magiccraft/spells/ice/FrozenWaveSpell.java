package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Frozen Wave: sends a wave of ice forward, freezing and damaging enemies in its path. */
public class FrozenWaveSpell extends AbstractSpell {

    public FrozenWaveSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "frozen_wave"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize();
        Location start = caster.getLocation().add(0, 0.5, 0);

        caster.getWorld().playSound(start, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.5f, 0.6f);
        caster.getWorld().playSound(start, Sound.BLOCK_GLASS_BREAK, 1f, 0.8f);

        new BukkitRunnable() {
            int ticks = 0;
            double distance = 0;

            @Override
            public void run() {
                if (ticks++ > 40) {
                    cancel();
                    return;
                }
                distance += 1.0;
                Location waveCenter = start.clone().add(dir.clone().multiply(distance));

                // Spawn a ring of particles perpendicular to direction.
                Vector right = new Vector(-dir.getZ(), 0, dir.getX());
                for (int i = -3; i <= 3; i++) {
                    Location ring = waveCenter.clone().add(right.clone().multiply(i));
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, ring, 4, 0.1, 0.5, 0.1, 0.05);
                    caster.getWorld().spawnParticle(Particle.CLOUD, ring, 2, 0.1, 0.3, 0.1, 0.02);

                    // Freeze the ground.
                    Block b = ring.getBlock().getRelative(BlockFace.DOWN);
                    if (b.getType().isAir() && b.getRelative(BlockFace.DOWN).getType().isSolid()) {
                        b.setType(Material.FROSTED_ICE);
                    }
                }

                for (var e : caster.getWorld().getNearbyEntities(waveCenter, 4, 3, 4)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(6.0, caster);
                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2));
                        living.setVelocity(living.getVelocity().add(dir.clone().multiply(0.3).setY(0.2)));
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
