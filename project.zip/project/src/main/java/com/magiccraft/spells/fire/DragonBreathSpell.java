package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Dragon Breath: cone of fire particles in front of caster, ignites and damages. */
public class DragonBreathSpell extends AbstractSpell {

    public DragonBreathSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "dragon_breath"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector forward = caster.getLocation().getDirection().normalize();
        Location origin = caster.getEyeLocation();
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_ENDER_DRAGON_SHOOT, 1.5f, 0.5f);

        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                if (step > 10) {
                    cancel();
                    return;
                }
                double distance = step * 1.5;
                double coneRadius = 1.0 + (step * 0.6);

                for (int i = 0; i < 20; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double r = Math.random() * coneRadius;
                    double x = r * Math.cos(angle);
                    double z = r * Math.sin(angle);

                    Vector right = new Vector(-forward.getZ(), 0, forward.getX());
                    Vector up = new Vector(0, 1, 0);
                    Location conePoint = origin.clone()
                            .add(forward.clone().multiply(distance))
                            .add(right.clone().multiply(x))
                            .add(up.clone().multiply(z * 0.5));
                    caster.getWorld().spawnParticle(Particle.DRAGON_BREATH, conePoint, 5, 0.1, 0.1, 0.1, 0.02);
                    caster.getWorld().spawnParticle(Particle.FLAME, conePoint, 3, 0.1, 0.1, 0.1, 0.03);
                }

                for (var e : caster.getWorld().getNearbyEntities(
                        origin.clone().add(forward.clone().multiply(distance)), coneRadius, coneRadius, coneRadius)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(5.0, caster);
                        living.setFireTicks(80);
                    }
                }
                step++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
