package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Wind Step: propels the caster forward on a gust of wind with a speed boost. */
public class WindStepSpell extends AbstractSpell {

    public WindStepSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "wind_step"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize().multiply(2.5).setY(0.6);
        caster.setVelocity(dir);
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 2));
        caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation().add(0, 1, 0), 40, 1, 1, 1, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ITEM_ELYTRA_FLYING, 1f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 20 || caster.isOnGround()) {
                    cancel();
                    return;
                }
                Location trail = caster.getLocation().add(0, 1, 0);
                caster.getWorld().spawnParticle(Particle.CLOUD, trail, 5, 0.3, 0.3, 0.3, 0.02);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
