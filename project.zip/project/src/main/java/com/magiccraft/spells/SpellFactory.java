package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import com.magiccraft.managers.SpellManager;
import com.magiccraft.spells.earth.BoulderTossSpell;
import com.magiccraft.spells.earth.EarthquakeSpell;
import com.magiccraft.spells.earth.StoneSkinSpell;
import com.magiccraft.spells.earth.StoneSpikeSpell;
import com.magiccraft.spells.elven.ForestWrathSpell;
import com.magiccraft.spells.elven.HealingTouchSpell;
import com.magiccraft.spells.elven.LeafBurstSpell;
import com.magiccraft.spells.elven.NatureShieldSpell;
import com.magiccraft.spells.fire.FireballSpell;
import com.magiccraft.spells.fire.FireShieldSpell;
import com.magiccraft.spells.fire.FlameBurstSpell;
import com.magiccraft.spells.fire.MeteorSpell;
import com.magiccraft.spells.ice.BlizzardSpell;
import com.magiccraft.spells.ice.FrostNovaSpell;
import com.magiccraft.spells.ice.IceShieldSpell;
import com.magiccraft.spells.ice.IceShardSpell;
import com.magiccraft.spells.lightning.SparkSpell;
import com.magiccraft.spells.lightning.StaticFieldSpell;
import com.magiccraft.spells.lightning.StormShieldSpell;
import com.magiccraft.spells.lightning.ThunderboltSpell;

/**
 * Registers all built-in spells with the {@link SpellManager}.
 * Adding a new spell = add a class + a register line here + a spells.yml entry.
 */
public final class SpellFactory {

    private SpellFactory() {}

    public static void registerAll(MagicPlugin plugin) {
        SpellManager sm = plugin.getSpellManager();
        // Ice
        sm.register(new IceShardSpell(plugin));
        sm.register(new FrostNovaSpell(plugin));
        sm.register(new IceShieldSpell(plugin));
        sm.register(new BlizzardSpell(plugin));
        // Fire
        sm.register(new FireballSpell(plugin));
        sm.register(new FlameBurstSpell(plugin));
        sm.register(new FireShieldSpell(plugin));
        sm.register(new MeteorSpell(plugin));
        // Earth
        sm.register(new StoneSpikeSpell(plugin));
        sm.register(new EarthquakeSpell(plugin));
        sm.register(new StoneSkinSpell(plugin));
        sm.register(new BoulderTossSpell(plugin));
        // Lightning
        sm.register(new SparkSpell(plugin));
        sm.register(new StaticFieldSpell(plugin));
        sm.register(new StormShieldSpell(plugin));
        sm.register(new ThunderboltSpell(plugin));
        // Elven
        sm.register(new LeafBurstSpell(plugin));
        sm.register(new HealingTouchSpell(plugin));
        sm.register(new NatureShieldSpell(plugin));
        sm.register(new ForestWrathSpell(plugin));
    }
}
