package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import com.magiccraft.managers.SpellManager;
import com.magiccraft.spells.earth.*;
import com.magiccraft.spells.elven.*;
import com.magiccraft.spells.fire.*;
import com.magiccraft.spells.ice.*;
import com.magiccraft.spells.lightning.*;

/**
 * Registers all built-in spells with the {@link SpellManager}.
 * Adding a new spell = add a class + a register line here + a spells.yml entry.
 */
public final class SpellFactory {

    private SpellFactory() {}

    public static void registerAll(MagicPlugin plugin) {
        SpellManager sm = plugin.getSpellManager();

        // === ICE (20 spells + 1 passive + 1 ultimate) ===
        sm.register(new IceShardSpell(plugin));
        sm.register(new FreezeSpell(plugin));
        sm.register(new FrostNovaSpell(plugin));
        sm.register(new IcePrisonSpell(plugin));
        sm.register(new FrozenSpearSpell(plugin));
        sm.register(new IceShieldSpell(plugin));
        sm.register(new GlacierWallSpell(plugin));
        sm.register(new BlizzardSpell(plugin));
        sm.register(new SnowStormSpell(plugin));
        sm.register(new PermafrostSpell(plugin));
        sm.register(new IceDashSpell(plugin));
        sm.register(new FrozenArmorSpell(plugin));
        sm.register(new CrystalRainSpell(plugin));
        sm.register(new AbsoluteZeroSpell(plugin));
        sm.register(new IceSpikeSpell(plugin));
        sm.register(new FrozenWaveSpell(plugin));
        sm.register(new MirrorIceSpell(plugin));
        sm.register(new ArcticWindSpell(plugin));
        sm.register(new ColdTouchSpell(plugin));
        sm.register(new FrozenOrbSpell(plugin));
        sm.register(new EternalWinterSpell(plugin));

        // === FIRE (20 spells + 1 passive + 1 ultimate) ===
        sm.register(new FireballSpell(plugin));
        sm.register(new FlameWaveSpell(plugin));
        sm.register(new FlameBurstSpell(plugin));
        sm.register(new InfernoSpell(plugin));
        sm.register(new MeteorSpell(plugin));
        sm.register(new MeteorShowerSpell(plugin));
        sm.register(new PhoenixSpell(plugin));
        sm.register(new FireShieldSpell(plugin));
        sm.register(new LavaPrisonSpell(plugin));
        sm.register(new FireDashSpell(plugin));
        sm.register(new HellExplosionSpell(plugin));
        sm.register(new FireTornadoSpell(plugin));
        sm.register(new BurningChainsSpell(plugin));
        sm.register(new FlameWallSpell(plugin));
        sm.register(new LavaRainSpell(plugin));
        sm.register(new MagmaBurstSpell(plugin));
        sm.register(new FireSpearSpell(plugin));
        sm.register(new DragonBreathSpell(plugin));
        sm.register(new SolarBlastSpell(plugin));
        sm.register(new CrimsonExplosionSpell(plugin));
        sm.register(new FlamePrisonSpell(plugin));
        sm.register(new MoltenArmorSpell(plugin));
        sm.register(new ApocalypseSpell(plugin));

        // === EARTH (20 spells + 2 passives + 1 ultimate) ===
        sm.register(new StoneSpikeSpell(plugin));
        sm.register(new StoneThrowSpell(plugin));
        sm.register(new EarthquakeSpell(plugin));
        sm.register(new RockWallSpell(plugin));
        sm.register(new StoneSkinSpell(plugin));
        sm.register(new NatureShieldSpell(plugin));
        sm.register(new BoulderTossSpell(plugin));
        sm.register(new RootPrisonSpell(plugin));
        sm.register(new StoneSpearSpell(plugin));
        sm.register(new SandstormSpell(plugin));
        sm.register(new CrystalArmorSpell(plugin));
        sm.register(new MountainSlamSpell(plugin));
        sm.register(new MudTrapSpell(plugin));
        sm.register(new NatureGrowthSpell(plugin));
        sm.register(new EarthDashSpell(plugin));
        sm.register(new SpikeFieldSpell(plugin));
        sm.register(new GaiaBlessingSpell(plugin));
        sm.register(new LivingRockSpell(plugin));
        sm.register(new StoneRainSpell(plugin));
        sm.register(new SeismicWaveSpell(plugin));
        sm.register(new TitanSkinSpell(plugin));
        sm.register(new WorldBreakerSpell(plugin));

        // === LIGHTNING (20 spells + 1 ultimate) ===
        sm.register(new SparkSpell(plugin));
        sm.register(new LightningBoltSpell(plugin));
        sm.register(new StaticFieldSpell(plugin));
        sm.register(new ChainLightningSpell(plugin));
        sm.register(new StormShieldSpell(plugin));
        sm.register(new ThunderboltSpell(plugin));
        sm.register(new ThunderstormSpell(plugin));
        sm.register(new FlashStepSpell(plugin));
        sm.register(new StormCageSpell(plugin));
        sm.register(new ElectricSpearSpell(plugin));
        sm.register(new OverloadSpell(plugin));
        sm.register(new LightningDashSpell(plugin));
        sm.register(new EMPSpell(plugin));
        sm.register(new VoltageBurstSpell(plugin));
        sm.register(new ThunderHammerSpell(plugin));
        sm.register(new SkyStrikeSpell(plugin));
        sm.register(new MagneticPullSpell(plugin));
        sm.register(new ArcBeamSpell(plugin));
        sm.register(new IonBlastSpell(plugin));
        sm.register(new TempestSpell(plugin));
        sm.register(new WrathOfZeusSpell(plugin));

        // === ELVEN (20 spells + 2 passives + 1 ultimate) ===
        sm.register(new LeafBurstSpell(plugin));
        sm.register(new NatureArrowSpell(plugin));
        sm.register(new HealingTouchSpell(plugin));
        sm.register(new HealingBloomSpell(plugin));
        sm.register(new NatureShieldSpell(plugin));
        sm.register(new ForestBlessingSpell(plugin));
        sm.register(new VineTrapSpell(plugin));
        sm.register(new ForestWrathSpell(plugin));
        sm.register(new SpiritShotSpell(plugin));
        sm.register(new WindStepSpell(plugin));
        sm.register(new LifeAuraSpell(plugin));
        sm.register(new MoonlightSpell(plugin));
        sm.register(new ThornPrisonSpell(plugin));
        sm.register(new SacredTreeSpell(plugin));
        sm.register(new NaturePulseSpell(plugin));
        sm.register(new WildGrowthSpell(plugin));
        sm.register(new SpiritWolfSpell(plugin));
        sm.register(new ElvenGraceSpell(plugin));
        sm.register(new EmeraldShieldSpell(plugin));
        sm.register(new LeafStormSpell(plugin));
        sm.register(new AncientWisdomSpell(plugin));
        sm.register(new CelestialArrowSpell(plugin));
        sm.register(new ForestGuardianSpell(plugin));
        sm.register(new WorldTreeSpell(plugin));
    }
}
