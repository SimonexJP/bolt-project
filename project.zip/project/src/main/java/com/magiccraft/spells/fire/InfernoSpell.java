package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Inferno: creates a ring of fire particles around caster, damages and ignites nearby enemies. */
public class InfernoSpell extends AbstractSpell {

    public InfernoSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "inferno"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.2f, 0.5f);

        double radius = 5.0;
        for (int i = 0; i < 36; i++) {
            double angle = (2 * Math.PI * i) / 36;
            double x = center.getX() + radius * Math.cos(angle);
            double z = center.getZ() + radius * Math.sin(angle);
            Location ringPoint = new Location(caster.getWorld(), x, center.getY() + 1, z);
            caster.getWorld().spawnParticle(Particle.FLAME, ringPoint, 10, 0.1, 0.5, 0.1, 0.02);
            caster.getWorld().spawnParticle(Particle.LAVA, ringPoint, 2, 0.1, 0.2, 0.1, 0.0);
        }

        for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(10.0, caster);
                living.setFireTicks(140);
            }
        }
        return true;
    }
}
