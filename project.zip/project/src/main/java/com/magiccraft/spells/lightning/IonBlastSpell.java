package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Ion Blast: charged ion explosion, big AoE electric damage. */
public class IonBlastSpell extends AbstractSpell {

    private static final double CHARGE_TICKS = 30;
    private static final double BLAST_RADIUS = 10.0;
    private static final double BLAST_DAMAGE = 25.0;

    public IonBlastSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ion_blast"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(40) != null
                ? caster.getTargetBlockExact(40).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(30));

        caster.getWorld().playSound(target, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.3f, 0.3f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks >= CHARGE_TICKS) {
                    // Detonate
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target, 300, BLAST_RADIUS, BLAST_RADIUS, BLAST_RADIUS, 0.6);
                    caster.getWorld().spawnParticle(Particle.FLASH, target, 15, 2, 2, 2, 0);
                    caster.getWorld().spawnParticle(Particle.EXPLOSION, target, 5, 1, 1, 1, 0);
                    caster.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.8f);
                    caster.getWorld().playSound(target, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 0.5f);

                    for (var e : caster.getWorld().getNearbyEntities(target, BLAST_RADIUS, BLAST_RADIUS, BLAST_RADIUS)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(BLAST_DAMAGE, caster);
                            // Strong knockback from blast center
                            Vector knock = living.getLocation().toVector()
                                    .subtract(target.toVector()).normalize().multiply(2.0);
                            knock.setY(1.0);
                            living.setVelocity(knock);
                        }
                    }
                    cancel();
                    return;
                }
                ticks++;

                // Charging ion particles — converging sphere
                double progress = (double) ticks / CHARGE_TICKS;
                double currentRadius = BLAST_RADIUS * (1.0 - progress);
                for (int i = 0; i < 12; i++) {
                    double theta = Math.random() * Math.PI * 2;
                    double phi = Math.random() * Math.PI;
                    Location p = target.clone().add(
                            currentRadius * Math.sin(phi) * Math.cos(theta),
                            currentRadius * Math.cos(phi),
                            currentRadius * Math.sin(phi) * Math.sin(theta));
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.02, 0.02, 0.02, 0.01);
                }

                if (ticks % 5 == 0) {
                    caster.getWorld().playSound(target, Sound.BLOCK_NOTE_BLOCK_PLING, 0.2f, 0.3f + (float) progress * 2f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
