package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Forest Guardian: summons an iron golem to protect the caster. */
public class ForestGuardianSpell extends AbstractSpell {

    public ForestGuardianSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "forest_guardian"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(2));
        IronGolem golem = caster.getWorld().spawn(loc, IronGolem.class);
        golem.setCustomName("Forest Guardian");
        golem.setCustomNameVisible(true);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 60, 1, 2, 1, 0.1);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 0.7f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 400 || golem.isDead()) {
                    golem.getWorld().spawnParticle(Particle.CHERRY_LEAVES, golem.getLocation(), 30, 1, 2, 1, 0.1);
                    golem.remove();
                    cancel();
                    return;
                }
                LivingEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (Entity e : golem.getWorld().getNearbyEntities(golem.getLocation(), 12, 6, 12)) {
                    if (e instanceof LivingEntity living && !e.equals(caster) && !e.equals(golem) && !(e instanceof IronGolem)) {
                        if (e instanceof Player) continue;
                        double d = living.getLocation().distanceSquared(golem.getLocation());
                        if (d < best) { best = d; nearest = living; }
                    }
                }
                if (nearest != null && best > 9) {
                    golem.setVelocity(nearest.getLocation().toVector().subtract(golem.getLocation().toVector()).normalize().multiply(0.4));
                }
            }
        }.runTaskTimer(plugin, 1L, 10L);
        return true;
    }
}
