package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.util.Vector;

/** Stone Throw: launches a stone projectile that damages on hit. */
public class StoneThrowSpell extends AbstractSpell {

    public StoneThrowSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "stone_throw"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.0);
        Snowball proj = caster.launchProjectile(Snowball.class, dir);
        proj.setShooter(caster);
        proj.setGravity(false);

        caster.getWorld().spawnParticle(Particle.CLOUD, caster.getEyeLocation(), 15, 0.3, 0.3, 0.3, 0.0);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1f, 0.7f);

        new org.bukkit.scheduler.BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (proj.isDead() || ticks > 100) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.CLOUD, proj.getLocation(), 4, 0.1, 0.1, 0.1, 0.0);
                for (var e : proj.getWorld().getNearbyEntities(proj.getLocation(), 1.0, 1.0, 1.0)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(7.0, caster);
                        proj.remove();
                        cancel();
                        return;
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
