package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Solar Blast: charges and releases a bright flash, blinding and damaging nearby enemies. */
public class SolarBlastSpell extends AbstractSpell {

    public SolarBlastSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "solar_blast"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 0.5f, 2.0f);

        new BukkitRunnable() {
            int charge = 0;

            @Override
            public void run() {
                if (charge < 20) {
                    // Charging: gathering bright particles
                    for (int i = 0; i < 10; i++) {
                        double angle = (2 * Math.PI * i) / 10 + (charge * 0.2);
                        double r = 3.0 - (charge * 0.15);
                        Location gather = loc.clone().add(r * Math.cos(angle), 1 + r * 0.3, r * Math.sin(angle));
                        caster.getWorld().spawnParticle(Particle.END_ROD, gather, 3, 0.05, 0.05, 0.05, 0.0);
                        caster.getWorld().spawnParticle(Particle.FLAME, gather, 2, 0.05, 0.05, 0.05, 0.0);
                    }
                    charge++;
                } else {
                    // Release: bright flash
                    caster.getWorld().spawnParticle(Particle.FLASH, loc.clone().add(0, 1, 0), 1, 0, 0, 0, 0);
                    caster.getWorld().spawnParticle(Particle.FLAME, loc, 200, 6, 3, 6, 0.3);
                    caster.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 1.5f);

                    for (var e : caster.getWorld().getNearbyEntities(loc, 8, 8, 8)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(15.0, caster);
                            living.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
                            living.setFireTicks(80);
                        }
                    }
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
