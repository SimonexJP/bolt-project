package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Nature Arrow: fires an arrow trailed by leaf particles. */
public class NatureArrowSpell extends AbstractSpell {

    public NatureArrowSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "nature_arrow"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(3.0);
        Arrow arrow = caster.launchProjectile(Arrow.class, dir);
        arrow.setShooter(caster);
        arrow.setDamage(6.0);
        arrow.setCritical(true);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getEyeLocation(), 20, 0.3, 0.3, 0.3, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (arrow.isDead() || !arrow.isValid() || ticks++ > 60) {
                    cancel();
                    return;
                }
                arrow.getWorld().spawnParticle(Particle.CHERRY_LEAVES, arrow.getLocation(), 4, 0.15, 0.15, 0.15, 0.02);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
