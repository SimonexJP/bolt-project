package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.UltimateSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

/** World Breaker: ULTIMATE - massive earthquake, huge AoE damage, launches all enemies into the air, stone rain. */
public class WorldBreakerSpell extends UltimateSpell {

    public WorldBreakerSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "world_breaker"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    protected boolean executeUltimate(@NotNull Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL, 2.0f, 0.3f);
        caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.2f);
        caster.getWorld().playSound(center, Sound.BLOCK_STONE_BREAK, 2.0f, 0.3f);

        new BukkitRunnable() {
            int phase = 0;

            @Override
            public void run() {
                if (phase > 80) {
                    cancel();
                    return;
                }

                // Phase 0-20: Earthquake shockwaves expanding outward
                if (phase <= 20) {
                    double radius = phase * 1.2;
                    for (int i = 0; i < 40; i++) {
                        double angle = (i * 2 * Math.PI) / 40.0;
                        Location shock = center.clone().add(radius * Math.cos(angle), 0.3, radius * Math.sin(angle));
                        caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, shock, 5, 0.2, 0.5, 0.2, 0.1);
                        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, shock, 3, 0.3, 0.3, 0.3, 0.05);
                    }
                }

                // Phase 10-50: Stone rain
                if (phase >= 10 && phase <= 50) {
                    for (int i = 0; i < 15; i++) {
                        double angle = Math.random() * 2 * Math.PI;
                        double r = Math.random() * 12;
                        double x = center.getX() + r * Math.cos(angle);
                        double z = center.getZ() + r * Math.sin(angle);
                        Location rain = new Location(caster.getWorld(), x, center.getY() + 15, z);
                        caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, rain, 5, 0.3, 0.0, 0.3, 0.3);
                        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, rain, 2, 0.2, 0.0, 0.2, 0.1);
                    }
                }

                // Phase 20: Launch all enemies into the air
                if (phase == 20) {
                    caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 3.0f, 0.2f);
                    for (var e : caster.getWorld().getNearbyEntities(center, 15, 10, 15)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(25.0, caster);
                            living.setVelocity(living.getVelocity().setY(2.5));
                        }
                    }
                }

                // Continuous AoE damage
                if (phase % 5 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 12, 8, 12)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(8.0, caster);
                            Vector away = living.getLocation().toVector().subtract(center.toVector()).setY(0).normalize().multiply(0.8);
                            living.setVelocity(away.setY(0.4));
                        }
                    }
                }

                // Ambient ground particles
                caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, center, 40, 8, 3, 8, 0.2);
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, center, 20, 10, 4, 10, 0.1);

                phase++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
