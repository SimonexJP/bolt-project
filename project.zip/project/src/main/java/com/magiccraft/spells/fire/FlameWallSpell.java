package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Flame Wall: creates a wall of fire particles in front of caster that blocks and damages. */
public class FlameWallSpell extends AbstractSpell {

    public FlameWallSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "flame_wall"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector forward = caster.getLocation().getDirection().normalize();
        forward.setY(0);
        Vector right = new Vector(-forward.getZ(), 0, forward.getX());
        Location wallCenter = caster.getLocation().add(forward.clone().multiply(5));
        caster.getWorld().playSound(wallCenter, Sound.BLOCK_FIRE_AMBIENT, 1.5f, 0.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 200) {
                    cancel();
                    return;
                }

                double wallWidth = 6.0;
                for (double w = -wallWidth; w <= wallWidth; w += 0.5) {
                    for (double h = 0; h <= 3; h += 0.5) {
                        Location wallPoint = wallCenter.clone().add(right.clone().multiply(w)).add(0, h, 0);
                        caster.getWorld().spawnParticle(Particle.FLAME, wallPoint, 2, 0.1, 0.1, 0.1, 0.01);
                    }
                }

                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(wallCenter, wallWidth, 4, 2)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(4.0, caster);
                            living.setFireTicks(60);
                        }
                    }
                }
                ticks += 5;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
