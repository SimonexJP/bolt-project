package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Elven Grace: passive speed and jump boost with drifting leaf particles. */
public class ElvenGraceSpell extends PassiveSpell {

    public ElvenGraceSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "elven_grace"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, false, false, true));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 1, false, false, true));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.4f);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 4, 0.5, 0.8, 0.5, 0.02);
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.SPEED);
        caster.removePotionEffect(PotionEffectType.JUMP_BOOST);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 12, 1, 1, 1, 0.05);
    }
}
