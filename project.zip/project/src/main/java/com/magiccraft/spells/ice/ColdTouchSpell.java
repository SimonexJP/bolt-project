package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Cold Touch: close-range freeze that deals heavy damage and applies heavy slowness to a nearby entity. */
public class ColdTouchSpell extends AbstractSpell {

    public ColdTouchSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "cold_touch"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().normalize();
        RayTraceResult result = caster.getWorld().rayTraceEntities(
                caster.getEyeLocation(), dir, 4.0, 0.8, e -> e instanceof LivingEntity && !e.equals(caster));

        if (result == null || result.getHitEntity() == null) {
            caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getEyeLocation().add(dir.multiply(3)), 10, 0.3, 0.3, 0.3, 0.02);
            caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_SNOW_PLACE, 1f, 1.5f);
            return true;
        }

        LivingEntity target = (LivingEntity) result.getHitEntity();
        Location hit = target.getLocation().add(0, 1, 0);

        target.damage(18.0, caster);
        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 6));
        target.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, -128));
        target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 200, 2));
        target.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 200, 2));
        target.setVelocity(new Vector(0, 0, 0));

        target.getWorld().spawnParticle(Particle.SNOWFLAKE, hit, 50, 0.3, 0.6, 0.3, 0.1);
        target.getWorld().spawnParticle(Particle.FIREWORK, hit, 15, 0.2, 0.4, 0.2, 0.0);
        target.getWorld().spawnParticle(Particle.SNOWBALL, hit, 20, 0.4, 0.5, 0.4, 0.05);
        target.getWorld().playSound(hit, Sound.ENTITY_PLAYER_HURT_FREEZE, 2f, 0.4f);
        target.getWorld().playSound(hit, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.5f);
        target.getWorld().playSound(hit, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 0.8f);

        return true;
    }
}
