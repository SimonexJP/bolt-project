package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.util.Vector;

/** Leaf Burst: fires razor-sharp leaves (snowball projectile). */
public class LeafBurstSpell extends AbstractSpell {

    public LeafBurstSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "leaf_burst"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.2);
        Snowball proj = caster.launchProjectile(Snowball.class, dir);
        proj.setShooter(caster);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getEyeLocation(), 15, 0.3, 0.3, 0.3, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.5f);
        return true;
    }
}
