package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Wolf;
import org.bukkit.scheduler.BukkitRunnable;

/** Spirit Wolf: summons a wolf that attacks nearby enemies. */
public class SpiritWolfSpell extends AbstractSpell {

    public SpiritWolfSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "spirit_wolf"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(2));
        Wolf wolf = caster.getWorld().spawn(loc, Wolf.class);
        wolf.setOwner(caster);
        wolf.setTamed(true);
        wolf.setCustomName("Spirit Wolf");
        wolf.setCustomNameVisible(true);
        caster.getWorld().spawnParticle(Particle.END_ROD, loc, 40, 0.5, 1, 0.5, 0.1);
        caster.getWorld().playSound(loc, Sound.ENTITY_WOLF_AMBIENT, 1f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 200 || wolf.isDead()) {
                    wolf.getWorld().spawnParticle(Particle.END_ROD, wolf.getLocation(), 20, 0.3, 0.5, 0.3, 0.05);
                    wolf.remove();
                    cancel();
                    return;
                }
                wolf.getWorld().spawnParticle(Particle.END_ROD, wolf.getLocation().add(0, 0.5, 0), 3, 0.2, 0.2, 0.2, 0.02);
                LivingEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (Entity e : wolf.getWorld().getNearbyEntities(wolf.getLocation(), 10, 5, 10)) {
                    if (e instanceof LivingEntity living && !e.equals(caster) && !e.equals(wolf) && !(e instanceof Wolf)) {
                        double d = living.getLocation().distanceSquared(wolf.getLocation());
                        if (d < best) { best = d; nearest = living; }
                    }
                }
                if (nearest != null && best > 4) {
                    wolf.setVelocity(nearest.getLocation().toVector().subtract(wolf.getLocation().toVector()).normalize().multiply(0.5));
                }
            }
        }.runTaskTimer(plugin, 1L, 5L);
        return true;
    }
}
