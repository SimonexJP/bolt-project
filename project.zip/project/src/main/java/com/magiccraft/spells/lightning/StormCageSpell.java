package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Storm Cage: traps target in an electric field, damaging over time. */
public class StormCageSpell extends AbstractSpell {

    private static final double RADIUS = 4.0;
    private static final double DAMAGE_PER_TICK = 3.0;
    private static final int DURATION_TICKS = 100;
    private static final int TICK_INTERVAL = 10;

    public StormCageSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "storm_cage"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        LivingEntity target = null;
        double closest = Double.MAX_VALUE;
        for (var e : caster.getWorld().getNearbyEntities(caster.getEyeLocation(), 30, 10, 30)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double dist = living.getLocation().distanceSquared(caster.getEyeLocation());
                if (dist < closest) {
                    closest = dist;
                    target = living;
                }
            }
        }

        if (target == null) {
            caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.5f, 0.5f);
            return false;
        }

        Location center = target.getLocation().clone();
        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.2f);

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= DURATION_TICKS) {
                    cancel();
                    return;
                }
                elapsed += TICK_INTERVAL;

                // Cage particle ring
                for (int i = 0; i < 16; i++) {
                    double angle = (i / 16.0) * Math.PI * 2;
                    Location ring = center.clone().add(
                            Math.cos(angle) * RADIUS, 0.5, Math.sin(angle) * RADIUS);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, ring, 3, 0.05, 0.5, 0.05, 0.02);
                }

                // Pull target back toward center and damage
                if (target.isValid() && !target.isDead()) {
                    Location tLoc = target.getLocation();
                    if (tLoc.distanceSquared(center) > RADIUS * RADIUS) {
                        org.bukkit.util.Vector pull = center.toVector().subtract(tLoc.toVector()).normalize().multiply(0.8);
                        target.setVelocity(pull);
                    }
                    target.damage(DAMAGE_PER_TICK, caster);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);
                }

                if (elapsed == TICK_INTERVAL) {
                    caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5f, 1.5f);
                }
            }
        }.runTaskTimer(plugin, 0L, TICK_INTERVAL);

        return true;
    }
}
