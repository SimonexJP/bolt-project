package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Crystal Rain: rains ice crystals over an area, damaging enemies caught beneath. */
public class CrystalRainSpell extends AbstractSpell {

    public CrystalRainSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "crystal_rain"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(5));
        double radius = 6.0;

        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1.2f, 0.7f);
        caster.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 0.8f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 100) {
                    cancel();
                    return;
                }
                for (int i = 0; i < 10; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * radius;
                    Location loc = center.clone().add(Math.cos(angle) * dist, 12, Math.sin(angle) * dist);
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 2, 0.1, 0.1, 0.1, 0.3);
                    caster.getWorld().spawnParticle(Particle.FIREWORK, loc, 1, 0.05, 0.05, 0.05, 0.1);
                }
                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, radius, 12, radius)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(5.0, caster);
                            living.getWorld().spawnParticle(Particle.SNOWBALL, living.getLocation().add(0, 1, 0), 10, 0.3, 0.6, 0.3, 0.05);
                        }
                    }
                    caster.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 0.5f, 1.8f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
