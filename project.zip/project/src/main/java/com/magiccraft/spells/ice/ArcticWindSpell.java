package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

/** Arctic Wind: a blast of cold wind that pushes enemies back and slows them. */
public class ArcticWindSpell extends AbstractSpell {

    public ArcticWindSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "arctic_wind"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize();
        Location center = caster.getLocation().add(0, 1, 0);
        double radius = 8.0;

        // Cone of wind particles.
        for (int i = 1; i <= 8; i++) {
            Location loc = center.clone().add(dir.clone().multiply(i));
            caster.getWorld().spawnParticle(Particle.CLOUD, loc, 15, 1.5, 0.5, 1.5, 0.1);
            caster.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 10, 1, 0.3, 1, 0.05);
        }

        caster.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_FLAP, 1.5f, 0.8f);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 1f);

        for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                // Only push entities in front of the caster.
                Vector toEntity = living.getLocation().toVector().subtract(center.toVector());
                if (toEntity.dot(dir) > 0) {
                    living.setVelocity(dir.clone().multiply(1.5).setY(0.4));
                    living.damage(5.0, caster);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 0));
                    living.getWorld().spawnParticle(Particle.SNOWFLAKE, living.getLocation().add(0, 1, 0), 15, 0.3, 0.6, 0.3, 0.05);
                }
            }
        }

        return true;
    }
}
