package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Meteor: strikes a large explosion at the target location. */
public class MeteorSpell extends AbstractSpell {

    public MeteorSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "meteor"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(40) != null
                ? caster.getTargetBlockExact(40).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(30));
        caster.getWorld().spawnParticle(Particle.FLAME, target, 200, 3, 3, 3, 0.3);
        caster.getWorld().spawnParticle(Particle.LAVA, target, 50, 1, 1, 1, 0.2);
        caster.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.8f);
        caster.getWorld().createExplosion(target, 4f, false, false);
        for (var e : caster.getWorld().getNearbyEntities(target, 6, 6, 6)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(18.0, caster);
                living.setFireTicks(160);
            }
        }
        return true;
    }
}
