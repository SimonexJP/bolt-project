package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Thunder Hammer: summons lightning at clicked target, heavy damage. */
public class ThunderHammerSpell extends AbstractSpell {

    private static final double RANGE = 60.0;
    private static final double IMPACT_RADIUS = 5.0;
    private static final double DAMAGE = 24.0;

    public ThunderHammerSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "thunder_hammer"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact((int) RANGE) != null
                ? caster.getTargetBlockExact((int) RANGE).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(RANGE * 0.8));

        // Hammer-impact particles — ring expanding outward
        for (int ring = 0; ring < 4; ring++) {
            double r = (ring + 1) * (IMPACT_RADIUS / 4.0);
            for (int i = 0; i < 24; i++) {
                double angle = (i / 24.0) * Math.PI * 2;
                Location p = target.clone().add(
                        Math.cos(angle) * r, 0.2, Math.sin(angle) * r);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 4, 0.05, 0.1, 0.05, 0.15);
            }
        }

        // Double lightning strike for heavy impact
        caster.getWorld().strikeLightning(target);
        caster.getWorld().strikeLightning(target.clone().add(1, 0, 1));

        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target, 150, IMPACT_RADIUS, 4, IMPACT_RADIUS, 0.4);
        caster.getWorld().spawnParticle(Particle.FLASH, target, 5, 1, 1, 1, 0);
        caster.getWorld().playSound(target, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 0.6f);
        caster.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.7f);

        for (var e : caster.getWorld().getNearbyEntities(target, IMPACT_RADIUS, 6, IMPACT_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(DAMAGE, caster);
                // Small upward knock
                living.setVelocity(living.getVelocity().setY(0.6));
            }
        }

        return true;
    }
}
