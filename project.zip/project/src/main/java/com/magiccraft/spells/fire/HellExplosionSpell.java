package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Hell Explosion: large delayed explosion with fire particles, big AoE damage. */
public class HellExplosionSpell extends AbstractSpell {

    public HellExplosionSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "hell_explosion"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(30) != null
                ? caster.getTargetBlockExact(30).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(25));

        caster.getWorld().playSound(target, Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.5f);

        new BukkitRunnable() {
            int charge = 0;

            @Override
            public void run() {
                if (charge < 30) {
                    // Charging particles converging inward
                    for (int i = 0; i < 8; i++) {
                        double angle = (2 * Math.PI * i) / 8;
                        double r = 4.0 - (charge * 0.13);
                        Location ring = target.clone().add(r * Math.cos(angle), 1, r * Math.sin(angle));
                        caster.getWorld().spawnParticle(Particle.FLAME, ring, 5, 0.1, 0.1, 0.1, 0.0);
                    }
                    charge++;
                } else {
                    // Detonate
                    caster.getWorld().spawnParticle(Particle.FLAME, target, 300, 5, 5, 5, 0.5);
                    caster.getWorld().spawnParticle(Particle.LAVA, target, 80, 3, 3, 3, 0.3);
                    caster.getWorld().playSound(target, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.4f);
                    caster.getWorld().createExplosion(target, 6f, false, false);

                    for (var e : caster.getWorld().getNearbyEntities(target, 10, 10, 10)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(25.0, caster);
                            living.setFireTicks(200);
                        }
                    }
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
