package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.UltimateSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

/** Apocalypse: ULTIMATE - massive fire storm with multiple explosions, lava rain, fire tornado effect, huge AoE damage. */
public class ApocalypseSpell extends UltimateSpell {

    public ApocalypseSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "apocalypse"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    protected boolean executeUltimate(@NotNull Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL, 2.0f, 0.3f);
        caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.3f);

        new BukkitRunnable() {
            int phase = 0;

            @Override
            public void run() {
                if (phase > 60) {
                    cancel();
                    return;
                }

                // Phase 1-20: Lava rain over wide area
                if (phase <= 20) {
                    for (int i = 0; i < 20; i++) {
                        double angle = Math.random() * 2 * Math.PI;
                        double r = Math.random() * 15;
                        double x = center.getX() + r * Math.cos(angle);
                        double z = center.getZ() + r * Math.sin(angle);
                        Location rainPoint = new Location(caster.getWorld(), x, center.getY() + 15, z);
                        caster.getWorld().spawnParticle(Particle.LAVA, rainPoint, 3, 0.3, 0.0, 0.3, 0.0);
                        caster.getWorld().spawnParticle(Particle.FALLING_LAVA, rainPoint, 1, 0.3, 0.0, 0.3, 0.0);
                    }
                }

                // Phase 10-40: Fire tornado spiraling outward
                if (phase >= 10 && phase <= 40) {
                    double tornadoStep = (phase - 10) * 0.5;
                    for (int y = 0; y <= 8; y++) {
                        double angle = (phase * 0.4) + (y * 0.6);
                        double radius = 3.0;
                        double x = center.getX() + radius * Math.cos(angle) + (tornadoStep * Math.cos(phase * 0.1));
                        double z = center.getZ() + radius * Math.sin(angle) + (tornadoStep * Math.sin(phase * 0.1));
                        Location tornadoPoint = new Location(caster.getWorld(), x, center.getY() + y, z);
                        caster.getWorld().spawnParticle(Particle.FLAME, tornadoPoint, 5, 0.1, 0.1, 0.1, 0.03);
                        caster.getWorld().spawnParticle(Particle.LAVA, tornadoPoint, 1, 0.05, 0.05, 0.05, 0.0);
                    }
                }

                // Phase 20-60: Multiple explosions
                if (phase >= 20 && phase % 10 == 0) {
                    double ex = center.getX() + (Math.random() - 0.5) * 20;
                    double ez = center.getZ() + (Math.random() - 0.5) * 20;
                    Location explosionLoc = new Location(caster.getWorld(), ex, center.getY(), ez);
                    caster.getWorld().spawnParticle(Particle.FLAME, explosionLoc, 200, 4, 4, 4, 0.5);
                    caster.getWorld().spawnParticle(Particle.LAVA, explosionLoc, 50, 2, 2, 2, 0.3);
                    caster.getWorld().playSound(explosionLoc, Sound.ENTITY_GENERIC_EXPLODE, 2.0f, 0.3f);
                    caster.getWorld().createExplosion(explosionLoc, 5f, false, false);

                    for (var e : caster.getWorld().getNearbyEntities(explosionLoc, 8, 8, 8)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(20.0, caster);
                            living.setFireTicks(200);
                        }
                    }
                }

                // Continuous AoE damage around center
                if (phase % 5 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 15, 10, 15)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(6.0, caster);
                            living.setFireTicks(80);
                        }
                    }
                }

                // Ambient fire particles
                caster.getWorld().spawnParticle(Particle.FLAME, center, 30, 10, 5, 10, 0.1);

                phase++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
