package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Frozen Orb: launches a snowball that orbits the caster and fires ice shards at nearby enemies. */
public class FrozenOrbSpell extends AbstractSpell {

    public FrozenOrbSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "frozen_orb"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(0, 1.5, 0);
        caster.getWorld().playSound(center, Sound.ENTITY_SNOWBALL_THROW, 1f, 1.2f);
        caster.getWorld().playSound(center, Sound.BLOCK_GLASS_PLACE, 0.8f, 1.8f);

        new BukkitRunnable() {
            int ticks = 0;
            double angle = 0;

            @Override
            public void run() {
                if (ticks++ >= 200) {
                    cancel();
                    return;
                }
                angle += 0.4;
                Location orbLoc = caster.getLocation().add(0, 1.5, 0)
                        .add(Math.cos(angle) * 2.5, 0, Math.sin(angle) * 2.5);

                caster.getWorld().spawnParticle(Particle.SNOWFLAKE, orbLoc, 6, 0.1, 0.1, 0.1, 0.02);
                caster.getWorld().spawnParticle(Particle.FIREWORK, orbLoc, 2, 0.05, 0.05, 0.05, 0.0);

                // Fire ice shards at nearby enemies every 15 ticks.
                if (ticks % 15 == 0) {
                    LivingEntity nearest = null;
                    double nearestDist = 15.0;
                    for (var e : orbLoc.getWorld().getNearbyEntities(orbLoc, 15, 15, 15)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            double d = living.getLocation().distance(orbLoc);
                            if (d < nearestDist) {
                                nearestDist = d;
                                nearest = living;
                            }
                        }
                    }
                    if (nearest != null) {
                        Vector toTarget = nearest.getLocation().add(0, 1, 0).toVector()
                                .subtract(orbLoc.toVector()).normalize().multiply(2.0);
                        Snowball shard = orbLoc.getWorld().spawn(orbLoc, Snowball.class);
                        shard.setVelocity(toTarget);
                        shard.setShooter(caster);
                        shard.setGravity(false);
                        orbLoc.getWorld().spawnParticle(Particle.SNOWFLAKE, orbLoc, 10, 0.2, 0.2, 0.2, 0.1);
                        orbLoc.getWorld().playSound(orbLoc, Sound.ENTITY_SNOWBALL_THROW, 0.6f, 2f);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
