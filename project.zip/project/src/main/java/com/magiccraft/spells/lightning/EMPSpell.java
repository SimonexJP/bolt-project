package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** EMP: electromagnetic pulse that blinds and weakens nearby enemies. */
public class EMPSpell extends AbstractSpell {

    private static final double PULSE_RADIUS = 10.0;
    private static final double DAMAGE = 5.0;

    public EMPSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "emp"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();

        // Expanding ring of electric particles
        for (int ring = 0; ring < 3; ring++) {
            double radius = (ring + 1) * (PULSE_RADIUS / 3.0);
            for (int i = 0; i < 40; i++) {
                double angle = (i / 40.0) * Math.PI * 2;
                Location p = center.clone().add(
                        Math.cos(angle) * radius, 0.5, Math.sin(angle) * radius);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 2, 0.05, 0.1, 0.05, 0.02);
            }
        }

        caster.getWorld().spawnParticle(Particle.FLASH, center, 5, 2, 2, 2, 0);
        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.5f);
        caster.getWorld().playSound(center, Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.5f);

        for (var e : caster.getWorld().getNearbyEntities(center, PULSE_RADIUS, PULSE_RADIUS, PULSE_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(DAMAGE, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 100, 0));
                living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1));
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2));
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, living.getLocation(), 20, 0.3, 0.5, 0.3, 0.1);
            }
        }

        return true;
    }
}
