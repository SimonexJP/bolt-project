package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Earth Dash: propels the caster forward with a stone trail, knocking back enemies. */
public class EarthDashSpell extends AbstractSpell {

    public EarthDashSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "earth_dash"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize().multiply(2.5).setY(0.3);
        caster.setVelocity(dir);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1.5f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 15) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation(), 8, 0.5, 0.5, 0.5, 0.1);
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation(), 5, 0.8, 0.5, 0.8, 0.05);

                for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 2.5, 2.5, 2.5)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(6.0, caster);
                        Vector away = living.getLocation().toVector().subtract(caster.getLocation().toVector()).normalize().multiply(1.5);
                        living.setVelocity(away.setY(0.5));
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
