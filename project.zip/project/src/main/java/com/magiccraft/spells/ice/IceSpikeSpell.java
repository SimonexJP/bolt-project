package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Ice Spike: summons ice spikes from the ground at the target location, damaging and launching enemies. */
public class IceSpikeSpell extends AbstractSpell {

    public IceSpikeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ice_spike"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize();
        Location target = caster.getLocation().add(dir.multiply(8));
        target = target.getBlock().getLocation().add(0.5, 0, 0.5);

        caster.getWorld().playSound(target, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.6f);
        caster.getWorld().playSound(target, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 1f);

        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                if (step >= 5) {
                    cancel();
                    return;
                }
                Location spikeLoc = target.clone().add(
                        (Math.random() - 0.5) * 4, 0, (Math.random() - 0.5) * 4);
                for (int y = 0; y < 3; y++) {
                    Block b = spikeLoc.clone().add(0, y, 0).getBlock();
                    if (b.getType().isAir()) {
                        b.setType(Material.PACKED_ICE);
                    }
                }
                spikeLoc.getWorld().spawnParticle(Particle.SNOWFLAKE, spikeLoc.add(0, 1.5, 0), 20, 0.5, 1, 0.5, 0.1);
                spikeLoc.getWorld().spawnParticle(Particle.FIREWORK, spikeLoc, 8, 0.3, 0.5, 0.3, 0.0);
                spikeLoc.getWorld().playSound(spikeLoc, Sound.BLOCK_GLASS_PLACE, 1f, 1.5f);

                for (var e : spikeLoc.getWorld().getNearbyEntities(spikeLoc, 2, 3, 2)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(7.0, caster);
                        living.setVelocity(new Vector(0, 0.6, 0));
                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                    }
                }
                step++;
            }
        }.runTaskTimer(plugin, 0L, 5L);

        return true;
    }
}
