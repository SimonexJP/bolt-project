package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Healing Touch: restores the caster's health. */
public class HealingTouchSpell extends AbstractSpell {

    public HealingTouchSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "healing_touch"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        double heal = Math.min(caster.getMaxHealth(), caster.getHealth() + 8.0);
        caster.setHealth(heal);
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        return true;
    }
}
