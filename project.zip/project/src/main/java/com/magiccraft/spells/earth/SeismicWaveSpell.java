package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Seismic Wave: sends a shockwave forward that damages and knocks back enemies. */
public class SeismicWaveSpell extends AbstractSpell {

    public SeismicWaveSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "seismic_wave"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location start = caster.getLocation();
        Vector dir = caster.getLocation().getDirection().setY(0).normalize();

        caster.getWorld().playSound(start, Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1.5f, 0.4f);
        caster.getWorld().playSound(start, Sound.BLOCK_STONE_BREAK, 1.5f, 0.5f);

        new BukkitRunnable() {
            int step = 0;

            @Override
            public void run() {
                if (step > 16) {
                    cancel();
                    return;
                }

                double distance = step * 1.5;
                Location wave = start.clone().add(dir.clone().multiply(distance));

                // Expanding ring at the wave front
                for (int i = 0; i < 24; i++) {
                    double angle = (i * 2 * Math.PI) / 24.0;
                    double ringR = 2.0;
                    Location ring = wave.clone().add(ringR * Math.cos(angle), 0.2, ringR * Math.sin(angle));
                    caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, ring, 3, 0.1, 0.3, 0.1, 0.0);
                    caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, ring, 2, 0.2, 0.2, 0.2, 0.05);
                }

                for (var e : caster.getWorld().getNearbyEntities(wave, 3, 2, 3)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(7.0, caster);
                        Vector away = living.getLocation().toVector().subtract(start.toVector()).setY(0).normalize().multiply(1.5);
                        living.setVelocity(away.setY(0.6));
                    }
                }

                caster.getWorld().playSound(wave, Sound.BLOCK_STONE_PLACE, 0.8f, 0.6f);
                step++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
