package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Snow Storm: an AoE snowstorm that slows and damages all nearby enemies over several seconds. */
public class SnowStormSpell extends AbstractSpell {

    public SnowStormSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "snow_storm"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        double radius = 8.0;

        caster.getWorld().playSound(center, Sound.WEATHER_CHANGE_RAIN, 1.5f, 0.6f);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 0.8f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 120) {
                    cancel();
                    return;
                }
                for (int i = 0; i < 8; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * radius;
                    Location loc = center.clone().add(Math.cos(angle) * dist, Math.random() * 3, Math.sin(angle) * dist);
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 3, 0.5, 0.3, 0.5, 0.05);
                }
                if (ticks % 20 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(4.0, caster);
                            living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                            living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0));
                        }
                    }
                    caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 0.6f, 0.9f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
