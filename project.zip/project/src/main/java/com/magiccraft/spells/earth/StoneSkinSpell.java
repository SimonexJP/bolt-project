package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Stone Skin: resistance + slowness buff. */
public class StoneSkinSpell extends AbstractSpell {

    public StoneSkinSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "stone_skin"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 0));
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1f, 1f);
        return true;
    }
}
