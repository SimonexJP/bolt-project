package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Flame Burst: ignites and damages nearby enemies. */
public class FlameBurstSpell extends AbstractSpell {

    public FlameBurstSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "flame_burst"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().spawnParticle(Particle.FLAME, caster.getLocation(), 80, 4, 2, 4, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1f, 1f);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 5, 5, 5)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(7.0, caster);
                living.setFireTicks(100);
            }
        }
        return true;
    }
}
