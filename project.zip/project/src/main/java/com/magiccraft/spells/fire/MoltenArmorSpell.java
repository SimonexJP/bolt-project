package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Molten Armor: PASSIVE - gives fire resistance on apply, spawns flame particles and damages nearby enemies on tick, removes effects on remove. */
public class MoltenArmorSpell extends PassiveSpell {

    public MoltenArmorSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "molten_armor"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1.0f, 0.5f);
        caster.getWorld().spawnParticle(Particle.LAVA, caster.getLocation().add(0, 1, 0), 20, 0.5, 1, 0.5, 0.0);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        Location loc = caster.getLocation().add(0, 1, 0);
        caster.getWorld().spawnParticle(Particle.FLAME, loc, 10, 1, 1, 1, 0.05);
        caster.getWorld().spawnParticle(Particle.LAVA, loc, 3, 0.5, 0.5, 0.5, 0.0);

        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 3, 3, 3)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(3.0, caster);
                living.setFireTicks(40);
            }
        }
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.FIRE_RESISTANCE);
        caster.getWorld().spawnParticle(Particle.FLAME, caster.getLocation().add(0, 1, 0), 30, 1, 1, 1, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1.0f, 0.5f);
    }
}
