package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Spike Field: creates a field of stone spikes that damages enemies in the area. */
public class SpikeFieldSpell extends AbstractSpell {

    public SpikeFieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "spike_field"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(5));
        caster.getWorld().playSound(center, Sound.BLOCK_STONE_PLACE, 2.0f, 0.4f);
        caster.getWorld().playSound(center, Sound.BLOCK_POINTED_DRIPSTONE_PLACE, 1.5f, 0.6f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 140) {
                    cancel();
                    return;
                }

                // Spawn spike particles in a grid
                for (int i = -4; i <= 4; i += 2) {
                    for (int j = -4; j <= 4; j += 2) {
                        Location spike = center.clone().add(i, 0, j);
                        caster.getWorld().spawnParticle(Particle.CRIT, spike, 3, 0.2, 1.5, 0.2, 0.0);
                        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, spike, 2, 0.3, 0.8, 0.3, 0.02);
                    }
                }

                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 5, 3, 5)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(5.0, caster);
                            living.setVelocity(living.getVelocity().setY(0.4));
                        }
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
