package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Ice Shield: grants resistance + slowness aura briefly. */
public class IceShieldSpell extends AbstractSpell {

    public IceShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ice_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 0));
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_PLACE, 1f, 1f);
        return true;
    }
}
