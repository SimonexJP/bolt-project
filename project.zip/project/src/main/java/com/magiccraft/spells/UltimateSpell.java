package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Base class for ultimate abilities: long-cooldown, high-impact signature
 * spells unique to each faction. Ultimates can scale with evolution tier
 * and element affinity.
 */
public abstract class UltimateSpell extends AbstractSpell {

    protected UltimateSpell(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    public com.magiccraft.core.enums.SpellType getType() {
        return com.magiccraft.core.enums.SpellType.ULTIMATE;
    }

    @Override
    public boolean cast(@NotNull Player caster) {
        return executeUltimate(caster);
    }

    /** Executes the faction's signature ultimate ability. */
    protected abstract boolean executeUltimate(@NotNull Player caster);
}
