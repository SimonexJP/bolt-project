package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Crystal Armor: PASSIVE - grants resistance on apply, spawns crystal particles on tick, removes effects on remove. */
public class CrystalArmorSpell extends PassiveSpell {

    public CrystalArmorSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "crystal_armor"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.2f);
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getLocation().add(0, 1, 0), 25, 0.8, 1.2, 0.8, 0.03);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getLocation().add(0, 1, 0), 6, 0.6, 1, 0.6, 0.02);
        caster.getWorld().spawnParticle(Particle.REVERSE_PORTAL, caster.getLocation().add(0, 1, 0), 4, 0.5, 0.8, 0.5, 0.01);
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.RESISTANCE);
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getLocation().add(0, 1, 0), 30, 1, 1.5, 1, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_BREAK, 1.0f, 0.8f);
    }
}
