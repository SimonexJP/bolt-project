package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Flash Step: teleports caster forward in a flash of electricity. */
public class FlashStepSpell extends AbstractSpell {

    private static final double TELEPORT_DISTANCE = 15.0;

    public FlashStepSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "flash_step"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location origin = caster.getLocation();
        Vector dir = origin.getDirection().normalize();
        Location dest = origin.clone().add(dir.multiply(TELEPORT_DISTANCE));

        // Electric trail from origin to destination
        Vector step = dir.clone().multiply(0.5);
        Location cursor = origin.clone();
        double traveled = 0;
        while (traveled < TELEPORT_DISTANCE) {
            cursor.add(step);
            traveled += 0.5;
            caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, cursor, 6, 0.1, 0.1, 0.1, 0.05);
        }

        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, origin, 40, 0.5, 1, 0.5, 0.2);
        caster.getWorld().playSound(origin, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 2f);

        caster.teleport(dest);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, dest, 60, 1, 1, 1, 0.3);
        caster.getWorld().playSound(dest, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.8f);

        // Damage enemies near the destination
        for (var e : caster.getWorld().getNearbyEntities(dest, 3, 3, 3)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(6.0, caster);
            }
        }

        return true;
    }
}
