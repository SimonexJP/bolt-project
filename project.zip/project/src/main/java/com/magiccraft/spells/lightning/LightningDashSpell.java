package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Lightning Dash: dash forward leaving a lightning trail, damaging enemies. */
public class LightningDashSpell extends AbstractSpell {

    private static final double DASH_DISTANCE = 18.0;
    private static final double TRAIL_RADIUS = 2.0;
    private static final double DAMAGE = 8.0;

    public LightningDashSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "lightning_dash"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().clone();
        dir.setY(0).normalize();
        Location start = caster.getLocation();

        caster.getWorld().playSound(start, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 2f);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, start, 30, 0.5, 1, 0.5, 0.2);

        new BukkitRunnable() {
            double traveled = 0;
            Location cursor = start.clone();

            @Override
            public void run() {
                if (traveled >= DASH_DISTANCE) {
                    cancel();
                    return;
                }
                double stepSize = 1.0;
                cursor.add(dir.clone().multiply(stepSize));
                traveled += stepSize;

                // Lightning trail
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, cursor, 15, 0.3, 0.5, 0.3, 0.1);
                caster.getWorld().spawnParticle(Particle.FLASH, cursor, 2, 0.2, 0.2, 0.2, 0);

                // Damage enemies along the trail
                for (var e : caster.getWorld().getNearbyEntities(cursor, TRAIL_RADIUS, TRAIL_RADIUS, TRAIL_RADIUS)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(DAMAGE, caster);
                        living.setVelocity(dir.clone().multiply(0.5).setY(0.3));
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        // Dash the caster forward
        caster.setVelocity(dir.clone().multiply(1.5).setY(0.2));
        return true;
    }
}
