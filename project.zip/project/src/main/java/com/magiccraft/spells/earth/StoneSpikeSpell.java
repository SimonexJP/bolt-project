package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Stone Spike: damages the target in front of the caster. */
public class StoneSpikeSpell extends AbstractSpell {

    public StoneSpikeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "stone_spike"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getLocation().add(caster.getLocation().getDirection().multiply(5)).add(0, 1, 0);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, target, 40, 0.5, 1, 0.5, 0.1);
        caster.getWorld().playSound(target, Sound.BLOCK_STONE_PLACE, 1f, 0.8f);
        for (var e : caster.getWorld().getNearbyEntities(target, 2, 3, 2)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(8.0, caster);
                living.setVelocity(living.getVelocity().setY(0.8));
            }
        }
        return true;
    }
}
