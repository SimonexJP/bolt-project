package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Life Aura: passive regeneration aura with gentle healing and happy particles. */
public class LifeAuraSpell extends PassiveSpell {

    public LifeAuraSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "life_aura"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, false, false, true));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 6, 1, 1, 1, 0.02);
        if (caster.getHealth() < caster.getMaxHealth()) {
            caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 1.0));
        }
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.REGENERATION);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 15, 1, 1, 1, 0.05);
    }
}
