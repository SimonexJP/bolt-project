package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.SmallFireball;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Magma Burst: fires a burst of magma that explodes on impact. */
public class MagmaBurstSpell extends AbstractSpell {

    public MagmaBurstSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "magma_burst"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.5);
        SmallFireball magma = caster.launchProjectile(SmallFireball.class, dir);
        magma.setShooter(caster);
        magma.setIsIncendiary(true);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 0.5f);

        // Trail particles following the fireball
        new BukkitRunnable() {
            @Override
            public void run() {
                if (magma.isDead()) {
                    Location impact = magma.getLocation();
                    caster.getWorld().spawnParticle(Particle.LAVA, impact, 60, 2, 2, 2, 0.2);
                    caster.getWorld().spawnParticle(Particle.FLAME, impact, 100, 3, 3, 3, 0.3);
                    caster.getWorld().playSound(impact, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.7f);
                    caster.getWorld().createExplosion(impact, 3f, false, false);

                    for (var e : caster.getWorld().getNearbyEntities(impact, 5, 5, 5)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(12.0, caster);
                            living.setFireTicks(120);
                        }
                    }
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.LAVA, magma.getLocation(), 5, 0.3, 0.3, 0.3, 0.0);
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }
}
