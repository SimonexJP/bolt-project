package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Tempest: creates a storm whirlwind with lightning and wind. */
public class TempestSpell extends AbstractSpell {

    private static final double RADIUS = 10.0;
    private static final double DAMAGE_PER_TICK = 5.0;
    private static final int DURATION_TICKS = 120;
    private static final int TICK_INTERVAL = 5;

    public TempestSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "tempest"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getTargetBlockExact(30) != null
                ? caster.getTargetBlockExact(30).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(20));

        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.4f);
        caster.getWorld().playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.3f);

        new BukkitRunnable() {
            int elapsed = 0;
            int strikeCount = 0;

            @Override
            public void run() {
                if (elapsed >= DURATION_TICKS) {
                    cancel();
                    return;
                }
                elapsed += TICK_INTERVAL;

                // Whirlwind particles — spiral upward
                for (int ring = 0; ring < 3; ring++) {
                    double r = RADIUS * (0.5 + ring * 0.25);
                    double yOff = ring * 2.0;
                    for (int i = 0; i < 20; i++) {
                        double angle = (i / 20.0) * Math.PI * 2 + (elapsed * 0.2);
                        Location p = center.clone().add(
                                Math.cos(angle) * r, yOff, Math.sin(angle) * r);
                        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.05, 0.1, 0.05, 0.05);
                        caster.getWorld().spawnParticle(Particle.CLOUD, p, 1, 0.1, 0.1, 0.1, 0.02);
                    }
                }

                // Pull enemies inward and damage
                for (var e : caster.getWorld().getNearbyEntities(center, RADIUS, RADIUS, RADIUS)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(DAMAGE_PER_TICK, caster);
                        living.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 20, 1));
                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 20, 0));
                        // Spiral pull
                        Vector toCenter = center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.3);
                        living.setVelocity(toCenter);
                    }
                }

                // Periodic lightning strikes within the whirlwind
                if (strikeCount < 4 && elapsed % 30 == 0) {
                    strikeCount++;
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * RADIUS * 0.7;
                    Location strike = center.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
                    caster.getWorld().strikeLightning(strike);
                    caster.getWorld().playSound(strike, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.6f);
                }

                // Wind sound
                if (elapsed % 20 == 0) {
                    caster.getWorld().playSound(center, Sound.ENTITY_BREEZE_WIND_BURST, 0.8f, 0.5f);
                }
            }
        }.runTaskTimer(plugin, 0L, TICK_INTERVAL);

        return true;
    }
}
