package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Stone Rain: rains stones over an area, damaging enemies. */
public class StoneRainSpell extends AbstractSpell {

    public StoneRainSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "stone_rain"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(6));
        caster.getWorld().playSound(center, Sound.BLOCK_STONE_PLACE, 2.0f, 0.5f);
        caster.getWorld().playSound(center, Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1.0f, 0.6f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 100) {
                    cancel();
                    return;
                }

                // Rain stones from above
                for (int i = 0; i < 10; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double r = Math.random() * 5;
                    double x = center.getX() + r * Math.cos(angle);
                    double z = center.getZ() + r * Math.sin(angle);
                    Location rain = new Location(caster.getWorld(), x, center.getY() + 12, z);
                    caster.getWorld().spawnParticle(Particle.CLOUD, rain, 4, 0.3, 0.0, 0.3, 0.2);
                    caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, rain, 2, 0.2, 0.0, 0.2, 0.1);
                }

                if (ticks % 5 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 5, 6, 5)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(5.0, caster);
                            living.setVelocity(living.getVelocity().setY(0.3));
                        }
                    }
                    // Ground impact particles
                    caster.getWorld().spawnParticle(Particle.CLOUD, center, 20, 3, 0.5, 3, 0.1);
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
