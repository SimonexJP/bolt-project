package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Leaf Storm: a whirlwind of leaves that damages and knocks back enemies. */
public class LeafStormSpell extends AbstractSpell {

    public LeafStormSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "leaf_storm"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        for (int i = 0; i < 3; i++) {
            caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 80, 5, 3, 5, 0.4);
        }
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 30, 5, 3, 5, 0.2);
        caster.getWorld().playSound(loc, Sound.ITEM_ELYTRA_FLYING, 1.5f, 0.8f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 6, 4, 6)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(7.0, caster);
                Vector knock = living.getLocation().toVector().subtract(loc.toVector()).setY(0).normalize().multiply(1.5).setY(0.7);
                living.setVelocity(knock);
            }
        }
        return true;
    }
}
