package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Fire Spear: launches a fast fire projectile (Arrow) with fire trail. */
public class FireSpearSpell extends AbstractSpell {

    public FireSpearSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "fire_spear"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(3.0);
        Arrow spear = caster.launchProjectile(Arrow.class, dir);
        spear.setShooter(caster);
        spear.setCritical(true);
        spear.setFireTicks(200);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0f, 2.0f);
        caster.getWorld().spawnParticle(Particle.FLAME, caster.getEyeLocation(), 20, 0.2, 0.2, 0.2, 0.1);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (spear.isDead() || spear.isOnGround()) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.FLAME, spear.getLocation(), 8, 0.1, 0.1, 0.1, 0.05);
                caster.getWorld().spawnParticle(Particle.LAVA, spear.getLocation(), 2, 0.1, 0.1, 0.1, 0.0);

                for (var e : spear.getWorld().getNearbyEntities(spear.getLocation(), 1.5, 1.5, 1.5)) {
                    if (e instanceof LivingEntity living && !e.equals(caster) && !e.equals(spear)) {
                        living.damage(10.0, caster);
                        living.setFireTicks(100);
                        spear.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }
}
