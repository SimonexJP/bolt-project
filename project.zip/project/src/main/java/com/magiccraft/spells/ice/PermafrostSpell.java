package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Permafrost: freezes the ground in a large radius, slowing all enemies standing on it. */
public class PermafrostSpell extends AbstractSpell {

    public PermafrostSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "permafrost"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        double radius = 12.0;

        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 120, radius, 1, radius, 0.1);
        caster.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.4f);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 0.5f);

        int r = (int) radius;
        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                Block b = center.clone().add(x, -1, z).getBlock();
                if (b.getType().isAir() && b.getRelative(BlockFace.DOWN).getType().isSolid()) {
                    b.setType(Material.FROSTED_ICE);
                }
            }
        }

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 200) {
                    cancel();
                    return;
                }
                for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                        if (ticks % 40 == 0) {
                            living.damage(3.0, caster);
                            living.getWorld().spawnParticle(Particle.SNOWFLAKE, living.getLocation().add(0, 1, 0), 8, 0.3, 0.6, 0.3, 0.05);
                        }
                    }
                }
                if (ticks % 30 == 0) {
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 20, radius, 1, radius, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 10L);

        return true;
    }
}
