package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Mud Trap: slows and traps enemies in mud with heavy slowness. */
public class MudTrapSpell extends AbstractSpell {

    public MudTrapSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "mud_trap"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation().add(caster.getLocation().getDirection().setY(0).normalize().multiply(4));
        caster.getWorld().playSound(center, Sound.BLOCK_MUD_PLACE, 2.0f, 0.5f);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_SPLASH, 1.5f, 0.6f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 120) {
                    cancel();
                    return;
                }

                for (int i = 0; i < 20; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double r = Math.random() * 4;
                    Location mud = center.clone().add(r * Math.cos(angle), 0.1, r * Math.sin(angle));
                    caster.getWorld().spawnParticle(Particle.SMOKE, mud, 3, 0.2, 0.1, 0.2, 0.0);
                    caster.getWorld().spawnParticle(Particle.SPLASH, mud, 2, 0.2, 0.2, 0.2, 0.0);
                }

                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 4, 2, 4)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 3));
                            living.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 60, 1));
                            living.setVelocity(living.getVelocity().multiply(0.3).setY(-0.2));
                            living.damage(3.0, caster);
                        }
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
