package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Spirit Shot: fires a spiritual snowball that glows and marks targets. */
public class SpiritShotSpell extends AbstractSpell {

    public SpiritShotSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "spirit_shot"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.5);
        Snowball proj = caster.launchProjectile(Snowball.class, dir);
        proj.setShooter(caster);
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getEyeLocation(), 25, 0.3, 0.3, 0.3, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.8f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (proj.isDead() || !proj.isValid() || ticks++ > 60) {
                    cancel();
                    return;
                }
                proj.getWorld().spawnParticle(Particle.END_ROD, proj.getLocation(), 6, 0.1, 0.1, 0.1, 0.02);
                for (var e : proj.getWorld().getNearbyEntities(proj.getLocation(), 1.5, 1.5, 1.5)) {
                    if (e instanceof org.bukkit.entity.LivingEntity living && !e.equals(caster)) {
                        living.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
                        living.damage(4.0, caster);
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
