package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Earthquake: AoE damage + slowness to nearby enemies. */
public class EarthquakeSpell extends AbstractSpell {

    public EarthquakeSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "earthquake"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation(), 100, 6, 1, 6, 0.2);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_ZOMBIE_BREAK_WOODEN_DOOR, 1f, 0.6f);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 6, 3, 6)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(9.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 80, 2));
                living.setVelocity(living.getVelocity().setY(0.5));
            }
        }
        return true;
    }
}
