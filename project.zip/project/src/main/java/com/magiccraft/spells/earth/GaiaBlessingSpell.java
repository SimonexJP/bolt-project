package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Gaia Blessing: blesses the caster with regeneration, resistance, and strength. */
public class GaiaBlessingSpell extends AbstractSpell {

    public GaiaBlessingSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "gaia_blessing"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 400, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 400, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 400, 1));

        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 60, 2, 3, 2, 0.05);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 40, 1.5, 2.5, 1.5, 0.03);
        caster.getWorld().spawnParticle(Particle.HEART, caster.getLocation().add(0, 2, 0), 15, 1, 1, 1, 0.0);

        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_ROOTED_DIRT_PLACE, 1.5f, 1.0f);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.0f, 1.2f);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 0.8f);
        return true;
    }
}
