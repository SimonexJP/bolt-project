package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.util.Vector;

/** Ice Shard: fires a fast snowball that deals damage on hit. */
public class IceShardSpell extends AbstractSpell {

    public IceShardSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ice_shard"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection();
        Snowball proj = caster.launchProjectile(Snowball.class, dir.multiply(2.0));
        proj.setShooter(caster);
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getEyeLocation(), 12, 0.3, 0.3, 0.3, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1f, 1.5f);
        // Tag damage via the projectile hit is handled in SpellProjectileListener.
        return true;
    }
}
