package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Moonlight: bathes the area in moonlight, healing allies and damaging undead. */
public class MoonlightSpell extends AbstractSpell {

    public MoonlightSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "moonlight"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.END_ROD, loc.clone().add(0, 3, 0), 80, 5, 3, 5, 0.05);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 40, 4, 2, 4, 0.05);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.2f, 0.8f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 8, 6, 8)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                String name = living.getType().name();
                if (name.contains("ZOMBIE") || name.contains("SKELETON") || name.contains("PHANTOM") || name.contains("DROWNED") || name.contains("HUSK")) {
                    living.damage(10.0, caster);
                    living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 0));
                } else if (e instanceof Player ally) {
                    ally.setHealth(Math.min(ally.getMaxHealth(), ally.getHealth() + 5.0));
                    ally.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 0));
                }
            }
        }
        caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 5.0));
        return true;
    }
}
