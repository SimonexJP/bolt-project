package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Ice Dash: propels the caster forward with an ice trail, leaving frozen ground behind. */
public class IceDashSpell extends AbstractSpell {

    public IceDashSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ice_dash"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().setY(0).normalize().multiply(2.5);
        dir.setY(0.3);
        caster.setVelocity(dir);
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 0));

        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1f, 2f);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 0.8f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;
            Location last = caster.getLocation();

            @Override
            public void run() {
                if (ticks++ > 40) {
                    cancel();
                    return;
                }
                Location current = caster.getLocation();
                if (current.distance(last) > 0.5) {
                    // Leave frozen ground along the trail.
                    Block b = current.getBlock().getRelative(BlockFace.DOWN);
                    if (b.getType().isAir() && b.getRelative(BlockFace.DOWN).getType().isSolid()) {
                        b.setType(Material.FROSTED_ICE);
                    }
                    last = current;
                }
                caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation().add(0, 1, 0), 6, 0.3, 0.5, 0.3, 0.05);
                caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation().add(0, 0.5, 0), 3, 0.2, 0.1, 0.2, 0.02);
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
