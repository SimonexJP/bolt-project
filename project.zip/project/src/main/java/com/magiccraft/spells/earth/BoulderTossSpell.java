package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.util.Vector;

/** Boulder Toss: launches a heavy projectile dealing big damage. */
public class BoulderTossSpell extends AbstractSpell {

    public BoulderTossSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "boulder toss"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(1.5);
        Snowball proj = caster.launchProjectile(Snowball.class, dir);
        proj.setShooter(caster);
        proj.setGravity(true);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getEyeLocation(), 20, 0.5, 0.5, 0.5, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1f, 0.6f);
        return true;
    }
}
