package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.UltimateSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.jetbrains.annotations.NotNull;

/** Eternal Winter: ULTIMATE. A massive blizzard that freezes all enemies in a huge radius and deals continuous ice damage. */
public class EternalWinterSpell extends UltimateSpell {

    public EternalWinterSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "eternal_winter"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    protected boolean executeUltimate(@NotNull Player caster) {
        Location center = caster.getLocation();
        double radius = 20.0;

        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 500, radius, 6, radius, 0.2);
        caster.getWorld().spawnParticle(Particle.CLOUD, center, 100, radius, 4, radius, 0.1);
        caster.getWorld().spawnParticle(Particle.FIREWORK, center, 60, 5, 5, 5, 0.0);
        caster.getWorld().playSound(center, Sound.ENTITY_ENDER_DRAGON_GROWL, 2f, 0.4f);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 2f, 0.3f);
        caster.getWorld().playSound(center, Sound.WEATHER_CHANGE_RAIN, 2f, 0.3f);
        caster.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 2f, 0.3f);

        // Initial freeze of all enemies.
        for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(15.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 400, 6));
                living.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 400, -128));
                living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 400, 2));
                living.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 400, 2));
                living.setVelocity(new Vector(0, 0, 0));
                living.getWorld().spawnParticle(Particle.SNOWFLAKE, living.getLocation().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
            }
        }

        // Continuous blizzard for 10 seconds.
        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 200) {
                    caster.getWorld().playSound(center, Sound.WEATHER_CHANGE_RAIN, 1f, 1.5f);
                    cancel();
                    return;
                }
                // Dense snowfall.
                for (int i = 0; i < 30; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * radius;
                    Location loc = center.clone().add(Math.cos(angle) * dist, Math.random() * 8, Math.sin(angle) * dist);
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 4, 0.5, 0.3, 0.5, 0.05);
                }
                // Periodic damage + refreeze.
                if (ticks % 25 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(8.0, caster);
                            living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 5));
                            living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 1));
                            living.getWorld().spawnParticle(Particle.SNOWFLAKE, living.getLocation().add(0, 1, 0), 15, 0.3, 0.6, 0.3, 0.05);
                        }
                    }
                    caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 0.5f);
                    caster.getWorld().spawnParticle(Particle.CLOUD, center, 50, radius, 3, radius, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
