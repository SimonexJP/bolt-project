package com.magiccraft.spells;

import com.magiccraft.core.enums.FactionType;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Contract for a castable spell.
 *
 * <p>Implementations are registered in {@link SpellManager} by id.
 * Metadata (mana cost, cooldown, display name) is read from spells.yml.
 */
public interface Spell {

    /** Unique id matching the key in spells.yml (e.g. {@code "fireball"}). */
    @NotNull String getId();

    /** Faction that owns this spell. */
    @NotNull FactionType getFaction();

    /**
     * Executes the spell effect.
     *
     * @param caster the player casting the spell
     * @return true if the spell succeeded (consumes mana + starts cooldown),
     *         false if it failed for an internal reason (still consumes nothing)
     */
    boolean cast(@NotNull Player caster);
}
