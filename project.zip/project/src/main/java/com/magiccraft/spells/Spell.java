package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.core.enums.SpellTier;
import com.magiccraft.core.enums.SpellType;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Contract for a castable spell.
 *
 * <p>Implementations are registered in {@link SpellManager} by id.
 * Metadata (mana cost, cooldown, display name) is read from spells.yml.
 *
 * <p>Default methods provide backward-compatible behavior so existing
 * spell implementations continue to work without modification. New
 * spell types (charged, ultimate, passive) override the relevant defaults.
 */
public interface Spell {

    /** Unique id matching the key in spells.yml (e.g. {@code "fireball"}). */
    @NotNull String getId();

    /** Faction that owns this spell. */
    @NotNull FactionType getFaction();

    /**
     * Executes the spell effect.
     *
     * @param caster the player casting the spell
     * @return true if the spell succeeded (consumes mana + starts cooldown),
     *         false if it failed for an internal reason (still consumes nothing)
     */
    boolean cast(@NotNull Player caster);

    /** Spell classification. Defaults to ACTIVE for backward compatibility. */
    default @NotNull SpellType getType() { return SpellType.ACTIVE; }

    /**
     * Resolves the current evolution tier for the caster based on their level
     * and the per-spell tier thresholds in spells.yml.
     */
    default @NotNull SpellTier tier(@NotNull MagicPlugin plugin, @NotNull Player caster) {
        var mp = plugin.getPlayerManager().getOrNull(caster);
        int level = mp != null ? mp.getData().getLevel() : 1;
        var cfg = plugin.getConfigManager().spells().get();
        int t2 = cfg.getInt("spells." + getId() + ".evolution.tier-2-level", 25);
        int t3 = cfg.getInt("spells." + getId() + ".evolution.tier-3-level", 50);
        int t4 = cfg.getInt("spells." + getId() + ".evolution.tier-4-level", 75);
        return SpellTier.forLevel(level, t2, t3, t4);
    }

    /**
     * Scales a base damage value by the caster's current evolution tier.
     * Implementations should call this when applying damage.
     */
    default double scaleDamage(@NotNull MagicPlugin plugin, @NotNull Player caster, double base) {
        return base * tier(plugin, caster).damageMultiplier();
    }

    /**
     * For CHARGED spells: the maximum charge time in ticks (1 second = 20 ticks).
     * The cast result scales with charge percentage. Default 40 ticks (2s).
     */
    default int maxChargeTicks() { return 40; }

    /**
     * For CHARGED spells: executes the spell at the given charge percentage
     * (0.0 to 1.0). Default delegates to {@link #cast}.
     */
    default boolean castCharged(@NotNull Player caster, double chargePercent) {
        return cast(caster);
    }

    /**
     * For PASSIVE spells: called periodically (every ~2 seconds) while the
     * player has the spell learned. Default no-op.
     */
    default void tickPassive(@NotNull Player caster) {}

    /**
     * For PASSIVE spells: called once when the spell is first applied.
     */
    default void onPassiveApply(@NotNull Player caster) {}

    /**
     * For PASSIVE spells: called once when the spell is removed.
     */
    default void onPassiveRemove(@NotNull Player caster) {}
}
