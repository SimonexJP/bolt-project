package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/** Thunderstorm: calls multiple lightning strikes in an area over time. */
public class ThunderstormSpell extends AbstractSpell {

    private static final double RADIUS = 12.0;
    private static final int STRIKES = 6;
    private static final int STRIKE_DELAY_TICKS = 10;

    public ThunderstormSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "thunderstorm"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getTargetBlockExact(40) != null
                ? caster.getTargetBlockExact(40).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(30));

        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 0.6f);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 60, RADIUS, 4, RADIUS, 0.1);

        new BukkitRunnable() {
            int strikes = 0;

            @Override
            public void run() {
                if (strikes++ >= STRIKES) {
                    cancel();
                    return;
                }
                double angle = Math.random() * Math.PI * 2;
                double dist = Math.random() * RADIUS;
                Location strike = center.clone().add(
                        Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
                caster.getWorld().strikeLightning(strike);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, strike, 50, 1, 2, 1, 0.2);
                caster.getWorld().playSound(strike, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.7f);
                for (var e : caster.getWorld().getNearbyEntities(strike, 3, 5, 3)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(8.0, caster);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, STRIKE_DELAY_TICKS);

        return true;
    }
}
