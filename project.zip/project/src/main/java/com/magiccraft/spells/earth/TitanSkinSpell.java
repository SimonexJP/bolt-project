package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.PassiveSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

/** Titan Skin: PASSIVE - grants resistance and slowness on apply, spawns stone particles on tick, removes effects on remove. */
public class TitanSkinSpell extends PassiveSpell {

    public TitanSkinSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "titan_skin"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public void onPassiveApply(@NotNull Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 0));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1.0f, 0.5f);
        caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation().add(0, 1, 0), 30, 0.8, 1.5, 0.8, 0.05);
    }

    @Override
    public void tickPassive(@NotNull Player caster) {
        caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation().add(0, 1, 0), 8, 0.6, 1.2, 0.6, 0.03);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 0.5, 0), 3, 0.5, 0.5, 0.5, 0.0);
    }

    @Override
    public void onPassiveRemove(@NotNull Player caster) {
        caster.removePotionEffect(PotionEffectType.RESISTANCE);
        caster.removePotionEffect(PotionEffectType.SLOWNESS);
        caster.getWorld().spawnParticle(Particle.CLOUD, caster.getLocation().add(0, 1, 0), 40, 1, 1.5, 1, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_BREAK, 1.0f, 0.6f);
    }
}
