package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Mirror Ice: creates an ice mirror around the caster that reflects projectiles and grants resistance. */
public class MirrorIceSpell extends AbstractSpell {

    public MirrorIceSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "mirror_ice"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0));

        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_PLACE, 1.5f, 1.5f);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_PLAYER_HURT_FREEZE, 0.8f, 1.2f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 200) {
                    cancel();
                    return;
                }
                Location center = caster.getLocation().add(0, 1, 0);
                // Spinning mirror ring.
                double angle = (ticks * 0.3) % (Math.PI * 2);
                for (int i = 0; i < 6; i++) {
                    double a = angle + (Math.PI * 2 * i) / 6;
                    Location loc = center.clone().add(Math.cos(a) * 2, 0, Math.sin(a) * 2);
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, loc, 3, 0.05, 0.3, 0.05, 0.0);
                    caster.getWorld().spawnParticle(Particle.FIREWORK, loc, 1, 0.02, 0.1, 0.02, 0.0);
                }

                // Reflect nearby projectiles.
                for (var e : caster.getWorld().getNearbyEntities(center, 3, 3, 3)) {
                    if (e instanceof Projectile proj && proj.getShooter() != caster) {
                        Vector away = proj.getLocation().toVector().subtract(center.toVector()).normalize();
                        proj.setVelocity(away.multiply(proj.getVelocity().length()));
                        proj.setShooter(caster);
                        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, proj.getLocation(), 10, 0.2, 0.2, 0.2, 0.1);
                        caster.getWorld().playSound(proj.getLocation(), Sound.BLOCK_GLASS_BREAK, 0.8f, 2f);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
