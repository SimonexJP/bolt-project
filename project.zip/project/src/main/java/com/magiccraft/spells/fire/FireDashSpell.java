package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Fire Dash: propels caster forward with fire trail, damages entities passed through. */
public class FireDashSpell extends AbstractSpell {

    public FireDashSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "fire_dash"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector direction = caster.getLocation().getDirection().normalize().multiply(1.5);
        direction.setY(0.1);
        caster.setVelocity(direction);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0f, 1.5f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 15) {
                    cancel();
                    return;
                }
                Location trail = caster.getLocation();
                caster.getWorld().spawnParticle(Particle.FLAME, trail, 15, 0.5, 0.5, 0.5, 0.1);
                caster.getWorld().spawnParticle(Particle.LAVA, trail, 3, 0.3, 0.3, 0.3, 0.0);

                for (var e : caster.getWorld().getNearbyEntities(trail, 2.0, 2.0, 2.0)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(5.0, caster);
                        living.setFireTicks(60);
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
