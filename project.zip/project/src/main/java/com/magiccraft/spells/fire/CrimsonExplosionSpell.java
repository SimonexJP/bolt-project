package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Crimson Explosion: red-themed explosion with extra fire damage. */
public class CrimsonExplosionSpell extends AbstractSpell {

    public CrimsonExplosionSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "crimson_explosion"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location target = caster.getTargetBlockExact(25) != null
                ? caster.getTargetBlockExact(25).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(20));

        caster.getWorld().playSound(target, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 1.5f, 0.3f);

        // Red-themed particle burst
        caster.getWorld().spawnParticle(Particle.FLAME, target, 150, 4, 4, 4, 0.4);
        caster.getWorld().spawnParticle(Particle.LAVA, target, 40, 2, 2, 2, 0.2);
        caster.getWorld().spawnParticle(Particle.CRIMSON_SPORE, target, 60, 3, 3, 3, 0.1);
        caster.getWorld().spawnParticle(Particle.SMALL_FLAME, target, 80, 4, 4, 4, 0.2);

        caster.getWorld().createExplosion(target, 4f, false, false);

        for (var e : caster.getWorld().getNearbyEntities(target, 7, 7, 7)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(16.0, caster);
                living.setFireTicks(180);
            }
        }
        return true;
    }
}
