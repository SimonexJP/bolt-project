package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Stone Spear: throws an arrow with a stone trail, dealing high damage. */
public class StoneSpearSpell extends AbstractSpell {

    public StoneSpearSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "stone_spear"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(3.0);
        Arrow proj = caster.launchProjectile(Arrow.class, dir);
        proj.setShooter(caster);
        proj.setGravity(false);
        proj.setDamage(15.0);
        proj.setCritical(false);

        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_HIT, 1f, 1.5f);
        caster.getWorld().spawnParticle(Particle.CRIT, caster.getEyeLocation(), 25, 0.3, 0.3, 0.3, 0.0);

        new org.bukkit.scheduler.BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (proj.isDead() || ticks > 80) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.CRIT, proj.getLocation(), 6, 0.1, 0.1, 0.1, 0.0);
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, proj.getLocation(), 3, 0.2, 0.2, 0.2, 0.0);
                for (var e : proj.getWorld().getNearbyEntities(proj.getLocation(), 1.0, 1.0, 1.0)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(15.0, caster);
                        living.setVelocity(living.getVelocity().setY(0.6));
                        proj.remove();
                        cancel();
                        return;
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
