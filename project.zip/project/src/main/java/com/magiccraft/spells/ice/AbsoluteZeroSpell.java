package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Absolute Zero: freezes all nearby enemies solid for several seconds. */
public class AbsoluteZeroSpell extends AbstractSpell {

    public AbsoluteZeroSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "absolute_zero"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        double radius = 10.0;

        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 200, radius, 2, radius, 0.15);
        caster.getWorld().spawnParticle(Particle.FIREWORK, center, 40, 2, 2, 2, 0.0);
        caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 2f, 0.3f);
        caster.getWorld().playSound(center, Sound.BLOCK_GLASS_BREAK, 1.5f, 0.3f);
        caster.getWorld().playSound(center, Sound.WEATHER_CHANGE_RAIN, 1f, 0.4f);

        for (var e : caster.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(8.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 160, 10));
                living.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 160, -128));
                living.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 160, 3));
                living.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 160, 3));
                living.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
                living.getWorld().spawnParticle(Particle.SNOWFLAKE, living.getLocation().add(0, 1, 0), 30, 0.4, 0.8, 0.4, 0.05);
            }
        }

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks++ >= 160) {
                    cancel();
                    return;
                }
                if (ticks % 20 == 0) {
                    caster.getWorld().spawnParticle(Particle.SNOWFLAKE, center, 30, radius, 2, radius, 0.05);
                    caster.getWorld().playSound(center, Sound.ENTITY_PLAYER_HURT_FREEZE, 0.5f, 0.5f);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
