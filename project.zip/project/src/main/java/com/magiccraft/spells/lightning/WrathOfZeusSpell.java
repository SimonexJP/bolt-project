package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.UltimateSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

/** Wrath of Zeus (ULTIMATE): massive lightning storm with multiple thunderbolts across a wide area. */
public class WrathOfZeusSpell extends UltimateSpell {

    private static final double STORM_RADIUS = 25.0;
    private static final int TOTAL_STRIKES = 12;
    private static final int STRIKE_DELAY_TICKS = 5;
    private static final double STRIKE_DAMAGE = 30.0;
    private static final double FINALE_DAMAGE = 50.0;

    public WrathOfZeusSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "wrath_of_zeus"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    protected boolean executeUltimate(@NotNull Player caster) {
        Location center = caster.getTargetBlockExact(60) != null
                ? caster.getTargetBlockExact(60).getLocation()
                : caster.getLocation().add(caster.getLocation().getDirection().multiply(40));

        // Opening thunder — the sky splits
        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 5f, 0.3f);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 0.4f);
        caster.getWorld().spawnParticle(Particle.FLASH, center, 20, 5, 5, 5, 0);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 200, STORM_RADIUS, 10, STORM_RADIUS, 0.3);

        // Grant caster brief resistance so they survive the storm
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 120, 3));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 120, 0));

        new BukkitRunnable() {
            int strikes = 0;

            @Override
            public void run() {
                if (strikes >= TOTAL_STRIKES) {
                    // Grand finale — central mega strike
                    caster.getWorld().strikeLightning(center);
                    caster.getWorld().strikeLightning(center.clone().add(2, 0, 2));
                    caster.getWorld().strikeLightning(center.clone().add(-2, 0, -2));
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center, 500, STORM_RADIUS, 15, STORM_RADIUS, 1.0);
                    caster.getWorld().spawnParticle(Particle.FLASH, center, 30, 3, 3, 3, 0);
                    caster.getWorld().spawnParticle(Particle.EXPLOSION, center, 10, 2, 2, 2, 0);
                    caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 5f, 0.5f);
                    caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 5f, 0.3f);

                    for (var e : caster.getWorld().getNearbyEntities(center, STORM_RADIUS, STORM_RADIUS, STORM_RADIUS)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(FINALE_DAMAGE, caster);
                            living.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0));
                        }
                    }
                    cancel();
                    return;
                }
                strikes++;

                // Random strike within the storm radius
                double angle = Math.random() * Math.PI * 2;
                double dist = Math.random() * STORM_RADIUS;
                Location strike = center.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);

                // Beam from sky visual
                for (int y = 0; y < 30; y += 3) {
                    Location beam = strike.clone().add(0, y, 0);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, beam, 8, 0.2, 0.2, 0.2, 0.1);
                }

                caster.getWorld().strikeLightning(strike);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, strike, 80, 2, 3, 2, 0.3);
                caster.getWorld().spawnParticle(Particle.FLASH, strike, 5, 1, 1, 1, 0);
                caster.getWorld().playSound(strike, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3f, 0.5f + (float) (Math.random() * 0.5));

                // Damage enemies near each strike
                for (var e : caster.getWorld().getNearbyEntities(strike, 5, 8, 5)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(STRIKE_DAMAGE, caster);
                        living.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0));
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, STRIKE_DELAY_TICKS);

        return true;
    }
}
