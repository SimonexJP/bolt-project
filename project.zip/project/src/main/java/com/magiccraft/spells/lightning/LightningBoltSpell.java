package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Lightning Bolt: fires a fast lightning-charged projectile forward. */
public class LightningBoltSpell extends AbstractSpell {

    public LightningBoltSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "lightning_bolt"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().normalize();
        Location start = caster.getEyeLocation().add(dir.clone().multiply(1.5));
        Arrow bolt = caster.getWorld().spawn(start, Arrow.class);
        bolt.setShooter(caster);
        bolt.setVelocity(dir.multiply(3.0));
        bolt.setCritical(true);
        bolt.setGlowing(true);

        caster.getWorld().playSound(start, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.6f, 1.8f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (bolt.isDead() || !bolt.isValid() || ticks++ > 60) {
                    cancel();
                    return;
                }
                Location loc = bolt.getLocation();
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 8, 0.2, 0.2, 0.2, 0.05);
                for (var e : caster.getWorld().getNearbyEntities(loc, 1.5, 1.5, 1.5)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(10.0, caster);
                        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 30, 0.5, 0.5, 0.5, 0.2);
                        caster.getWorld().playSound(loc, Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1f, 1.5f);
                        bolt.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }
}
