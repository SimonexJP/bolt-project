package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Base class for passive abilities: always-on effects while the spell is
 * learned. No mana cost, no cooldown, no cast action. The
 * {@link com.magiccraft.managers.PassiveManager} ticks these periodically
 * and handles apply/remove lifecycle.
 */
public abstract class PassiveSpell extends AbstractSpell {

    protected PassiveSpell(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    public com.magiccraft.core.enums.SpellType getType() {
        return com.magiccraft.core.enums.SpellType.PASSIVE;
    }

    /** Passives are never cast directly. */
    @Override
    public final boolean cast(@NotNull Player caster) {
        return false;
    }
}
