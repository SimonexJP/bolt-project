package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Sandstorm: creates a swirling sandstorm that blinds and damages nearby enemies. */
public class SandstormSpell extends AbstractSpell {

    public SandstormSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "sandstorm"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.BLOCK_SAND_FALL, 2.0f, 0.5f);
        caster.getWorld().playSound(center, Sound.BLOCK_SAND_PLACE, 1.5f, 0.4f);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks > 120) {
                    cancel();
                    return;
                }

                for (int i = 0; i < 30; i++) {
                    double angle = Math.random() * 2 * Math.PI;
                    double r = Math.random() * 6;
                    double x = center.getX() + r * Math.cos(angle);
                    double z = center.getZ() + r * Math.sin(angle);
                    double y = center.getY() + Math.random() * 4;
                    Location storm = new Location(caster.getWorld(), x, y, z);
                    caster.getWorld().spawnParticle(Particle.CLOUD, storm, 2, 0.3, 0.3, 0.3, 0.05);
                    caster.getWorld().spawnParticle(Particle.SWEEP_ATTACK, storm, 1, 0.2, 0.2, 0.2, 0.0);
                }

                if (ticks % 10 == 0) {
                    for (var e : caster.getWorld().getNearbyEntities(center, 6, 4, 6)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(4.0, caster);
                            living.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0));
                            living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 1));
                        }
                    }
                }
                ticks++;
            }
        }.runTaskTimer(plugin, 0L, 2L);

        return true;
    }
}
