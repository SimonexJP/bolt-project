package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Thorn Prison: traps the nearest target in thorns, damaging over time. */
public class ThornPrisonSpell extends AbstractSpell {

    public ThornPrisonSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "thorn_prison"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        LivingEntity target = null;
        double best = Double.MAX_VALUE;
        for (Entity e : caster.getWorld().getNearbyEntities(loc, 14, 6, 14)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double d = living.getLocation().distanceSquared(loc);
                if (d < best) { best = d; target = living; }
            }
        }
        if (target == null) return false;
        final LivingEntity trapped = target;
        Location tloc = trapped.getLocation();
        trapped.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 4));
        trapped.getWorld().spawnParticle(Particle.CHERRY_LEAVES, tloc, 60, 0.5, 2, 0.5, 0.1);
        trapped.getWorld().playSound(tloc, Sound.BLOCK_ROOTED_DIRT_BREAK, 1f, 0.8f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ >= 5 || trapped.isDead()) {
                    cancel();
                    return;
                }
                trapped.damage(3.0, caster);
                trapped.getWorld().spawnParticle(Particle.CHERRY_LEAVES, trapped.getLocation(), 12, 0.4, 1.5, 0.4, 0.05);
            }
        }.runTaskTimer(plugin, 10L, 10L);
        return true;
    }
}
