package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Voltage Burst: burst of voltage that knocks back and damages enemies. */
public class VoltageBurstSpell extends AbstractSpell {

    private static final double BURST_RADIUS = 7.0;
    private static final double DAMAGE = 10.0;
    private static final double KNOCKBACK_STRENGTH = 2.0;

    public VoltageBurstSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "voltage_burst"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();

        // Burst particles — expanding sphere
        for (int ring = 0; ring < 5; ring++) {
            double r = (ring + 1) * (BURST_RADIUS / 5.0);
            for (int i = 0; i < 30; i++) {
                double angle = (i / 30.0) * Math.PI * 2;
                double y = (ring - 2) * 1.5;
                Location p = center.clone().add(
                        Math.cos(angle) * r, y, Math.sin(angle) * r);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.05, 0.05, 0.05, 0.1);
            }
        }

        caster.getWorld().spawnParticle(Particle.FLASH, center, 3, 1, 1, 1, 0);
        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.2f);
        caster.getWorld().playSound(center, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.8f);

        for (var e : caster.getWorld().getNearbyEntities(center, BURST_RADIUS, BURST_RADIUS, BURST_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(DAMAGE, caster);
                // Radial knockback
                Vector knock = living.getLocation().toVector()
                        .subtract(center.toVector()).normalize().multiply(KNOCKBACK_STRENGTH);
                knock.setY(0.8);
                living.setVelocity(knock);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, living.getLocation(), 15, 0.2, 0.2, 0.2, 0.1);
            }
        }

        return true;
    }
}
