package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Static Field: AoE shock that damages and briefly stuns. */
public class StaticFieldSpell extends AbstractSpell {

    public StaticFieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "static_field"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, caster.getLocation(), 100, 5, 3, 5, 0.2);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.2f);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 6, 4, 6)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(8.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 3));
            }
        }
        return true;
    }
}
