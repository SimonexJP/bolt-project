package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Frost Nova: freezes (slows) and damages all nearby enemies. */
public class FrostNovaSpell extends AbstractSpell {

    public FrostNovaSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "frost_nova"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation(), 60, 4, 2, 4, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_BREAK, 1f, 0.8f);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 5, 5, 5)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(6.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2));
            }
        }
        return true;
    }
}
