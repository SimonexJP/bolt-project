package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Arc Beam: continuous beam of electricity toward target, damage over time. */
public class ArcBeamSpell extends AbstractSpell {

    private static final double RANGE = 30.0;
    private static final double BEAM_RADIUS = 1.5;
    private static final double DAMAGE_PER_TICK = 4.0;
    private static final int DURATION_TICKS = 60;
    private static final int TICK_INTERVAL = 4;

    public ArcBeamSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "arc_beam"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5f, 2f);

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= DURATION_TICKS) {
                    cancel();
                    return;
                }
                elapsed += TICK_INTERVAL;

                Vector dir = caster.getEyeLocation().getDirection().normalize();
                Location beamStart = caster.getEyeLocation();

                // Draw beam particles
                for (double d = 1.0; d < RANGE; d += 0.8) {
                    Location point = beamStart.clone().add(dir.clone().multiply(d));
                    // Zigzag effect
                    double jitterX = (Math.random() - 0.5) * 0.3;
                    double jitterY = (Math.random() - 0.5) * 0.3;
                    double jitterZ = (Math.random() - 0.5) * 0.3;
                    point.add(jitterX, jitterY, jitterZ);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, point, 3, 0.05, 0.05, 0.05, 0.05);

                    // Check for entities at this beam point
                    for (var e : caster.getWorld().getNearbyEntities(point, BEAM_RADIUS, BEAM_RADIUS, BEAM_RADIUS)) {
                        if (e instanceof LivingEntity living && !e.equals(caster)) {
                            living.damage(DAMAGE_PER_TICK, caster);
                            caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, living.getLocation(), 10, 0.2, 0.2, 0.2, 0.1);
                        }
                    }
                }

                // Beam origin effect
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, beamStart, 5, 0.1, 0.1, 0.1, 0.05);

                if (elapsed % 20 == 0) {
                    caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5f, 1.8f);
                }
            }
        }.runTaskTimer(plugin, 0L, TICK_INTERVAL);

        return true;
    }
}
