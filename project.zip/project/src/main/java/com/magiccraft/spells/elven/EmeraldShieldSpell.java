package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Emerald Shield: shields the caster with emerald energy, granting resistance. */
public class EmeraldShieldSpell extends AbstractSpell {

    public EmeraldShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "emerald_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 2));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 0));
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 50, 1, 2, 1, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 0.8f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ > 10) {
                    cancel();
                    return;
                }
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 8, 1.2, 1.2, 1.2, 0.05);
            }
        }.runTaskTimer(plugin, 5L, 5L);
        return true;
    }
}
