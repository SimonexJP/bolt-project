package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Phoenix: launches a burst of fire upward, gives caster regeneration and fire resistance, damages nearby. */
public class PhoenixSpell extends AbstractSpell {

    public PhoenixSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "phoenix"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().playSound(loc, Sound.ENTITY_BLAZE_SHOOT, 1.5f, 1.5f);
        caster.getWorld().playSound(loc, Sound.BLOCK_FIRE_AMBIENT, 1.0f, 0.5f);

        // Upward burst of fire particles
        for (int i = 0; i < 30; i++) {
            double angle = (2 * Math.PI * i) / 30;
            double x = loc.getX() + Math.cos(angle) * 1.5;
            double z = loc.getZ() + Math.sin(angle) * 1.5;
            Location burstPoint = new Location(caster.getWorld(), x, loc.getY(), z);
            caster.getWorld().spawnParticle(Particle.FLAME, burstPoint, 15, 0.2, 3.0, 0.2, 0.1);
            caster.getWorld().spawnParticle(Particle.LAVA, burstPoint, 3, 0.2, 1.0, 0.2, 0.0);
        }

        // Self buffs
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 400, 0));

        // Damage nearby enemies
        for (var e : caster.getWorld().getNearbyEntities(loc, 6, 6, 6)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(8.0, caster);
                living.setFireTicks(100);
            }
        }
        return true;
    }
}
