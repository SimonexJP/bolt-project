package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Flame Wave: sends a wave of fire forward, damaging entities in a line. */
public class FlameWaveSpell extends AbstractSpell {

    public FlameWaveSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "flame_wave"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Vector direction = caster.getLocation().getDirection().normalize();
        Location start = caster.getLocation().add(0, 1, 0);
        caster.getWorld().playSound(caster.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1f, 0.6f);

        new BukkitRunnable() {
            int distance = 0;

            @Override
            public void run() {
                if (distance > 15) {
                    cancel();
                    return;
                }
                Location current = start.clone().add(direction.clone().multiply(distance));
                caster.getWorld().spawnParticle(Particle.FLAME, current, 20, 1.5, 0.5, 1.5, 0.05);
                caster.getWorld().spawnParticle(Particle.LAVA, current, 5, 1.0, 0.3, 1.0, 0.0);
                for (var e : caster.getWorld().getNearbyEntities(current, 2.0, 2.0, 2.0)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(6.0, caster);
                        living.setFireTicks(80);
                    }
                }
                distance++;
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
