package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Magnetic Pull: pulls all nearby enemies toward caster with electric force. */
public class MagneticPullSpell extends AbstractSpell {

    private static final double PULL_RADIUS = 14.0;
    private static final double DAMAGE = 7.0;
    private static final double PULL_STRENGTH = 1.5;

    public MagneticPullSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "magnetic_pull"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();

        caster.getWorld().playSound(center, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.5f);
        caster.getWorld().playSound(center, Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 0.5f);

        // Magnetic field particles — lines converging on caster
        for (int ring = 0; ring < 4; ring++) {
            double r = (ring + 1) * (PULL_RADIUS / 4.0);
            for (int i = 0; i < 24; i++) {
                double angle = (i / 24.0) * Math.PI * 2;
                Location p = center.clone().add(
                        Math.cos(angle) * r, 0.5, Math.sin(angle) * r);
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, p, 3, 0.05, 0.1, 0.05, 0.05);
            }
        }

        // Caster aura
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, center.add(0, 1, 0), 40, 1, 1, 1, 0.2);

        for (var e : caster.getWorld().getNearbyEntities(center, PULL_RADIUS, PULL_RADIUS, PULL_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                // Pull toward caster
                Vector pull = center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(PULL_STRENGTH);
                pull.setY(0.4);
                living.setVelocity(pull);

                living.damage(DAMAGE, caster);
                living.addPotionEffect(new org.bukkit.potion.PotionEffect(
                        org.bukkit.potion.PotionEffectType.SLOWNESS, 40, 1));

                // Electric trail from enemy to caster
                Vector step = center.toVector().subtract(living.getLocation().toVector()).normalize().multiply(0.5);
                Location cursor = living.getLocation().clone();
                double dist = living.getLocation().distance(center);
                int points = (int) (dist / 0.5);
                for (int i = 0; i < points; i++) {
                    cursor.add(step);
                    caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, cursor, 2, 0.05, 0.05, 0.05, 0.02);
                }
            }
        }

        return true;
    }
}
