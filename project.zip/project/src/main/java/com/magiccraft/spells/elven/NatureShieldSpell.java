package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Nature Shield: resistance + regeneration. */
public class NatureShieldSpell extends AbstractSpell {

    public NatureShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "nature_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1f);
        return true;
    }
}
