package com.magiccraft.spells.ice;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Blizzard: large AoE damage + freezing. */
public class BlizzardSpell extends AbstractSpell {

    public BlizzardSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "blizzard"; }

    @Override
    public FactionType getFaction() { return FactionType.ICE; }

    @Override
    public boolean cast(Player caster) {
        caster.getWorld().spawnParticle(Particle.SNOWFLAKE, caster.getLocation(), 150, 8, 4, 8, 0.2);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.5f, 0.5f);
        for (var e : caster.getWorld().getNearbyEntities(caster.getLocation(), 10, 6, 10)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(14.0, caster);
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 160, 3));
                living.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 160, 1));
            }
        }
        return true;
    }
}
