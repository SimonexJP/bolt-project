package com.magiccraft.spells.fire;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

/** Burning Chains: chains nearby enemies with fire, pulling them toward caster and igniting. */
public class BurningChainsSpell extends AbstractSpell {

    public BurningChainsSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "burning_chains"; }

    @Override
    public FactionType getFaction() { return FactionType.FIRE; }

    @Override
    public boolean cast(Player caster) {
        Location casterLoc = caster.getLocation();
        caster.getWorld().playSound(casterLoc, Sound.BLOCK_FIRE_AMBIENT, 1.0f, 0.6f);

        boolean hit = false;
        for (var e : caster.getWorld().getNearbyEntities(casterLoc, 12, 12, 12)) {
            if (!(e instanceof LivingEntity living) || e.equals(caster)) continue;
            hit = true;

            // Draw chain particles between caster and target
            Location targetLoc = living.getLocation().add(0, 1, 0);
            Location fromLoc = casterLoc.clone().add(0, 1, 0);
            Vector toTarget = targetLoc.toVector().subtract(fromLoc.toVector());
            double distance = toTarget.length();
            toTarget.normalize();
            for (double d = 0; d < distance; d += 0.5) {
                Location chainPoint = fromLoc.clone().add(toTarget.clone().multiply(d));
                caster.getWorld().spawnParticle(Particle.FLAME, chainPoint, 3, 0.1, 0.1, 0.1, 0.0);
            }

            // Pull target toward caster
            Vector pullDir = casterLoc.toVector().subtract(living.getLocation().toVector()).normalize().multiply(1.2);
            pullDir.setY(0.3);
            living.setVelocity(pullDir);

            living.setFireTicks(120);
            living.damage(5.0, caster);
        }
        return hit;
    }
}
