package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Forest Wrath: powerful AoE nature damage. */
public class ForestWrathSpell extends AbstractSpell {

    public ForestWrathSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "forest wrath"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 200, 8, 4, 8, 0.3);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 50, 6, 3, 6, 0.2);
        caster.getWorld().playSound(loc, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 0.6f);
        for (var e : caster.getWorld().getNearbyEntities(loc, 9, 5, 9)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.damage(15.0, caster);
                living.setVelocity(living.getVelocity().setY(1.0));
            }
        }
        return true;
    }
}
