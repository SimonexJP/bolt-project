package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Ancient Wisdom: grants the caster wisdom, restoring health and giving regeneration. */
public class AncientWisdomSpell extends AbstractSpell {

    public AncientWisdomSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "ancient_wisdom"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        caster.setHealth(Math.min(caster.getMaxHealth(), caster.getHealth() + 10.0));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 200, 0));
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getLocation().add(0, 1, 0), 40, 1, 2, 1, 0.05);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 30, 1, 2, 1, 0.05);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.0f);
        return true;
    }
}
