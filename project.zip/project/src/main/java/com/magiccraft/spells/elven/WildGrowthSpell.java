package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

/** Wild Growth: rapid plant growth roots enemies in place and damages them. */
public class WildGrowthSpell extends AbstractSpell {

    public WildGrowthSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "wild_growth"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Location loc = caster.getLocation();
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 120, 6, 2, 6, 0.2);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, loc, 40, 6, 2, 6, 0.1);
        caster.getWorld().playSound(loc, Sound.BLOCK_ROOTED_DIRT_BREAK, 1.3f, 0.6f);

        for (Entity e : caster.getWorld().getNearbyEntities(loc, 7, 4, 7)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 120, 3));
                living.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 120, 1));
            }
        }
        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks++ >= 4) {
                    cancel();
                    return;
                }
                for (Entity e : caster.getWorld().getNearbyEntities(loc, 7, 4, 7)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(4.0, caster);
                    }
                }
                caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, loc, 20, 5, 2, 5, 0.1);
            }
        }.runTaskTimer(plugin, 15L, 15L);
        return true;
    }
}
