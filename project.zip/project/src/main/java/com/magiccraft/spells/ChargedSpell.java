package com.magiccraft.spells;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.SpellTier;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Base class for spells that are held to charge and released at higher power.
 * The charge percentage (0.0 to 1.0) scales damage, particle count, and area.
 *
 * <p>Charging is detected by the wand interaction listener: while the player
 * holds right-click, charge accumulates; on release, {@link #castCharged}
 * is called with the accumulated percentage.
 */
public abstract class ChargedSpell extends AbstractSpell {

    protected ChargedSpell(MagicPlugin plugin) {
        super(plugin);
    }

    /** Normal cast delegates to a minimum-charge charged cast. */
    @Override
    public boolean cast(@NotNull Player caster) {
        return castCharged(caster, 0.25);
    }

    @Override
    public boolean castCharged(@NotNull Player caster, double chargePercent) {
        SpellTier tier = tier(plugin, caster);
        double scaled = Math.max(0.1, chargePercent);
        return executeCharged(caster, scaled, tier);
    }

    /**
     * Spell effect at the given charge level and evolution tier.
     *
     * @param caster         the player releasing the charge
     * @param chargePercent  0.1 (tap) to 1.0 (full charge)
     * @param tier           current evolution tier
     * @return true if successful
     */
    protected abstract boolean executeCharged(@NotNull Player caster, double chargePercent, @NotNull SpellTier tier);
}
