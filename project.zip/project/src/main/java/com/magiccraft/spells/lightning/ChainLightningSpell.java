package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** Chain Lightning: lightning that jumps between nearby enemies. */
public class ChainLightningSpell extends AbstractSpell {

    private static final double JUMP_RADIUS = 8.0;
    private static final int MAX_JUMPS = 5;
    private static final double DAMAGE_PER_JUMP = 9.0;

    public ChainLightningSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "chain_lightning"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Location start = caster.getEyeLocation();
        LivingEntity first = null;
        double closest = Double.MAX_VALUE;
        for (var e : caster.getWorld().getNearbyEntities(start, 15, 8, 15)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                double dist = living.getLocation().distanceSquared(start);
                if (dist < closest) {
                    closest = dist;
                    first = living;
                }
            }
        }

        if (first == null) {
            Location fallback = caster.getLocation().add(caster.getLocation().getDirection().multiply(20));
            caster.getWorld().strikeLightning(fallback);
            return true;
        }

        List<LivingEntity> hit = new ArrayList<>();
        hit.add(first);
        strikeChain(caster, start, first, hit, 0);

        caster.getWorld().playSound(start, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.6f);
        return true;
    }

    private void strikeChain(Player caster, Location from, LivingEntity target, List<LivingEntity> hit, int depth) {
        if (depth >= MAX_JUMPS) return;

        // Visual arc from previous position to target
        drawArc(caster, from, target.getLocation());

        target.damage(DAMAGE_PER_JUMP - depth, caster);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, target.getLocation(), 40, 0.5, 0.5, 0.5, 0.2);
        caster.getWorld().playSound(target.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.8f, 1.8f);

        // Find next jump target
        LivingEntity next = null;
        double closest = Double.MAX_VALUE;
        for (var e : caster.getWorld().getNearbyEntities(target.getLocation(), JUMP_RADIUS, JUMP_RADIUS, JUMP_RADIUS)) {
            if (e instanceof LivingEntity living && !e.equals(caster) && !hit.contains(living)) {
                double dist = living.getLocation().distanceSquared(target.getLocation());
                if (dist < closest) {
                    closest = dist;
                    next = living;
                }
            }
        }

        if (next != null) {
            hit.add(next);
            strikeChain(caster, target.getLocation(), next, hit, depth + 1);
        }
    }

    private void drawArc(Player caster, Location from, Location to) {
        Vector step = to.toVector().subtract(from.toVector());
        double length = step.length();
        step.normalize().multiply(0.5);
        int points = (int) Math.max(1, length / 0.5);
        Location cursor = from.clone();
        for (int i = 0; i < points; i++) {
            cursor.add(step);
            caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, cursor, 4, 0.1, 0.1, 0.1, 0.02);
        }
    }
}
