package com.magiccraft.spells.lightning;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Electric Spear: throws a spear of lightning (trident) that shocks enemies. */
public class ElectricSpearSpell extends AbstractSpell {

    public ElectricSpearSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "electric_spear"; }

    @Override
    public FactionType getFaction() { return FactionType.LIGHTNING; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(2.5);
        Arrow spear = caster.launchProjectile(Arrow.class, dir);
        spear.setShooter(caster);
        spear.setCritical(true);
        spear.setGlowing(true);

        Location start = caster.getEyeLocation();
        caster.getWorld().playSound(start, Sound.ITEM_TRIDENT_THROW, 1f, 1.5f);
        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, start, 30, 0.3, 0.3, 0.3, 0.1);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (spear.isDead() || spear.isOnGround() || ticks++ > 60) {
                    cancel();
                    return;
                }
                Location loc = spear.getLocation();
                caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, loc, 10, 0.2, 0.2, 0.2, 0.08);
                for (var e : caster.getWorld().getNearbyEntities(loc, 2, 2, 2)) {
                    if (e instanceof LivingEntity living && !e.equals(caster) && !e.equals(spear)) {
                        living.damage(12.0, caster);
                        caster.getWorld().strikeLightning(living.getLocation());
                        caster.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, living.getLocation(), 40, 0.5, 0.5, 0.5, 0.2);
                        caster.getWorld().playSound(living.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1f, 1.2f);
                        spear.remove();
                        cancel();
                        return;
                    }
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);

        return true;
    }
}
