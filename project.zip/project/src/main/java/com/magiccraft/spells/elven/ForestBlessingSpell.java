package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Forest Blessing: blesses the caster with regen, resistance, and speed. */
public class ForestBlessingSpell extends AbstractSpell {

    public ForestBlessingSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "forest_blessing"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 200, 0));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 1));
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 40, 1.5, 2, 1.5, 0.08);
        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation(), 20, 1.5, 2, 1.5, 0.08);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.1f);
        return true;
    }
}
