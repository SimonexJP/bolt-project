package com.magiccraft.spells.elven;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Celestial Arrow: fires an arrow of starlight that deals high damage. */
public class CelestialArrowSpell extends AbstractSpell {

    public CelestialArrowSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "celestial_arrow"; }

    @Override
    public FactionType getFaction() { return FactionType.ELVEN; }

    @Override
    public boolean cast(Player caster) {
        Vector dir = caster.getLocation().getDirection().multiply(3.5);
        Arrow arrow = caster.launchProjectile(Arrow.class, dir);
        arrow.setShooter(caster);
        arrow.setDamage(15.0);
        arrow.setCritical(true);
        caster.getWorld().spawnParticle(Particle.END_ROD, caster.getEyeLocation(), 30, 0.3, 0.3, 0.3, 0.1);
        caster.getWorld().playSound(caster.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1.2f, 2.0f);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (arrow.isDead() || !arrow.isValid() || ticks++ > 60) {
                    cancel();
                    return;
                }
                arrow.getWorld().spawnParticle(Particle.END_ROD, arrow.getLocation(), 8, 0.1, 0.1, 0.1, 0.02);
                arrow.getWorld().spawnParticle(Particle.CHERRY_LEAVES, arrow.getLocation(), 3, 0.1, 0.1, 0.1, 0.01);
            }
        }.runTaskTimer(plugin, 1L, 1L);
        return true;
    }
}
