package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

/** Mountain Slam: caster jumps up then slams down for AoE damage and knockup. */
public class MountainSlamSpell extends AbstractSpell {

    public MountainSlamSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "mountain_slam"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        caster.setVelocity(caster.getVelocity().setY(1.2));
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_STONE_PLACE, 1f, 0.5f);
        caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, caster.getLocation(), 30, 1, 0.5, 1, 0.1);

        new BukkitRunnable() {
            int ticks = 0;

            @Override
            public void run() {
                if (ticks < 15) {
                    caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, caster.getLocation(), 5, 0.5, 0.5, 0.5, 0.0);
                    ticks++;
                    return;
                }

                // Slam down
                Location slam = caster.getLocation();
                caster.getWorld().playSound(slam, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.3f);
                caster.getWorld().playSound(slam, Sound.BLOCK_STONE_BREAK, 2.0f, 0.4f);
                caster.getWorld().spawnParticle(Particle.LARGE_SMOKE, slam, 150, 5, 1, 5, 0.5);
                caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, slam, 80, 6, 2, 6, 0.3);

                for (var e : caster.getWorld().getNearbyEntities(slam, 7, 4, 7)) {
                    if (e instanceof LivingEntity living && !e.equals(caster)) {
                        living.damage(14.0, caster);
                        Vector away = living.getLocation().toVector().subtract(slam.toVector()).normalize().multiply(1.2);
                        living.setVelocity(away.setY(1.0));
                    }
                }
                cancel();
            }
        }.runTaskTimer(plugin, 0L, 1L);

        return true;
    }
}
