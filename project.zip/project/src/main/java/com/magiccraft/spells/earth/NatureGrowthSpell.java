package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Nature Growth: grows vines that heal the caster and nearby allies. */
public class NatureGrowthSpell extends AbstractSpell {

    public NatureGrowthSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "nature_growth"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        Location center = caster.getLocation();
        caster.getWorld().playSound(center, Sound.BLOCK_ROOTED_DIRT_PLACE, 1.5f, 1.0f);
        caster.getWorld().playSound(center, Sound.BLOCK_ROOTS_PLACE, 1.0f, 1.2f);

        // Vine particle ring
        for (int i = 0; i < 36; i++) {
            double angle = (i * 2 * Math.PI) / 36.0;
            double r = 4;
            Location vine = center.clone().add(r * Math.cos(angle), 0, r * Math.sin(angle));
            caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, vine, 5, 0.3, 1.5, 0.3, 0.02);
            caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, vine, 3, 0.3, 1, 0.3, 0.01);
        }

        // Heal caster
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 2));

        // Heal nearby allies
        for (var e : caster.getWorld().getNearbyEntities(center, 5, 3, 5)) {
            if (e instanceof LivingEntity living && !e.equals(caster)) {
                if (living instanceof Player || living.getType().isAlive()) {
                    living.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
                    living.getWorld().spawnParticle(Particle.HEART, living.getLocation().add(0, 1, 0), 5, 0.5, 0.5, 0.5, 0.0);
                }
            }
        }

        caster.getWorld().spawnParticle(Particle.HEART, center.add(0, 1, 0), 10, 1, 1, 1, 0.0);
        return true;
    }
}
