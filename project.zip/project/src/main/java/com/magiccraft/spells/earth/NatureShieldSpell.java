package com.magiccraft.spells.earth;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.spells.AbstractSpell;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/** Nature Shield: grants resistance and regeneration with nature particles. */
public class NatureShieldSpell extends AbstractSpell {

    public NatureShieldSpell(MagicPlugin plugin) { super(plugin); }

    @Override
    public String getId() { return "nature_shield"; }

    @Override
    public FactionType getFaction() { return FactionType.EARTH; }

    @Override
    public boolean cast(Player caster) {
        caster.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 300, 1));
        caster.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 300, 1));

        caster.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, caster.getLocation().add(0, 1, 0), 40, 1.5, 2, 1.5, 0.05);
        caster.getWorld().spawnParticle(Particle.CHERRY_LEAVES, caster.getLocation().add(0, 1, 0), 20, 1, 1.5, 1, 0.03);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_ROOTED_DIRT_PLACE, 1f, 1.2f);
        caster.getWorld().playSound(caster.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 0.8f);
        return true;
    }
}
