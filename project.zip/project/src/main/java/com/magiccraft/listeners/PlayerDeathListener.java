package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

/** Increments the death statistic. */
public class PlayerDeathListener implements Listener {

    private final MagicPlugin plugin;

    public PlayerDeathListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp != null) mp.getData().getStatistics().addDeath();
    }
}
