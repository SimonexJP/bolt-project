package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.CastCombo;
import com.magiccraft.managers.WandManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Detects wand click combinations and dispatches spell casts.
 *
 * <p>Combination → slot mapping (configurable in config.yml):
 * <ul>
 *   <li>Right click → slot 1</li>
 *   <li>Left click → slot 2</li>
 *   <li>Shift + right click → slot 3</li>
 *   <li>Shift + left click → slot 4</li>
 * </ul>
 */
public class WandInteractListener implements Listener {

    private final MagicPlugin plugin;

    public WandInteractListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action == Action.PHYSICAL) return;
        if (action != Action.LEFT_CLICK_AIR && action != Action.LEFT_CLICK_BLOCK
                && action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        WandManager wands = plugin.getWandManager();
        if (!wands.isWand(item)) return;

        boolean left = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;
        boolean sneaking = player.isSneaking();
        CastCombo combo = CastCombo.of(left, sneaking);

        if (plugin.getCapitalPunishmentManager().getLockManager().isLocked(player)) return;

        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null || !mp.hasFaction()) return;

        int slot = combo.getSlot();
        var spellIdOpt = plugin.getFactionManager().getSlotSpell(
                mp.getData().getFaction(), mp.getData().getLevel(), slot);
        if (spellIdOpt.isEmpty()) return;

        String spellId = spellIdOpt.get();
        if (spellId.equalsIgnoreCase("none")) return;

        if (plugin.getSpellManager().cast(player, spellId, combo)) {
            player.sendMessage(plugin.getMessages().get("spell-cast",
                    plugin.getSpellManager().displayName(spellId)));
        }
    }
}
