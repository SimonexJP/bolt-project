package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.CastCombo;
import com.magiccraft.core.enums.SpellType;
import com.magiccraft.managers.WandManager;
import com.magiccraft.spells.Spell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Detects wand click combinations and dispatches spell casts.
 *
 * <p>Combination → slot mapping (configurable in config.yml):
 * <ul>
 *   <li>Right click → slot 1</li>
 *   <li>Left click → slot 2</li>
 *   <li>Shift + right click → slot 3</li>
 *   <li>Shift + left click → slot 4</li>
 * </ul>
 */
public class WandInteractListener implements Listener {

    private final MagicPlugin plugin;
    private final ConcurrentHashMap<UUID, ChargeData> charging = new ConcurrentHashMap<>();

    public WandInteractListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    private static final class ChargeData {
        final String spellId;
        int ticks;
        final int maxTicks;
        ChargeData(String spellId, int maxTicks) { this.spellId = spellId; this.maxTicks = maxTicks; }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action == Action.PHYSICAL) return;
        if (action != Action.LEFT_CLICK_AIR && action != Action.LEFT_CLICK_BLOCK
                && action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        WandManager wands = plugin.getWandManager();

        if (!wands.isWand(item)) {
            if (plugin.getSpellBookItemManager().isSpellBook(item) && !event.isCancelled()) {
                String spellId = plugin.getSpellBookItemManager().spellId(item);
                if (spellId != null && plugin.getSpellBookManager().learn(player, spellId)) {
                    item.setAmount(item.getAmount() - 1);
                }
            }
            return;
        }

        boolean left = action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK;
        boolean sneaking = player.isSneaking();
        CastCombo combo = CastCombo.of(left, sneaking);

        if (plugin.getCapitalPunishmentManager().getLockManager().isLocked(player)) return;

        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null || !mp.hasFaction()) return;

        int slot = combo.getSlot();
        var spellIdOpt = plugin.getFactionManager().getSlotSpell(
                mp.getData().getFaction(), mp.getData().getLevel(), slot);
        if (spellIdOpt.isEmpty()) return;

        String spellId = spellIdOpt.get();
        if (spellId.equalsIgnoreCase("none")) return;

        Spell spell = plugin.getSpellManager().get(spellId).orElse(null);
        if (spell != null && spell.getType() == SpellType.CHARGED) {
            startCharging(player, spellId, spell.maxChargeTicks());
            return;
        }

        if (plugin.getSpellManager().cast(player, spellId, combo)) {
            player.sendMessage(plugin.getMessages().get("spell-cast",
                    plugin.getSpellManager().displayName(spellId)));
        }
    }

    private void startCharging(Player player, String spellId, int maxTicks) {
        ChargeData data = new ChargeData(spellId, maxTicks);
        charging.put(player.getUniqueId(), data);
        new BukkitRunnable() {
            @Override public void run() {
                ChargeData cd = charging.get(player.getUniqueId());
                if (cd == null || cd != data) { cancel(); return; }
                cd.ticks++;
                if (cd.ticks >= cd.maxTicks) {
                    releaseCharge(player);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1, 1);
    }

    private void releaseCharge(Player player) {
        ChargeData data = charging.remove(player.getUniqueId());
        if (data == null) return;
        double percent = Math.min(1.0, data.ticks / (double) data.maxTicks);
        plugin.getSpellManager().castCharged(player, data.spellId, percent);
        player.sendMessage(plugin.getMessages().get("spell-cast",
                plugin.getSpellManager().displayName(data.spellId)));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onItemHeld(PlayerItemHeldEvent event) {
        charging.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSneakToggle(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) {
            releaseCharge(event.getPlayer());
        }
    }
}
