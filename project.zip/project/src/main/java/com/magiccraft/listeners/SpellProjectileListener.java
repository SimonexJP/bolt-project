package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import com.magiccraft.managers.WandManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Projectile;

/**
 * Handles damage from spell projectiles (snowballs used as ice shards,
 * boulders, leaves) and small fireballs.
 */
public class SpellProjectileListener implements Listener {

    private final MagicPlugin plugin;

    public SpellProjectileListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile proj = event.getEntity();
        if (!(proj.getShooter() instanceof Player caster)) return;
        LivingEntity hit = event.getHitEntity() instanceof LivingEntity le ? le : null;
        if (hit == null || hit.equals(caster)) return;
        double damage = damageFor(proj);
        if (damage > 0) {
            hit.damage(damage, caster);
        }
    }

    private double damageFor(Projectile proj) {
        return switch (proj.getType()) {
            case SNOWBALL -> 6.0;       // ice shard, boulder, leaf burst
            case SMALL_FIREBALL -> 8.0;  // fireball
            case FIREBALL -> 12.0;
            default -> 0;
        };
    }
}
