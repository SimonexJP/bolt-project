package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import com.magiccraft.managers.WandManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Prevents dropping or container-moving the faction wand when configured.
 */
public class WandProtectionListener implements Listener {

    private final MagicPlugin plugin;

    public WandProtectionListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (!plugin.getWandManager().preventDrop()) return;
        if (plugin.getWandManager().isWand(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(plugin.getMessages().get("wand-dropped-blocked"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!plugin.getConfigManager().main().get().getBoolean("wands.prevent-container-move", true)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack current = event.getCurrentItem();
        ItemStack cursor = event.getCursor();
        boolean movingWand = plugin.getWandManager().isWand(current) || plugin.getWandManager().isWand(cursor);
        if (!movingWand) return;
        InventoryType type = event.getInventory().getType();
        if (type == InventoryType.PLAYER || type == InventoryType.CRAFTING || type == InventoryType.CREATIVE) return;
        event.setCancelled(true);
        player.sendMessage(plugin.getMessages().get("wand-dropped-blocked"));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent event) {
        // Keep the wand on death if prevent-drop is on.
        if (!plugin.getWandManager().preventDrop()) return;
        event.getDrops().removeIf(plugin.getWandManager()::isWand);
    }
}
