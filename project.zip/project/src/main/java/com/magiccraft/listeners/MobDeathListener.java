package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

/**
 * Grants XP to a player's killer when a mob dies.
 */
public class MobDeathListener implements Listener {

    private final MagicPlugin plugin;

    public MobDeathListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        EntityType type = event.getEntityType();
        int xp = plugin.getXPManager().forMob(type);
        if (xp <= 0) return;
        var mp = plugin.getPlayerManager().getOrNull(killer);
        if (mp == null) return;
        mp.getData().getStatistics().addMobKill();
        plugin.getLevelManager().addXp(killer, xp, "mob_kill:" + type.name());
    }
}
