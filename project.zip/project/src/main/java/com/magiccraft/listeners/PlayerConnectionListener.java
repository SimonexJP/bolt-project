package com.magiccraft.listeners;

import com.magiccraft.MagicPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Loads player data on join and persists it on quit.
 */
public class PlayerConnectionListener implements Listener {

    private final MagicPlugin plugin;

    public PlayerConnectionListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onJoin(PlayerJoinEvent event) {
        plugin.getPlayerManager().onJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onQuit(PlayerQuitEvent event) {
        plugin.getPlayerManager().onQuit(event.getPlayer());
    }
}
