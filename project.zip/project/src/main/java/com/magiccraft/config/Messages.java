package com.magiccraft.config;

import com.magiccraft.MagicPlugin;
import com.magiccraft.util.TextUtil;

/**
 * Thin accessor over messages.yml. Messages are looked up by path and
 * formatted with {prefix} and positional {n} placeholders.
 */
public class Messages {

    private final MagicPlugin plugin;
    private String cachedPrefix;

    public Messages(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Returns the prefix string (colorized).
     * Reads the raw config value directly to avoid calling get() which
     * would cause infinite recursion via getPrefix().
     */
    public String getPrefix() {
        if (cachedPrefix == null) {
            String raw = plugin.getConfigManager().get(ConfigManager.MESSAGES).get().getString("prefix", "");
            cachedPrefix = TextUtil.color(raw);
        }
        return cachedPrefix;
    }

    /** Reloads the cached prefix (called after a config reload). */
    public void refresh() {
        cachedPrefix = null;
    }

    public String get(String path, Object... args) {
        String raw = plugin.getConfigManager().get(ConfigManager.MESSAGES).get().getString(path, path);
        return TextUtil.format(raw, getPrefix(), args);
    }

    public String raw(String path, Object... args) {
        String raw = plugin.getConfigManager().get(ConfigManager.MESSAGES).get().getString(path, path);
        return TextUtil.format(raw, "", args);
    }
}
