package com.magiccraft.config;

import com.magiccraft.MagicPlugin;
import com.magiccraft.util.TextUtil;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Objects;

/**
 * Loads and caches a named YAML config file from the plugin data folder,
 * copying the bundled resource on first access.
 */
public class YamlConfig {

    private final MagicPlugin plugin;
    private final String fileName;
    private File file;
    private FileConfiguration config;

    public YamlConfig(MagicPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.fileName = fileName;
    }

    public void load() {
        file = new File(plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            plugin.saveResource(fileName, false);
        }
        config = YamlConfiguration.loadConfiguration(file);
        // Merge defaults from the bundled resource so new keys appear automatically.
        try (InputStreamReader reader = new InputStreamReader(
                Objects.requireNonNull(plugin.getResource(fileName), "Missing bundled resource: " + fileName))) {
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration(reader);
            config.setDefaults(defaults);
            config.options().copyDefaults(true);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to load defaults for " + fileName + ": " + e.getMessage());
        }
        save();
    }

    public void save() {
        try {
            config.save(file);
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to save " + fileName + ": " + e.getMessage());
        }
    }

    public void reload() {
        load();
    }

    public FileConfiguration get() {
        return config;
    }

    public String msg(String path, Object... args) {
        return TextUtil.format(config.getString(path, path), plugin.getMessages().getPrefix(), args);
    }

    public List<String> msgList(String path) {
        return TextUtil.color(config.getStringList(path));
    }
}
