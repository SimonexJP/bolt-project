package com.magiccraft.config;

import com.magiccraft.MagicPlugin;

import java.util.HashMap;
import java.util.Map;

/**
 * Central registry of all YAML config files. Provides typed accessors.
 */
public class ConfigManager {

    private final MagicPlugin plugin;
    private final Map<String, YamlConfig> configs = new HashMap<>();

    public static final String MAIN = "config.yml";
    public static final String MESSAGES = "messages.yml";
    public static final String XP = "xp.yml";
    public static final String FACTIONS = "factions.yml";
    public static final String SPELLS = "spells.yml";
    public static final String MANA = "mana.yml";
    public static final String COOLDOWNS = "cooldowns.yml";
    public static final String DATABASE = "database.yml";
    public static final String CAPITAL_PUNISHMENT = "capitalpunishment.yml";
    public static final String FACTION_SYSTEM = "factionsystem.yml";
    public static final String DUEL = "duel.yml";
    public static final String TOURNAMENT = "tournament.yml";

    public ConfigManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        register(MAIN);
        register(MESSAGES);
        register(XP);
        register(FACTIONS);
        register(SPELLS);
        register(MANA);
        register(COOLDOWNS);
        register(DATABASE);
        register(CAPITAL_PUNISHMENT);
        register(FACTION_SYSTEM);
        register(DUEL);
        register(TOURNAMENT);
    }

    public void reloadAll() {
        configs.values().forEach(YamlConfig::reload);
    }

    public YamlConfig get(String name) {
        YamlConfig cfg = configs.get(name);
        if (cfg == null) {
            cfg = new YamlConfig(plugin, name);
            cfg.load();
            configs.put(name, cfg);
        }
        return cfg;
    }

    public YamlConfig main() { return get(MAIN); }
    public YamlConfig xp() { return get(XP); }
    public YamlConfig factions() { return get(FACTIONS); }
    public YamlConfig spells() { return get(SPELLS); }
    public YamlConfig mana() { return get(MANA); }
    public YamlConfig cooldowns() { return get(COOLDOWNS); }
    public YamlConfig database() { return get(DATABASE); }
    public YamlConfig tournament() { return get(TOURNAMENT); }

    private void register(String name) {
        YamlConfig cfg = new YamlConfig(plugin, name);
        cfg.load();
        configs.put(name, cfg);
    }
}
