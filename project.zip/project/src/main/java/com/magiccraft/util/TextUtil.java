package com.magiccraft.util;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;

/**
 * Small text utilities: color translation and placeholder substitution.
 */
public final class TextUtil {

    private TextUtil() {}

    public static String color(String input) {
        if (input == null) return "";
        return ChatColor.translateAlternateColorCodes('&', input);
    }

    public static List<String> color(List<String> input) {
        List<String> out = new ArrayList<>(input.size());
        for (String s : input) out.add(color(s));
        return out;
    }

    /**
     * Replaces {prefix}, {0}, {1}, ... in the template with the supplied args.
     * The first arg is NOT the prefix; the prefix is injected separately.
     */
    public static String format(String template, String prefix, Object... args) {
        if (template == null) return "";
        String result = template.replace("{prefix}", prefix == null ? "" : prefix);
        for (int i = 0; i < args.length; i++) {
            result = result.replace("{" + i + "}", String.valueOf(args[i]));
        }
        return color(result);
    }
}
