package com.magiccraft.capitalpunishment;

import com.magiccraft.MagicPlugin;
import com.magiccraft.commands.SafeCommandExecutor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * /penacapitale <player> <reason>   — initiates a Capital Punishment event.
 * /penacapitale <player> cancel     — cancels an active event (no punishment applied).
 *
 * <p>Permission: {@code magiccraft.capitalpunishment} (founder/admin only).
 */
public class CapitalPunishmentCommand extends SafeCommandExecutor {

    public CapitalPunishmentCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (!sender.hasPermission("magiccraft.capitalpunishment")) {
            sender.sendMessage(plugin.getMessages().get("capitalpunishment-no-permission"));
            return;
        }
        if (args.length < 1) {
            sender.sendMessage(plugin.getMessages().get("capitalpunishment-usage"));
            return;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getMessages().get("player-not-found", args[0]));
            return;
        }

        // Cancel subcommand.
        if (args.length >= 2 && args[1].equalsIgnoreCase("cancel")) {
            boolean cancelled = plugin.getCapitalPunishmentManager().cancel(target.getUniqueId());
            if (!cancelled) {
                sender.sendMessage(plugin.getMessages().get("capitalpunishment-not-active", target.getName()));
            }
            return;
        }

        if (args.length < 2) {
            sender.sendMessage(plugin.getMessages().get("capitalpunishment-usage"));
            return;
        }

        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

        if (!(sender instanceof Player initiator)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }

        if (plugin.getCapitalPunishmentManager().isActive()) {
            sender.sendMessage(plugin.getMessages().get("capitalpunishment-already-active"));
            return;
        }

        boolean started = plugin.getCapitalPunishmentManager().start(target, reason, initiator);
        if (started) {
            sender.sendMessage(plugin.getMessages().get("capitalpunishment-started", target.getName(), reason));
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 2) {
            List<String> options = new ArrayList<>();
            options.add("cancel");
            return options.stream().filter(o -> o.startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        return List.of();
    }
}
