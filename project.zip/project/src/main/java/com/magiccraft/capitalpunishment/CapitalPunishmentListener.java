package com.magiccraft.capitalpunishment;

import com.magiccraft.MagicPlugin;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Enforces full lockdown for all players locked during a Capital Punishment event.
 * Blocks movement, camera rotation, interactions, combat, commands, inventory,
 * item use, and spell casting.
 */
public class CapitalPunishmentListener implements Listener {

    private final MagicPlugin plugin;
    private final LockManager lockManager;

    public CapitalPunishmentListener(MagicPlugin plugin) {
        this.plugin = plugin;
        this.lockManager = plugin.getCapitalPunishmentManager().getLockManager();
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!lockManager.isLocked(event.getPlayer())) return;
        Player player = event.getPlayer();
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;
        // Block position changes (x, y, z).
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            event.setCancelled(true);
            return;
        }
        // Block camera rotation: restore locked yaw/pitch.
        LockManager.LockedState state = lockManager.getState(player.getUniqueId());
        if (state == null) return;
        if (state.faceTarget() != null) {
            Player target = plugin.getServer().getPlayer(state.faceTarget());
            if (target != null && target.isOnline()) {
                Location lookAt = lookAt(player.getEyeLocation(), target.getLocation().add(0, 1, 0));
                if (to.getYaw() != lookAt.getYaw() || to.getPitch() != lookAt.getPitch()) {
                    player.teleport(lookAt);
                }
            }
        } else {
            if (to.getYaw() != state.yaw() || to.getPitch() != state.pitch()) {
                player.teleport(new Location(to.getWorld(), to.getX(), to.getY(), to.getZ(), state.yaw(), state.pitch()));
            }
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onDropItem(PlayerDropItemEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPickupItem(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player p && lockManager.isLocked(p)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player p && lockManager.isLocked(p)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onItemConsume(PlayerItemConsumeEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onItemHeld(PlayerItemHeldEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onToggleSneak(PlayerToggleSneakEvent event) {
        if (lockManager.isLocked(event.getPlayer())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p && lockManager.isLocked(p)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player p && lockManager.isLocked(p)) {
            event.setCancelled(true);
            event.setFoodLevel(20);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        // Allow only plugin-caused teleports (for arena teleport). Block player-initiated.
        if (lockManager.isLocked(event.getPlayer()) && event.getCause() != PlayerTeleportEvent.TeleportCause.PLUGIN) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!lockManager.isLocked(event.getPlayer())) return;
        String message = event.getMessage();
        List<String> allowed = plugin.getCapitalPunishmentManager().config().get().getStringList("allowedCommands");
        for (String allowedCmd : allowed) {
            if (message.toLowerCase().startsWith(allowedCmd.toLowerCase())) return;
        }
        event.setCancelled(true);
        event.getPlayer().sendMessage(plugin.getMessages().get("capitalpunishment-command-blocked"));
    }

    /** Computes a Location with yaw/pitch looking from 'eye' toward 'target'. */
    private Location lookAt(@NotNull Location eye, @NotNull Location target) {
        double dx = target.getX() - eye.getX();
        double dy = target.getY() - eye.getY();
        double dz = target.getZ() - eye.getZ();
        double r = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(Math.atan2(-dy, r));
        return new Location(eye.getWorld(), eye.getX(), eye.getY(), eye.getZ(), yaw, pitch);
    }
}
