package com.magiccraft.capitalpunishment;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks which players are locked during a Capital Punishment event and
 * stores their frozen location (for camera-lock restoration).
 *
 * <p>The actual event cancellation is handled by {@link CapitalPunishmentListener},
 * which queries this manager on every relevant event.
 */
public class LockManager {

    private final Map<UUID, LockedState> locked = new ConcurrentHashMap<>();

    /** Stores the frozen yaw/pitch and optionally the condemned player to face. */
    public record LockedState(float yaw, float pitch, @Nullable UUID faceTarget) {}

    public void lock(@NotNull Player player, @Nullable Player faceTarget) {
        Location loc = player.getLocation();
        LockedState state = new LockedState(
                loc.getYaw(),
                loc.getPitch(),
                faceTarget != null ? faceTarget.getUniqueId() : null
        );
        locked.put(player.getUniqueId(), state);
    }

    public void unlock(@NotNull Player player) {
        locked.remove(player.getUniqueId());
    }

    public void unlockAll() {
        locked.clear();
    }

    public boolean isLocked(@NotNull UUID uuid) {
        return locked.containsKey(uuid);
    }

    public boolean isLocked(@NotNull Player player) {
        return isLocked(player.getUniqueId());
    }

    public @Nullable LockedState getState(@NotNull UUID uuid) {
        return locked.get(uuid);
    }

    public Set<UUID> lockedPlayers() {
        return locked.keySet();
    }
}
