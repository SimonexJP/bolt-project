package com.magiccraft.capitalpunishment;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.data.model.PlayerData;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Orchestrates the Capital Punishment cinematic: teleport to arena,
 * lock all participants, play phased effects (sounds, particles, titles,
 * BossBar), then execute the punishment (reset on first offense, ban on second+).
 *
 * <p>Persistent tracking is via {@code capitalPunishmentCount} on {@link PlayerData}.
 */
public class CapitalPunishmentManager {

    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.legacyAmpersand();

    private final MagicPlugin plugin;
    private final LockManager lockManager;
    private final Map<UUID, Boolean> activeEvents = new ConcurrentHashMap<>();
    private final Map<UUID, BossBar> activeBossBars = new ConcurrentHashMap<>();
    private final Map<UUID, Map<UUID, Location>> savedLocations = new ConcurrentHashMap<>();

    public CapitalPunishmentManager(MagicPlugin plugin) {
        this.plugin = plugin;
        this.lockManager = new LockManager();
    }

    public LockManager getLockManager() { return lockManager; }

    public YamlConfig config() {
        return plugin.getConfigManager().get(com.magiccraft.config.ConfigManager.CAPITAL_PUNISHMENT);
    }

    public boolean isActive() { return !activeEvents.isEmpty(); }

    public boolean isActiveFor(@NotNull UUID condemned) {
        return activeEvents.containsKey(condemned);
    }

    /**
     * Starts a Capital Punishment event for the condemned player.
     */
    public boolean start(@NotNull Player condemned, @NotNull String reason, @NotNull Player initiator) {
        UUID condemnedId = condemned.getUniqueId();
        if (activeEvents.containsKey(condemnedId)) return false;

        activeEvents.put(condemnedId, true);
        Bukkit.broadcastMessage(plugin.getMessages().raw("capitalpunishment-broadcast-start", condemned.getName()));

        List<Player> participants = gatherParticipants(condemned);
        Map<UUID, Location> locs = new HashMap<>();
        for (Player p : participants) {
            locs.put(p.getUniqueId(), p.getLocation().clone());
        }
        savedLocations.put(condemnedId, locs);

        Location arena = getArenaLocation();
        for (Player p : participants) {
            p.teleport(arena);
            lockManager.lock(p, condemned);
        }

        BossBar bossBar = createBossBar(condemned, reason);
        activeBossBars.put(condemnedId, bossBar);
        for (Player p : participants) {
            p.showBossBar(bossBar);
        }

        runCinematic(condemned, reason, participants, condemnedId);
        return true;
    }

    /**
     * Cancels an active event before execution. Does NOT increment the counter.
     */
    public boolean cancel(@NotNull UUID condemnedId) {
        if (!activeEvents.containsKey(condemnedId)) return false;
        activeEvents.remove(condemnedId);
        cleanupEvent(condemnedId);
        Player condemned = Bukkit.getPlayer(condemnedId);
        String name = condemned != null ? condemned.getName() : condemnedId.toString();
        Bukkit.broadcastMessage(plugin.getMessages().raw("capitalpunishment-cancelled", name));
        return true;
    }

    private void runCinematic(Player condemned, String reason, List<Player> participants, UUID condemnedId) {
        ConfigurationSection phases = config().get().getConfigurationSection("phases");
        if (phases == null) return;

        int introDelay = phases.getInt("intro-delay", 0);
        int effectsDelay = phases.getInt("effects-delay", 60);
        int executionDelay = phases.getInt("execution-delay", 160);
        int cleanupDelay = phases.getInt("cleanup-delay", 200);

        new BukkitRunnable() {
            @Override public void run() {
                if (!activeEvents.containsKey(condemnedId)) return;
                for (Player p : participants) {
                    p.sendTitle(
                            plugin.getMessages().raw("capitalpunishment-title"),
                            plugin.getMessages().raw("capitalpunishment-subtitle", condemned.getName(), reason),
                            10, 50, 10);
                }
                playSoundAt(condemned.getLocation(), config().get().getString("sounds.intro", "ENTITY_ENDER_DRAGON_GROWL"));
            }
        }.runTaskLater(plugin, introDelay);

        new BukkitRunnable() {
            @Override public void run() {
                if (!activeEvents.containsKey(condemnedId)) return;
                Location loc = condemned.getLocation();
                for (int i = 0; i < 5; i++) {
                    loc.getWorld().strikeLightningEffect(loc.clone().add(
                            (Math.random() - 0.5) * 6, 0, (Math.random() - 0.5) * 6));
                }
                spawnParticles(loc, config().get().getString("particles.ambient", "TOTEM_OF_UNDYING"), 100);
                playSoundAt(loc, config().get().getString("sounds.effects", "ENTITY_LIGHTNING_BOLT_THUNDER"));
            }
        }.runTaskLater(plugin, effectsDelay);

        new BukkitRunnable() {
            @Override public void run() {
                if (!activeEvents.containsKey(condemnedId)) return;
                executePunishment(condemned, condemnedId, participants);
            }
        }.runTaskLater(plugin, executionDelay);

        new BukkitRunnable() {
            @Override public void run() {
                cleanupEvent(condemnedId);
            }
        }.runTaskLater(plugin, cleanupDelay);
    }

    private void executePunishment(Player condemned, UUID condemnedId, List<Player> participants) {
        var mp = plugin.getPlayerManager().getOrNull(condemned);
        if (mp == null) return;
        PlayerData data = mp.getData();
        int count = data.getCapitalPunishmentCount();

        condemned.setHealth(0);

        Location loc = condemned.getLocation();
        spawnParticles(loc, config().get().getString("particles.explosion", "EXPLOSION_LARGE"), 50);
        playSoundAt(loc, config().get().getString("sounds.execution", "ENTITY_GENERIC_EXPLODE"));

        for (Player p : participants) {
            p.sendTitle(
                    plugin.getMessages().raw("capitalpunishment-execution-title"),
                    plugin.getMessages().raw("capitalpunishment-execution-subtitle"),
                    5, 30, 10);
        }

        if (count == 0) {
            // First offense: reset the player via console command.
            plugin.getPlayerManager().reset(condemnedId);
            plugin.getPlayerManager().onJoin(condemned);
            var refreshed = plugin.getPlayerManager().getOrNull(condemned);
            if (refreshed != null) {
                refreshed.getData().setCapitalPunishmentCount(1);
                plugin.getDatabaseManager().save(refreshed.getData());
            }
            Bukkit.broadcastMessage(plugin.getMessages().raw("capitalpunishment-first", condemned.getName()));
        } else {
            // Second+ offense: ban the player.
            data.incrementCapitalPunishment();
            plugin.getDatabaseManager().save(data);
            String banReason = config().get().getString("ban-reason", "Capital Pain");
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + condemned.getName() + " " + banReason);
            Bukkit.broadcastMessage(plugin.getMessages().raw("capitalpunishment-second", condemned.getName()));
        }
    }

    private void cleanupEvent(UUID condemnedId) {
        activeEvents.remove(condemnedId);
        BossBar bar = activeBossBars.remove(condemnedId);
        if (bar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                p.hideBossBar(bar);
            }
        }
        for (UUID uuid : lockManager.lockedPlayers()) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) lockManager.unlock(p);
        }
        lockManager.unlockAll();
        savedLocations.remove(condemnedId);
    }

    @NotNull
    private List<Player> gatherParticipants(@NotNull Player condemned) {
        if (config().get().getBoolean("teleport-spectators", true)) {
            return new ArrayList<>(Bukkit.getOnlinePlayers());
        }
        double radius = config().get().getDouble("spectator-radius", 50);
        List<Player> nearby = new ArrayList<>();
        nearby.add(condemned);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(condemned)) continue;
            if (p.getWorld().equals(condemned.getWorld()) && p.getLocation().distance(condemned.getLocation()) <= radius) {
                nearby.add(p);
            }
        }
        return nearby;
    }

    @NotNull
    private Location getArenaLocation() {
        ConfigurationSection arena = config().get().getConfigurationSection("arena");
        if (arena == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        String worldName = arena.getString("world", "default");
        World world = worldName.equals("default") ? Bukkit.getWorlds().get(0) : Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);
        return new Location(world,
                arena.getDouble("x", 0.5),
                arena.getDouble("y", 64),
                arena.getDouble("z", 0.5),
                (float) arena.getDouble("yaw", 0),
                (float) arena.getDouble("pitch", 0));
    }

    private BossBar createBossBar(Player condemned, String reason) {
        String titleTemplate = config().get().getString("bossbar.title", "&c⚠ Capital Punishment: {player} ⚠");
        String title = titleTemplate.replace("{player}", condemned.getName()).replace("{reason}", reason);
        BossBar.Color color = BossBar.Color.valueOf(config().get().getString("bossbar.color", "RED").toUpperCase());
        BossBar.Overlay style = BossBar.Overlay.valueOf(config().get().getString("bossbar.style", "SEGMENTED_10").toUpperCase());
        return BossBar.bossBar(SERIALIZER.deserialize(title), 1f, color, style);
    }

    private void playSoundAt(Location loc, String soundName) {
        try {
            Sound sound = Sound.valueOf(soundName.toUpperCase());
            loc.getWorld().playSound(loc, sound, 1f, 1f);
        } catch (IllegalArgumentException ignored) {}
    }

    private void spawnParticles(Location loc, String particleName, int count) {
        try {
            Particle particle = Particle.valueOf(particleName.toUpperCase());
            loc.getWorld().spawnParticle(particle, loc, count, 2, 2, 2, 0.1);
        } catch (IllegalArgumentException ignored) {}
    }
}
