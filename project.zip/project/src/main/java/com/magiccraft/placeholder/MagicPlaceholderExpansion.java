package com.magiccraft.placeholder;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.data.model.MagicPlayer;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * PlaceholderAPI expansion providing %magic_*% placeholders.
 *
 * <p>Placeholders:
 * <ul>
 *   <li>%magic_level%</li>
 *   <li>%magic_xp%</li>
 *   <li>%magic_rank%</li>
 *   <li>%magic_faction%</li>
 *   <li>%magic_mana%</li>
 *   <li>%magic_maxmana%</li>
 *   <li>%magic_teacher%</li>
 * </ul>
 */
public class MagicPlaceholderExpansion extends PlaceholderExpansion {

    private final MagicPlugin plugin;

    public MagicPlaceholderExpansion(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() { return "magic"; }

    @Override
    public @NotNull String getAuthor() { return "MagicCraft"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "";
        var mp = plugin.getPlayerManager().get(player.getUniqueId());
        if (mp.isEmpty()) return "";

        return switch (params.toLowerCase()) {
            case "level" -> String.valueOf(mp.get().getLevel());
            case "xp" -> String.valueOf(mp.get().getXp());
            case "rank" -> mp.get().getRank().getDisplayName();
            case "faction" -> mp.get().hasFaction() ? mp.get().getData().getFaction().name() : "None";
            case "mana" -> String.valueOf(mp.get().getMana());
            case "maxmana" -> String.valueOf(mp.get().getMaxMana());
            case "teacher" -> isTeacher(mp.get().getLevel()) ? "true" : "false";
            default -> null;
        };
    }

    private boolean isTeacher(int level) {
        Rank rank = Rank.fromLevel(level);
        return rank == Rank.TEACHER || rank == Rank.MASTER_TEACHER || rank == Rank.MAGIC_WANDERER;
    }
}
