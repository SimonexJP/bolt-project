package com.magiccraft.core;

import com.magiccraft.MagicPlugin;

/**
 * Marks a class as part of the MagicPlugin service graph.
 * Implementations typically receive their dependencies via constructor injection.
 */
public interface MagicComponent {
    void onEnable(MagicPlugin plugin);
}
