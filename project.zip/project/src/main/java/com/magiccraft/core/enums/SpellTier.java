package com.magiccraft.core.enums;

/**
 * Spell evolution tiers. Each tier increases damage, mana cost, and
 * visual intensity. Tier is determined by player level thresholds
 * configured per-spell in spells.yml.
 */
public enum SpellTier {
    I(1, 1.0, 1.0, 1.0),
    II(2, 1.25, 1.15, 1.2),
    III(3, 1.6, 1.3, 1.5),
    IV(4, 2.0, 1.5, 2.0);

    private final int tier;
    private final double damageMultiplier;
    private final double manaMultiplier;
    private final double particleMultiplier;

    SpellTier(int tier, double damageMultiplier, double manaMultiplier, double particleMultiplier) {
        this.tier = tier;
        this.damageMultiplier = damageMultiplier;
        this.manaMultiplier = manaMultiplier;
        this.particleMultiplier = particleMultiplier;
    }

    public int getTierNumber() { return tier; }

    public double damageMultiplier() { return damageMultiplier; }
    public double manaMultiplier() { return manaMultiplier; }
    public double particleMultiplier() { return particleMultiplier; }

    public String displayName() { return "I".repeat(tier); }

    public static SpellTier forLevel(int level, int tier2Level, int tier3Level, int tier4Level) {
        if (level >= tier4Level) return IV;
        if (level >= tier3Level) return III;
        if (level >= tier2Level) return II;
        return I;
    }
}
