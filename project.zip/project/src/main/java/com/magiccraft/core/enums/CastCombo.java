package com.magiccraft.core.enums;

/**
 * The four click combinations that can trigger a spell.
 * Each combination maps to a spell "slot" (1-4) in the faction config.
 */
public enum CastCombo {
    RIGHT_CLICK(1),
    LEFT_CLICK(2),
    SHIFT_RIGHT_CLICK(3),
    SHIFT_LEFT_CLICK(4);

    private final int slot;

    CastCombo(int slot) {
        this.slot = slot;
    }

    public int getSlot() {
        return slot;
    }

    public static CastCombo of(boolean left, boolean sneaking) {
        if (sneaking) return left ? SHIFT_LEFT_CLICK : SHIFT_RIGHT_CLICK;
        return left ? LEFT_CLICK : RIGHT_CLICK;
    }
}
