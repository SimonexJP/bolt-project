package com.magiccraft.core.enums;

import java.util.Optional;

/**
 * The five magical factions. To add a new faction, add an enum constant here
 * (or extend the design to register factions by id at runtime) and add a
 * matching entry in factions.yml plus a Faction implementation.
 */
public enum FactionType {
    ICE("❄"),
    FIRE("🔥"),
    EARTH("🌍"),
    LIGHTNING("⚡"),
    ELVEN("🌿");

    private final String icon;

    FactionType(String icon) {
        this.icon = icon;
    }

    public String getIcon() {
        return icon;
    }

    public static Optional<FactionType> fromId(String id) {
        if (id == null) return Optional.empty();
        for (FactionType type : values()) {
            if (type.name().equalsIgnoreCase(id)) return Optional.of(type);
        }
        return Optional.empty();
    }
}
