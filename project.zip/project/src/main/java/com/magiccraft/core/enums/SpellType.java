package com.magiccraft.core.enums;

/**
 * Classifies a spell for the spell engine.
 * <ul>
 *   <li>{@link #ACTIVE} — normal cast-on-click spell.</li>
 *   <li>{@link #CHARGED} — hold to charge; released at higher power.</li>
 *   <li>{@link #ULTIMATE} — long-cooldown signature ability.</li>
 *   <li>{@link #PASSIVE} — always-on while learned; no cast action.</li>
 * </ul>
 */
public enum SpellType {
    ACTIVE,
    CHARGED,
    ULTIMATE,
    PASSIVE
}
