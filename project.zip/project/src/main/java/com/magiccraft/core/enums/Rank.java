package com.magiccraft.core.enums;

/**
 * Wizard ranks derived from a player's level.
 *
 * <p>Level ranges:
 * <ul>
 *   <li>1-9   → Apprentice</li>
 *   <li>10-24 → Adept</li>
 *   <li>25-49 → Mage</li>
 *   <li>50-74 → Teacher</li>
 *   <li>75-99 → Master Teacher</li>
 *   <li>100   → Magic Wanderer</li>
 * </ul>
 */
public enum Rank {
    APPRENTICE("Apprentice", 1, 9),
    ADEPT("Adept", 10, 24),
    MAGE("Mage", 25, 49),
    TEACHER("Teacher", 50, 74),
    MASTER_TEACHER("Master Teacher", 75, 99),
    MAGIC_WANDERER("Magic Wanderer", 100, 100);

    private final String displayName;
    private final int minLevel;
    private final int maxLevel;

    Rank(String displayName, int minLevel, int maxLevel) {
        this.displayName = displayName;
        this.minLevel = minLevel;
        this.maxLevel = maxLevel;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getMinLevel() {
        return minLevel;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public static Rank fromLevel(int level) {
        for (Rank rank : values()) {
            if (level >= rank.minLevel && level <= rank.maxLevel) return rank;
        }
        return level >= 100 ? MAGIC_WANDERER : APPRENTICE;
    }
}
