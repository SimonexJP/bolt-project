package com.magiccraft.tournament;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.managers.LeaderboardManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;

/**
 * Manages the Monthly Grand Magic Tournament lifecycle: scheduling,
 * countdown broadcast, arena teleportation, battle phase, winner
 * determination, reward distribution, and leaderboard integration.
 *
 * <p>Thread-safety: participant state is held in {@link ConcurrentHashMap}s.
 * All Bukkit API calls (teleport, broadcast, scheduler) are executed on the
 * main thread via {@link MagicPlugin#sync(Runnable)} or {@link BukkitRunnable}.
 */
public class TournamentManager {

    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.legacyAmpersand();

    /** Tournament phases, in order. */
    public enum Phase {
        IDLE, SCHEDULED, COUNTDOWN, BATTLE, REWARDS, ENDED
    }

    private final MagicPlugin plugin;

    // ── Participant state (thread-safe) ──────────────────────────────
    /** UUIDs of players who have joined the upcoming/active tournament. */
    private final Set<UUID> participants = ConcurrentHashMap.newKeySet();
    /** UUIDs of players spectating the active tournament. */
    private final Set<UUID> spectators = ConcurrentHashMap.newKeySet();
    /** Saved pre-tournament locations for restoration after the event. */
    private final Map<UUID, Location> savedLocations = new ConcurrentHashMap<>();
    /** Elimination order — first eliminated is first in the list. */
    private final List<UUID> eliminationOrder = Collections.synchronizedList(new ArrayList<>());

    // ── Current tournament state ────────────────────────────────────
    private volatile Phase currentPhase = Phase.IDLE;
    private volatile BukkitRunnable activeTask;
    private volatile int currentMonth = -1;

    public TournamentManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    // ════════════════════════════════════════════════════════════════
    // Config access
    // ════════════════════════════════════════════════════════════════

    public YamlConfig config() {
        return plugin.getConfigManager().tournament();
    }

    public void reloadConfig() {
        config().reload();
        plugin.getLogger().info("Tournament config reloaded.");
    }

    // ════════════════════════════════════════════════════════════════
    // State queries
    // ════════════════════════════════════════════════════════════════

    public Phase getCurrentPhase() { return currentPhase; }
    public boolean isActive() { return currentPhase != Phase.IDLE && currentPhase != Phase.ENDED; }
    public boolean isIdle() { return currentPhase == Phase.IDLE; }

    public Set<UUID> getParticipants() { return Collections.unmodifiableSet(participants); }
    public Set<UUID> getSpectators() { return Collections.unmodifiableSet(spectators); }

    /**
     * Adds a player as a spectator and teleports them to the spectator area.
     * Only valid while a tournament is active.
     */
    public boolean spectate(@NotNull Player player) {
        if (!isActive()) return false;
        if (isParticipant(player.getUniqueId())) return false;
        spectators.add(player.getUniqueId());
        return true;
    }

    public boolean isParticipant(@NotNull UUID uuid) { return participants.contains(uuid); }
    public boolean isSpectator(@NotNull UUID uuid) { return spectators.contains(uuid); }

    /** Removes a player from the spectator set (used on disconnect). */
    public void removeSpectator(@NotNull UUID uuid) { spectators.remove(uuid); }

    public int getParticipantCount() { return participants.size(); }

    // ════════════════════════════════════════════════════════════════
    // Join / Leave
    // ════════════════════════════════════════════════════════════════

    /**
     * Adds a player to the participant roster. Only valid during SCHEDULED
     * or COUNTDOWN phases (before the battle begins).
     */
    public boolean join(@NotNull Player player) {
        if (currentPhase != Phase.SCHEDULED && currentPhase != Phase.COUNTDOWN) {
            player.sendMessage(plugin.getMessages().get("tournament-not-joinable"));
            return false;
        }
        int max = config().get().getInt("battle.max-participants", 32);
        if (max > 0 && participants.size() >= max) {
            player.sendMessage(plugin.getMessages().get("tournament-full"));
            return false;
        }
        if (!participants.add(player.getUniqueId())) {
            player.sendMessage(plugin.getMessages().get("tournament-already-joined"));
            return false;
        }
        player.sendMessage(plugin.getMessages().get("tournament-joined",
                participants.size(), config().get().getInt("battle.min-participants", 2)));
        return true;
    }

    /**
     * Removes a player from the participant roster before the battle starts,
     * or eliminates them if the battle is active.
     */
    public boolean leave(@NotNull Player player) {
        UUID uuid = player.getUniqueId();
        if (!participants.contains(uuid) && !spectators.contains(uuid)) {
            player.sendMessage(plugin.getMessages().get("tournament-not-joined"));
            return false;
        }

        if (currentPhase == Phase.BATTLE && participants.contains(uuid)) {
            eliminate(player, "Left the tournament");
            return true;
        }

        participants.remove(uuid);
        spectators.remove(uuid);
        player.sendMessage(plugin.getMessages().get("tournament-left"));
        return true;
    }

    // ════════════════════════════════════════════════════════════════
    // Tournament lifecycle
    // ════════════════════════════════════════════════════════════════

    /**
     * Manually starts the tournament (admin command). Skips the monthly
     * schedule check and begins the countdown immediately.
     */
    public boolean start() {
        if (isActive()) {
            plugin.getLogger().warning("Tournament start requested but one is already active (phase=" + currentPhase + ").");
            return false;
        }
        beginCountdown();
        return true;
    }

    /**
     * Cancels any active tournament, restoring all participants and
     * spectators to their saved locations.
     */
    public boolean cancel() {
        if (!isActive()) return false;
        plugin.getLogger().info("Tournament cancelled during phase " + currentPhase + ".");
        broadcast(announcementsKey("cancelled"));
        cleanup();
        return true;
    }

    /**
     * Checks the monthly schedule and starts the tournament if it is due.
     * Call this from a repeating task (e.g. every minute).
     */
    public void checkSchedule() {
        if (isActive()) return;

        var now = LocalDateTime.now(ZoneId.systemDefault());
        int day = config().get().getInt("schedule.day-of-month", 1);
        int hour = config().get().getInt("schedule.hour", 18);
        int minute = config().get().getInt("schedule.minute", 0);

        int nowMonth = now.getMonthValue();
        if (nowMonth == currentMonth) return; // already ran this month

        if (now.getDayOfMonth() == day && now.getHour() == hour &&
                now.getMinute() == minute && now.getSecond() < 5) {
            currentMonth = nowMonth;
            plugin.getLogger().info("Monthly tournament triggered by schedule (day=" + day + ", hour=" + hour + ").");
            beginCountdown();
        }
    }

    // ── Countdown phase ─────────────────────────────────────────────

    private void beginCountdown() {
        currentPhase = Phase.COUNTDOWN;
        participants.clear();
        spectators.clear();
        savedLocations.clear();
        eliminationOrder.clear();

        int duration = config().get().getInt("countdown.duration", 30);
        List<Integer> announceAt = config().get().getIntList("countdown.announce-at");
        if (announceAt.isEmpty()) announceAt = List.of(30, 20, 10, 5, 4, 3, 2, 1);

        broadcast(announcementsKey("starting"));

        final List<Integer> finalAnnounceAt = announceAt;
        activeTask = new BukkitRunnable() {
            int secondsLeft = duration;

            @Override
            public void run() {
                try {
                    if (currentPhase != Phase.COUNTDOWN) {
                        cancel();
                        return;
                    }
                    if (finalAnnounceAt.contains(secondsLeft)) {
                        broadcast(announcementsKey("countdown"), secondsLeft);
                        playSoundToAll(Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                    }
                    if (secondsLeft <= 0) {
                        cancel();
                        beginBattle();
                        return;
                    }
                    secondsLeft--;
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Error during tournament countdown", e);
                    cancel();
                    cleanup();
                }
            }
        };
        activeTask.runTaskTimer(plugin, 0L, 20L); // every second
    }

    // ── Battle phase ────────────────────────────────────────────────

    private void beginBattle() {
        int minParticipants = config().get().getInt("battle.min-participants", 2);
        if (participants.size() < minParticipants) {
            plugin.getLogger().warning("Tournament cancelled: only " + participants.size()
                    + " participants (minimum " + minParticipants + ").");
            broadcast(announcementsKey("not-enough-players"), participants.size(), minParticipants);
            cleanup();
            return;
        }

        currentPhase = Phase.BATTLE;

        // Teleport participants to arena, spectators to spectator point.
        Location arena = getArenaLocation();
        Location specLoc = getSpectatorLocation();
        for (UUID uuid : participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                savedLocations.put(uuid, p.getLocation().clone());
                p.teleport(arena);
            } else {
                // Offline — remove from participants.
                participants.remove(uuid);
            }
        }
        for (UUID uuid : spectators) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                savedLocations.put(uuid, p.getLocation().clone());
                p.teleport(specLoc);
            }
        }

        broadcast(announcementsKey("started"), participants.size());
        playSoundToAll(Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 0.8f);

        int battleDuration = config().get().getInt("battle.duration", 300);
        activeTask = new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                try {
                    if (currentPhase != Phase.BATTLE) {
                        cancel();
                        return;
                    }
                    elapsed++;
                    // Check for a winner every 5 seconds or when only 1 remains.
                    if (participants.size() <= 1) {
                        cancel();
                        beginRewards();
                        return;
                    }
                    if (elapsed >= battleDuration) {
                        cancel();
                        // Time's up — pick survivor by lowest health, or random.
                        determineWinnerByTimeout();
                        beginRewards();
                    }
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Error during tournament battle", e);
                    cancel();
                    cleanup();
                }
            }
        };
        activeTask.runTaskTimer(plugin, 20L, 20L); // check every second
    }

    /**
     * Eliminates a participant (called on death, disconnect, or voluntary leave).
     */
    public void eliminate(@NotNull Player player, @NotNull String reason) {
        UUID uuid = player.getUniqueId();
        if (!participants.remove(uuid)) return;

        eliminationOrder.add(uuid);
        plugin.getLogger().info("Participant eliminated: " + player.getName() + " (" + reason + "). "
                + participants.size() + " remaining.");

        // Teleport to spectator area.
        Location specLoc = getSpectatorLocation();
        player.teleport(specLoc);
        spectators.add(uuid);
        player.sendMessage(plugin.getMessages().get("tournament-eliminated", reason));

        if (participants.size() <= 1) {
            plugin.sync(this::beginRewards);
        }
    }

    private void determineWinnerByTimeout() {
        if (participants.isEmpty()) return;
        Player winner = null;
        double maxHealth = -1;
        for (UUID uuid : participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null || !p.isOnline()) continue;
            if (p.getHealth() > maxHealth) {
                maxHealth = p.getHealth();
                winner = p;
            }
        }
        if (winner == null) {
            // All offline — pick random from remaining UUIDs.
            var remaining = new ArrayList<>(participants);
            if (!remaining.isEmpty()) {
                winner = Bukkit.getPlayer(remaining.get(ThreadLocalRandom.current().nextInt(remaining.size())));
            }
        }
        if (winner != null) {
            // Eliminate everyone except the winner.
            var toEliminate = new ArrayList<>(participants);
            toEliminate.remove(winner.getUniqueId());
            for (UUID uuid : toEliminate) {
                participants.remove(uuid);
                eliminationOrder.add(uuid);
            }
        }
    }

    // ── Rewards phase ───────────────────────────────────────────────

    private void beginRewards() {
        currentPhase = Phase.REWARDS;
        try {
            distributeRewards();
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE, "Error distributing tournament rewards", e);
        }

        // Short delay then cleanup.
        new BukkitRunnable() {
            @Override
            public void run() {
                cleanup();
            }
        }.runTaskLater(plugin, 100L); // 5 seconds
    }

    private void distributeRewards() {
        if (participants.isEmpty()) {
            plugin.getLogger().warning("Tournament ended with no winner.");
            broadcast(announcementsKey("ended"));
            return;
        }

        UUID winnerId = participants.iterator().next();
        Player winner = Bukkit.getPlayer(winnerId);
        String winnerName = winner != null ? winner.getName() : winnerId.toString();

        // XP rewards.
        int winnerXp = config().get().getInt("rewards.winner-xp", 5000);
        int participantXp = config().get().getInt("rewards.participant-xp", 250);

        if (winner != null && winner.isOnline()) {
            plugin.getLevelManager().addXp(winner, winnerXp, "tournament-win");
            giveWinnerItems(winner);
        }

        // Participant XP for everyone who was eliminated (and the winner gets winner-xp instead).
        for (UUID uuid : eliminationOrder) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                plugin.getLevelManager().addXp(p, participantXp, "tournament-participation");
            }
        }

        // Broadcast winner.
        broadcast(announcementsKey("winner-announced"), winnerName);
        playSoundToAll(Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);

        // Statistics / leaderboard integration.
        recordStatistics(winnerId, winnerName);

        plugin.getLogger().info("Tournament complete. Winner: " + winnerName
                + ". Participants: " + (eliminationOrder.size() + 1));
    }

    private void giveWinnerItems(@NotNull Player winner) {
        ConfigurationSection items = config().get().getConfigurationSection("rewards.winner-items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection entry = items.getConfigurationSection(key);
            if (entry == null) continue;
            try {
                String matName = entry.getString("material", "AIR");
                int amount = entry.getInt("amount", 1);
                Material material = Material.matchMaterial(matName);
                if (material == null || material == Material.AIR) continue;
                winner.getInventory().addItem(new ItemStack(material, amount));
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to give winner item '" + key + "': " + e.getMessage());
            }
        }
    }

    private void recordStatistics(@NotNull UUID winnerId, @NotNull String winnerName) {
        if (!config().get().getBoolean("statistics.enabled", true)) return;
        try {
            String categoryName = config().get().getString("statistics.category", "XP");
            LeaderboardManager.Category category = LeaderboardManager.Category.valueOf(categoryName.toUpperCase());
            var top = plugin.getLeaderboardManager().top(category, 100);
            plugin.getLogger().info("Tournament winner recorded. Current " + category
                    + " leaderboard has " + top.size() + " entries.");
            // The winner's XP was already added via addXp, so the leaderboard
            // reflects the updated value automatically on the next query.
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to record tournament statistics: " + e.getMessage());
        }
    }

    // ── Cleanup ─────────────────────────────────────────────────────

    private void cleanup() {
        currentPhase = Phase.ENDED;

        // Restore locations.
        for (Map.Entry<UUID, Location> entry : savedLocations.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p != null && p.isOnline()) {
                plugin.sync(() -> {
                    try {
                        p.teleport(entry.getValue());
                    } catch (Exception e) {
                        plugin.getLogger().warning("Failed to restore location for "
                                + p.getName() + ": " + e.getMessage());
                    }
                });
            }
        }

        if (activeTask != null) {
            try {
                activeTask.cancel();
            } catch (IllegalStateException ignored) {
                // Task already cancelled/scheduled — safe to ignore.
            }
            activeTask = null;
        }

        participants.clear();
        spectators.clear();
        savedLocations.clear();
        eliminationOrder.clear();

        // Return to IDLE after a short grace period.
        new BukkitRunnable() {
            @Override
            public void run() {
                currentPhase = Phase.IDLE;
            }
        }.runTaskLater(plugin, 60L); // 3 seconds
    }

    // ════════════════════════════════════════════════════════════════
    // Arena / location helpers
    // ════════════════════════════════════════════════════════════════

    @NotNull
    public Location getArenaLocation() {
        ConfigurationSection arena = config().get().getConfigurationSection("arena");
        if (arena == null) return Bukkit.getWorlds().get(0).getSpawnLocation();
        World world = resolveWorld(arena.getString("world", "default"));
        return new Location(world,
                arena.getDouble("x", 0.5),
                arena.getDouble("y", 64),
                arena.getDouble("z", 0.5),
                (float) arena.getDouble("yaw", 0),
                (float) arena.getDouble("pitch", 0));
    }

    @NotNull
    public Location getSpectatorLocation() {
        ConfigurationSection arena = config().get().getConfigurationSection("arena");
        Location fallback = Bukkit.getWorlds().get(0).getSpawnLocation();
        if (arena == null) return fallback;
        World world = resolveWorld(arena.getString("world", "default"));
        return new Location(world,
                arena.getDouble("spectator-x", arena.getDouble("x", 0.5)),
                arena.getDouble("spectator-y", arena.getDouble("y", 64) + 6),
                arena.getDouble("spectator-z", arena.getDouble("z", 0.5)));
    }

    public int getArenaRadius() {
        return config().get().getInt("arena.radius", 32);
    }

    /**
     * Checks whether a location is inside the arena region.
     */
    public boolean isInArena(@NotNull Location loc) {
        Location center = getArenaLocation();
        if (!loc.getWorld().equals(center.getWorld())) return false;
        double radius = getArenaRadius();
        return loc.distanceSquared(center) <= radius * radius;
    }

    @NotNull
    private World resolveWorld(@Nullable String worldName) {
        if (worldName == null || worldName.equalsIgnoreCase("default")) {
            return Bukkit.getWorlds().get(0);
        }
        World world = Bukkit.getWorld(worldName);
        return world != null ? world : Bukkit.getWorlds().get(0);
    }

    // ════════════════════════════════════════════════════════════════
    // Scheduling helpers
    // ════════════════════════════════════════════════════════════════

    /**
     * Returns the next scheduled tournament date/time, or null if not computable.
     */
    public @Nullable LocalDateTime getNextScheduledTime() {
        var now = LocalDateTime.now(ZoneId.systemDefault());
        int day = config().get().getInt("schedule.day-of-month", 1);
        int hour = config().get().getInt("schedule.hour", 18);
        int minute = config().get().getInt("schedule.minute", 0);

        int safeDay = Math.min(day, now.toLocalDate().lengthOfMonth());
        var next = now.withDayOfMonth(safeDay)
                .withHour(hour).withMinute(minute).withSecond(0).withNano(0);
        if (!next.isAfter(now)) {
            var nextMonth = next.plusMonths(1);
            int safeDayNext = Math.min(day, nextMonth.toLocalDate().lengthOfMonth());
            next = nextMonth.withDayOfMonth(safeDayNext);
        }
        return next;
    }

    /**
     * Returns a human-readable description of the next scheduled time.
     */
    public String getNextScheduledDescription() {
        var next = getNextScheduledTime();
        if (next == null) return "Unknown";
        long days = LocalDateTime.now(ZoneId.systemDefault()).until(next, ChronoUnit.DAYS);
        long hours = LocalDateTime.now(ZoneId.systemDefault()).until(next, ChronoUnit.HOURS) % 24;
        return next.toString() + " (in " + days + "d " + hours + "h)";
    }

    // ════════════════════════════════════════════════════════════════
    // Broadcast / sound helpers
    // ════════════════════════════════════════════════════════════════

    private String announcementsKey(@NotNull String key) {
        return config().get().getString("announcements." + key, "tournament-" + key);
    }

    private void broadcast(@NotNull String messageKey, Object... args) {
        try {
            String msg = plugin.getMessages().raw(messageKey, args);
            Component component = SERIALIZER.deserialize(msg);
            Bukkit.getServer().sendMessage(component);
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to broadcast tournament message '" + messageKey + "': " + e.getMessage());
        }
    }

    private void playSoundToAll(@NotNull Sound sound, float volume, float pitch) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), sound, volume, pitch);
        }
    }
}
