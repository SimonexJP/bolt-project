package com.magiccraft.tournament;

import com.magiccraft.MagicPlugin;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

/**
 * Bukkit listener that enforces arena protection rules during a tournament
 * and handles player disconnects.
 *
 * <p>Protections:
 * <ul>
 *   <li>Prevents block break/place inside the arena region</li>
 *   <li>Prevents damage to spectators</li>
 *   <li>Prevents all damage in the spectator area</li>
 *   <li>Handles player quit during an active tournament</li>
 * </ul>
 */
public class TournamentListener implements Listener {

    private final MagicPlugin plugin;

    public TournamentListener(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    private TournamentManager manager() {
        return plugin.getTournamentManager();
    }

    // ── Block protection ────────────────────────────────────────────

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockBreak(@NotNull BlockBreakEvent event) {
        if (!manager().isActive()) return;
        if (!plugin.getTournamentManager().config().get().getBoolean("protection.block-break", true)) return;
        if (manager().isInArena(event.getBlock().getLocation())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(plugin.getMessages().get("tournament-arena-protected"));
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockPlace(@NotNull BlockPlaceEvent event) {
        if (!manager().isActive()) return;
        if (!plugin.getTournamentManager().config().get().getBoolean("protection.block-place", true)) return;
        if (manager().isInArena(event.getBlock().getLocation())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(plugin.getMessages().get("tournament-arena-protected"));
        }
    }

    // ── Spectator damage protection ─────────────────────────────────

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityDamage(@NotNull EntityDamageEvent event) {
        if (!manager().isActive()) return;
        if (!(event.getEntity() instanceof Player player)) return;

        var cfg = plugin.getTournamentManager().config().get();

        // Spectators take no damage at all.
        if (cfg.getBoolean("protection.spectator-no-damage", true)
                && manager().isSpectator(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        // No damage in the spectator area.
        if (cfg.getBoolean("protection.spectator-damage", true)) {
            Location specLoc = manager().getSpectatorLocation();
            if (player.getWorld().equals(specLoc.getWorld())
                    && player.getLocation().distanceSquared(specLoc) <= 25.0) {
                event.setCancelled(true);
            }
        }
    }

    // ── Player disconnect ───────────────────────────────────────────

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(@NotNull PlayerQuitEvent event) {
        if (!manager().isActive()) return;
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        var manager = manager();

        if (manager.isParticipant(uuid)) {
            // Eliminate the disconnected participant.
            plugin.sync(() -> manager.eliminate(player, "Disconnected"));
        }

        // Remove from spectators silently.
        manager.removeSpectator(uuid);
    }
}
