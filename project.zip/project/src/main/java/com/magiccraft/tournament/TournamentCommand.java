package com.magiccraft.tournament;

import com.magiccraft.MagicPlugin;
import com.magiccraft.commands.SafeCommandExecutor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Command executor for {@code /torneo} (tournament command).
 *
 * <p>Subcommands:
 * <ul>
 *   <li>{@code /torneo start}     — (admin) manually start the tournament</li>
 *   <li>{@code /torneo cancel}    — (admin) cancel the active tournament</li>
 *   <li>{@code /torneo info}      — show tournament info and schedule</li>
 *   <li>{@code /torneo join}      — join the tournament</li>
 *   <li>{@code /torneo leave}     — leave the tournament</li>
 *   <li>{@code /torneo reload}    — (admin) reload tournament config</li>
 *   <li>{@code /torneo spectate}  — spectate the active tournament</li>
 * </ul>
 */
public class TournamentCommand extends SafeCommandExecutor {

    private static final String ADMIN_PERMISSION = "magiccraft.tournament.admin";
    private static final String USE_PERMISSION = "magiccraft.tournament.use";

    private static final List<String> SUBCOMMANDS = List.of(
            "start", "cancel", "info", "join", "leave", "reload", "spectate"
    );
    private static final List<String> ADMIN_SUBCOMMANDS = List.of(
            "start", "cancel", "reload"
    );

    public TournamentCommand(MagicPlugin plugin) {
        super(plugin);
    }

    @Override
    protected void safeExecute(@NotNull CommandSender sender, @NotNull Command command,
                               @NotNull String label, @NotNull String[] args) {
        if (args.length < 1) {
            sendUsage(sender);
            return;
        }

        var sub = args[0].toLowerCase();
        switch (sub) {
            case "start"   -> handleStart(sender);
            case "cancel"  -> handleCancel(sender);
            case "info"    -> handleInfo(sender);
            case "join"    -> handleJoin(sender);
            case "leave"   -> handleLeave(sender);
            case "reload"  -> handleReload(sender);
            case "spectate"-> handleSpectate(sender);
            default        -> sendUsage(sender);
        }
    }

    // ── Admin: start ────────────────────────────────────────────────

    private void handleStart(@NotNull CommandSender sender) {
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        var manager = plugin.getTournamentManager();
        if (manager.isActive()) {
            sender.sendMessage(plugin.getMessages().get("tournament-already-active"));
            return;
        }
        boolean started = manager.start();
        if (started) {
            sender.sendMessage(plugin.getMessages().get("tournament-started-by-admin", sender.getName()));
            plugin.getLogger().info("Tournament manually started by " + sender.getName() + ".");
        } else {
            sender.sendMessage(plugin.getMessages().get("tournament-start-failed"));
        }
    }

    // ── Admin: cancel ───────────────────────────────────────────────

    private void handleCancel(@NotNull CommandSender sender) {
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        var manager = plugin.getTournamentManager();
        boolean cancelled = manager.cancel();
        if (cancelled) {
            sender.sendMessage(plugin.getMessages().get("tournament-cancelled-by-admin", sender.getName()));
            plugin.getLogger().info("Tournament cancelled by " + sender.getName() + ".");
        } else {
            sender.sendMessage(plugin.getMessages().get("tournament-not-active"));
        }
    }

    // ── Admin: reload ───────────────────────────────────────────────

    private void handleReload(@NotNull CommandSender sender) {
        if (!sender.hasPermission(ADMIN_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        plugin.getTournamentManager().reloadConfig();
        sender.sendMessage(plugin.getMessages().get("tournament-reloaded"));
    }

    // ── Player: info ────────────────────────────────────────────────

    private void handleInfo(@NotNull CommandSender sender) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        var manager = plugin.getTournamentManager();
        var phase = manager.getCurrentPhase();

        sender.sendMessage(plugin.getMessages().raw("tournament-info-header"));
        sender.sendMessage(plugin.getMessages().get("tournament-info-phase", phase.name()));
        sender.sendMessage(plugin.getMessages().get("tournament-info-participants", manager.getParticipantCount()));
        sender.sendMessage(plugin.getMessages().get("tournament-info-schedule", manager.getNextScheduledDescription()));

        if (manager.isActive()) {
            sender.sendMessage(plugin.getMessages().get("tournament-info-join-hint"));
        }
    }

    // ── Player: join ────────────────────────────────────────────────

    private void handleJoin(@NotNull CommandSender sender) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        plugin.getTournamentManager().join(player);
    }

    // ── Player: leave ───────────────────────────────────────────────

    private void handleLeave(@NotNull CommandSender sender) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        plugin.getTournamentManager().leave(player);
    }

    // ── Player: spectate ────────────────────────────────────────────

    private void handleSpectate(@NotNull CommandSender sender) {
        if (!sender.hasPermission(USE_PERMISSION)) {
            sender.sendMessage(plugin.getMessages().get("tournament-no-permission"));
            return;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return;
        }
        var manager = plugin.getTournamentManager();
        if (!manager.isActive()) {
            player.sendMessage(plugin.getMessages().get("tournament-not-active"));
            return;
        }
        if (manager.isParticipant(player.getUniqueId())) {
            player.sendMessage(plugin.getMessages().get("tournament-already-joined"));
            return;
        }
        if (manager.spectate(player)) {
            player.teleport(manager.getSpectatorLocation());
            player.sendMessage(plugin.getMessages().get("tournament-spectating"));
        }
    }

    // ── Usage ───────────────────────────────────────────────────────

    private void sendUsage(@NotNull CommandSender sender) {
        sender.sendMessage(plugin.getMessages().raw("tournament-usage"));
    }

    // ── Tab completion ──────────────────────────────────────────────

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                 @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            return SUBCOMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .filter(s -> !ADMIN_SUBCOMMANDS.contains(s) || sender.hasPermission(ADMIN_PERMISSION))
                    .collect(Collectors.toList());
        }
        return List.of();
    }
}
