package com.magiccraft.duel;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.scheduler.BukkitRunnable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages 1v1 magic duels between players.
 *
 * <p>Flow: invitation → accept → cinematic countdown → active duel (magic-only
 * combat, melee disabled) → winner determination → rewards + safe return.
 *
 * <p>Thread-safety: all player-facing state maps use {@link ConcurrentHashMap}.
 * All Bukkit API calls are scheduled on the main thread via {@link MagicPlugin#sync(Runnable)}
 * or {@link BukkitRunnable} runTask variants.
 */
public class DuelManager {

    private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.legacyAmpersand();

    /** Lifecycle states for a duel. */
    public enum DuelState {
        INVITED,   // invitation sent, awaiting accept/deny
        COUNTDOWN, // both players teleported to arena, counting down
        ACTIVE,    // duel in progress — spells allowed, melee disabled
        ENDED      // duel concluded — cleanup in progress or done
    }

    /** Per-player saved state for inventory restoration and safe return. */
    private record SavedState(
            UUID playerId,
            Location returnLocation,
            ItemStack[] inventoryContents,
            ItemStack[] armorContents,
            double health,
            int food,
            float saturation,
            int fireTicks
    ) {}

    /** Active or pending duel sessions, keyed by a synthetic duel ID. */
    private final Map<UUID, DuelSession> activeDuels = new ConcurrentHashMap<>();

    /** Maps a player UUID to the duel ID they are involved in (for O(1) lookups). */
    private final Map<UUID, UUID> playerToDuel = new ConcurrentHashMap<>();

    /** Pending invitations: key = invited player UUID, value = challenger UUID. */
    private final Map<UUID, UUID> pendingInvites = new ConcurrentHashMap<>();

    private final MagicPlugin plugin;

    public DuelManager(@NotNull MagicPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────── Public API ───────────────────────────

    /**
     * Sends a duel invitation from {@code challenger} to {@code target}.
     *
     * @return {@code true} if the invitation was sent, {@code false} if blocked
     *         by a precondition (self-target, already in duel, offline target, etc.)
     */
    public boolean sendInvitation(@NotNull Player challenger, @NotNull Player target) {
        if (challenger.getUniqueId().equals(target.getUniqueId())) {
            challenger.sendMessage(plugin.getMessages().get("duel-cannot-self"));
            return false;
        }
        if (isInDuel(challenger)) {
            challenger.sendMessage(plugin.getMessages().get("duel-already-in"));
            return false;
        }
        if (isInDuel(target)) {
            challenger.sendMessage(plugin.getMessages().get("duel-target-busy", target.getName()));
            return false;
        }
        if (pendingInvites.containsKey(target.getUniqueId())) {
            challenger.sendMessage(plugin.getMessages().get("duel-target-pending", target.getName()));
            return false;
        }
        if (pendingInvites.containsValue(challenger.getUniqueId())) {
            challenger.sendMessage(plugin.getMessages().get("duel-invite-pending-out"));
            return false;
        }

        pendingInvites.put(target.getUniqueId(), challenger.getUniqueId());
        challenger.sendMessage(plugin.getMessages().get("duel-invite-sent", target.getName()));
        target.sendMessage(plugin.getMessages().get("duel-invite-received", challenger.getName()));
        return true;
    }

    /**
     * Accepts a pending duel invitation.
     *
     * @return {@code true} if the invitation was accepted and the duel started.
     */
    public boolean acceptInvitation(@NotNull Player player) {
        UUID challengerId = pendingInvites.remove(player.getUniqueId());
        if (challengerId == null) {
            player.sendMessage(plugin.getMessages().get("duel-no-invite"));
            return false;
        }

        Player challenger = Bukkit.getPlayer(challengerId);
        if (challenger == null || !challenger.isOnline()) {
            player.sendMessage(plugin.getMessages().get("duel-challenger-offline"));
            return false;
        }

        if (isInDuel(challenger)) {
            player.sendMessage(plugin.getMessages().get("duel-challenger-busy"));
            return false;
        }

        startDuel(challenger, player);
        return true;
    }

    /** Denies a pending duel invitation. */
    public boolean denyInvitation(@NotNull Player player) {
        UUID challengerId = pendingInvites.remove(player.getUniqueId());
        if (challengerId == null) {
            player.sendMessage(plugin.getMessages().get("duel-no-invite"));
            return false;
        }
        player.sendMessage(plugin.getMessages().get("duel-denied-self"));
        Player challenger = Bukkit.getPlayer(challengerId);
        if (challenger != null && challenger.isOnline()) {
            challenger.sendMessage(plugin.getMessages().get("duel-denied-by", player.getName()));
        }
        return true;
    }

    /** Cancels an outgoing invitation that {@code player} sent. */
    public boolean cancelInvitation(@NotNull Player player) {
        // Remove the invitation where this player is the challenger (value).
        UUID invitedId = null;
        for (var entry : pendingInvites.entrySet()) {
            if (entry.getValue().equals(player.getUniqueId())) {
                invitedId = entry.getKey();
                break;
            }
        }
        if (invitedId == null) {
            player.sendMessage(plugin.getMessages().get("duel-no-outgoing"));
            return false;
        }
        pendingInvites.remove(invitedId);
        player.sendMessage(plugin.getMessages().get("duel-cancelled-self"));
        Player invited = Bukkit.getPlayer(invitedId);
        if (invited != null && invited.isOnline()) {
            invited.sendMessage(plugin.getMessages().get("duel-cancelled-by", player.getName()));
        }
        return true;
    }

    // ─────────────────────────── State Queries ───────────────────────────

    /** Returns {@code true} if the player is currently in any duel phase. */
    public boolean isInDuel(@NotNull Player player) {
        return playerToDuel.containsKey(player.getUniqueId());
    }

    /** Returns the active session for a player, or {@code null}. */
    public @Nullable DuelSession getSession(@NotNull Player player) {
        UUID duelId = playerToDuel.get(player.getUniqueId());
        if (duelId == null) return null;
        return activeDuels.get(duelId);
    }

    /** Returns the duel session by its ID. */
    public @Nullable DuelSession getSessionById(@NotNull UUID duelId) {
        return activeDuels.get(duelId);
    }

    /** Returns {@code true} if melee damage should be cancelled for this player (magic-only mode). */
    public boolean isMagicOnly(@NotNull Player player) {
        DuelSession session = getSession(player);
        if (session == null) return false;
        return session.state == DuelState.ACTIVE && config().get().getBoolean("settings.magic-only", true);
    }

    /** Returns {@code true} if the player is in an active duel and should be prevented from running commands. */
    public boolean shouldBlockCommands(@NotNull Player player) {
        DuelSession session = getSession(player);
        if (session == null) return false;
        return session.state == DuelState.ACTIVE
                && config().get().getBoolean("settings.prevent-commands", true);
    }

    /** Returns {@code true} if the player is in an active duel and should be prevented from leaving the arena. */
    public boolean shouldPreventEscape(@NotNull Player player) {
        DuelSession session = getSession(player);
        if (session == null) return false;
        return session.state == DuelState.ACTIVE
                && config().get().getBoolean("settings.prevent-escape", true);
    }

    // ─────────────────────────── Duel Lifecycle ───────────────────────────

    /**
     * Starts a duel: saves inventories, teleports both players to the arena,
     * and begins the cinematic countdown.
     */
    private void startDuel(@NotNull Player player1, @NotNull Player player2) {
        UUID duelId = UUID.randomUUID();

        SavedState saved1 = saveState(player1);
        SavedState saved2 = saveState(player2);

        DuelSession session = new DuelSession(
                duelId,
                player1.getUniqueId(),
                player2.getUniqueId(),
                DuelState.COUNTDOWN,
                saved1,
                saved2
        );
        activeDuels.put(duelId, session);
        playerToDuel.put(player1.getUniqueId(), duelId);
        playerToDuel.put(player2.getUniqueId(), duelId);

        plugin.getLogger().info("Duel starting: " + player1.getName() + " vs " + player2.getName()
                + " (id=" + duelId + ")");

        // Teleport both players to the arena on the main thread.
        plugin.sync(() -> {
            try {
                Location arenaCenter = getArenaLocation();
                double offset = config().get().getDouble("arena.player-offset", 5.0);
                Location loc1 = offsetLocation(arenaCenter, offset, 0);
                Location loc2 = offsetLocation(arenaCenter, -offset, 0);

                player1.teleport(loc1);
                player2.teleport(loc2);

                // Clear inventories for a clean duel.
                if (config().get().getBoolean("settings.protect-inventory", true)) {
                    player1.getInventory().clear();
                    player2.getInventory().clear();
                    player1.getInventory().setArmorContents(null);
                    player2.getInventory().setArmorContents(null);
                }

                // Full health and food for fairness.
                player1.setHealth(Objects.requireNonNull(player1.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH)).getValue());
                player2.setHealth(Objects.requireNonNull(player2.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH)).getValue());
                player1.setFoodLevel(20);
                player2.setFoodLevel(20);
                player1.setSaturation(20f);
                player2.setSaturation(20f);
                player1.setFireTicks(0);
                player2.setFireTicks(0);

                beginCountdown(session, player1, player2);
            } catch (Exception e) {
                plugin.getLogger().severe("Error during duel start for " + duelId + ": " + e.getMessage());
                e.printStackTrace();
                endDuel(duelId, null, "Duel start error");
            }
        });
    }

    /**
     * Runs the cinematic countdown (3, 2, 1, FIGHT!) using a repeating
     * {@link BukkitRunnable}. When the countdown finishes, the duel becomes
     * ACTIVE and spell combat is enabled.
     */
    private void beginCountdown(@NotNull DuelSession session, @NotNull Player player1, @NotNull Player player2) {
        int totalSeconds = config().get().getInt("countdown.duration", 3);

        new BukkitRunnable() {
            int count = totalSeconds;

            @Override
            public void run() {
                try {
                    // Abort if the duel was cancelled or a player went offline.
                    if (!activeDuels.containsKey(session.duelId())) {
                        cancel();
                        return;
                    }
                    if (!player1.isOnline() || !player2.isOnline()) {
                        cancel();
                        Player survivor = player1.isOnline() ? player1 : player2;
                        endDuel(session.duelId(), survivor.getUniqueId(), "Opponent disconnected during countdown");
                        return;
                    }

                    if (count > 0) {
                        String titleKey = "duel-countdown-" + count;
                        showTitleToBoth(player1, player2, titleKey, "duel-countdown-subtitle", 200, 800, 200);
                        player1.playSound(player1.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                        player2.playSound(player2.getLocation(), Sound.UI_BUTTON_CLICK, 1f, 1f);
                        count--;
                    } else {
                        // FIGHT!
                        showTitleToBoth(player1, player2, "duel-fight-title", "duel-fight-subtitle", 200, 1200, 400);
                        player1.playSound(player1.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
                        player2.playSound(player2.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
                        player1.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player1.getLocation(), 30, 1, 1, 1, 0.1);
                        player2.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player2.getLocation(), 30, 1, 1, 1, 0.1);

                        session.state = DuelState.ACTIVE;
                        plugin.getLogger().info("Duel " + session.duelId() + " is now ACTIVE.");
                        cancel();
                    }
                } catch (Exception e) {
                    plugin.getLogger().severe("Error during countdown for duel " + session.duelId() + ": " + e.getMessage());
                    e.printStackTrace();
                    cancel();
                    endDuel(session.duelId(), null, "Countdown error");
                }
            }
        }.runTaskTimer(plugin, 0L, 20L); // every 1 second
    }

    /**
     * Ends a duel, determines the winner, distributes rewards, and restores
     * both players to their pre-duel state.
     *
     * @param duelId      the duel session ID
     * @param winnerId    the winner's UUID, or {@code null} if the duel ended without a winner (draw/cancel)
     * @param reason      a short reason string for logging
     */
    public void endDuel(@NotNull UUID duelId, @Nullable UUID winnerId, @NotNull String reason) {
        DuelSession session = activeDuels.get(duelId);
        if (session == null) return; // already ended

        session.state = DuelState.ENDED;

        UUID loserId = null;
        if (winnerId != null) {
            loserId = winnerId.equals(session.player1Id()) ? session.player2Id() : session.player1Id();
        }

        plugin.getLogger().info("Duel " + duelId + " ended. Winner="
                + (winnerId != null ? Bukkit.getOfflinePlayer(winnerId).getName() : "none")
                + ", reason=" + reason);

        // Distribute rewards on the main thread.
        plugin.sync(() -> {
            try {
                if (winnerId != null) {
                    Player winner = Bukkit.getPlayer(winnerId);
                    Player loser = Bukkit.getPlayer(loserId);
                    if (winner != null && winner.isOnline()) {
                        awardWinner(winner);
                    }
                    if (loser != null && loser.isOnline()) {
                        comfortLoser(loser);
                    }
                    // Broadcast result.
                    String winnerName = winner != null ? winner.getName() : Bukkit.getOfflinePlayer(winnerId).getName();
                    String loserName = loser != null ? loser.getName() : Bukkit.getOfflinePlayer(loserId).getName();
                    Bukkit.broadcastMessage(plugin.getMessages().get("duel-result-broadcast", winnerName, loserName));
                } else {
                    Player p1 = Bukkit.getPlayer(session.player1Id());
                    Player p2 = Bukkit.getPlayer(session.player2Id());
                    if (p1 != null && p1.isOnline()) p1.sendMessage(plugin.getMessages().get("duel-ended-no-winner"));
                    if (p2 != null && p2.isOnline()) p2.sendMessage(plugin.getMessages().get("duel-ended-no-winner"));
                }

                // Restore both players.
                restorePlayer(session.player1Id(), session.saved1());
                restorePlayer(session.player2Id(), session.saved2());

                // Clean up maps.
                playerToDuel.remove(session.player1Id());
                playerToDuel.remove(session.player2Id());
                activeDuels.remove(duelId);
            } catch (Exception e) {
                plugin.getLogger().severe("Error during duel cleanup for " + duelId + ": " + e.getMessage());
                e.printStackTrace();
                // Force-clean maps even on error.
                playerToDuel.remove(session.player1Id());
                playerToDuel.remove(session.player2Id());
                activeDuels.remove(duelId);
            }
        });
    }

    /**
     * Handles a player disconnecting while in a duel. The disconnecting player
     * forfeits and the other player wins.
     */
    public void handleDisconnect(@NotNull Player player) {
        // Remove any pending invites involving this player.
        pendingInvites.remove(player.getUniqueId());
        pendingInvites.entrySet().removeIf(e -> e.getValue().equals(player.getUniqueId()));

        DuelSession session = getSession(player);
        if (session == null) return;

        UUID otherId = player.getUniqueId().equals(session.player1Id())
                ? session.player2Id()
                : session.player1Id();
        endDuel(session.duelId(), otherId, player.getName() + " disconnected (forfeit)");
    }

    /**
     * Shows a title + subtitle to both duel participants using the Kyori
     * Adventure API.
     */
    private void showTitleToBoth(@NotNull Player p1, @NotNull Player p2,
                                 @NotNull String titleKey, @NotNull String subtitleKey,
                                 int fadeInMs, int stayMs, int fadeOutMs) {
        Component title = SERIALIZER.deserialize(plugin.getMessages().raw(titleKey));
        Component subtitle = SERIALIZER.deserialize(plugin.getMessages().raw(subtitleKey));
        var times = net.kyori.adventure.title.Title.Times.times(
                java.time.Duration.ofMillis(fadeInMs),
                java.time.Duration.ofMillis(stayMs),
                java.time.Duration.ofMillis(fadeOutMs));
        var titleObj = net.kyori.adventure.title.Title.title(title, subtitle, times);
        p1.showTitle(titleObj);
        p2.showTitle(titleObj);
    }

    // ─────────────────────────── Rewards ───────────────────────────

    private void awardWinner(@NotNull Player winner) {
        int xp = config().get().getInt("rewards.winner-xp", 100);
        int rankingPoints = config().get().getInt("rewards.ranking-points", 10);

        if (xp > 0) {
            plugin.getLevelManager().addXp(winner, xp, "duel-win");
        }
        winner.sendMessage(plugin.getMessages().get("duel-win-message", xp, rankingPoints));
        winner.playSound(winner.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1.2f);
        winner.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING,
                winner.getLocation().clone().add(0, 1, 0), 40, 0.5, 1, 0.5, 0.1);
    }

    private void comfortLoser(@NotNull Player loser) {
        int xp = config().get().getInt("rewards.loser-xp", 20);
        if (xp > 0) {
            plugin.getLevelManager().addXp(loser, xp, "duel-loss");
        }
        loser.sendMessage(plugin.getMessages().get("duel-loss-message", xp));
        loser.playSound(loser.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.8f);
    }

    // ─────────────────────────── Save / Restore ───────────────────────────

    private @NotNull SavedState saveState(@NotNull Player player) {
        PlayerInventory inv = player.getInventory();
        return new SavedState(
                player.getUniqueId(),
                player.getLocation().clone(),
                cloneItems(inv.getContents()),
                cloneItems(inv.getArmorContents()),
                player.getHealth(),
                player.getFoodLevel(),
                player.getSaturation(),
                player.getFireTicks()
        );
    }

    private void restorePlayer(@NotNull UUID playerId, @NotNull SavedState saved) {
        Player player = Bukkit.getPlayer(playerId);
        if (player == null || !player.isOnline()) return;

        try {
            PlayerInventory inv = player.getInventory();
            inv.setContents(saved.inventoryContents());
            inv.setArmorContents(saved.armorContents());
            player.setHealth(Math.max(1.0, saved.health()));
            player.setFoodLevel(saved.food());
            player.setSaturation(saved.saturation());
            player.setFireTicks(saved.fireTicks());
            player.teleport(saved.returnLocation());
            player.sendMessage(plugin.getMessages().get("duel-returned"));
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to restore state for " + playerId + ": " + e.getMessage());
            // At least teleport them to spawn as a fallback.
            World world = Bukkit.getWorlds().get(0);
            player.teleport(world.getSpawnLocation());
        }
    }

    private static ItemStack @NotNull [] cloneItems(ItemStack @Nullable [] items) {
        if (items == null) return new ItemStack[0];
        ItemStack[] clones = new ItemStack[items.length];
        for (int i = 0; i < items.length; i++) {
            clones[i] = items[i] != null ? items[i].clone() : null;
        }
        return clones;
    }

    // ─────────────────────────── Arena ───────────────────────────

    private @NotNull YamlConfig config() {
        return plugin.getConfigManager().get(ConfigManager.DUEL);
    }

    /**
     * Reads the arena center location from the config. If the configured world
     * is unavailable, falls back to the first loaded world's spawn.
     */
    public @NotNull Location getArenaLocation() {
        ConfigurationSection arena = config().get().getConfigurationSection("arena");
        if (arena == null) return Bukkit.getWorlds().get(0).getSpawnLocation();

        String worldName = arena.getString("world", "default");
        World world = worldName.equals("default")
                ? Bukkit.getWorlds().get(0)
                : Bukkit.getWorld(worldName);
        if (world == null) world = Bukkit.getWorlds().get(0);

        return new Location(
                world,
                arena.getDouble("x", 0.5),
                arena.getDouble("y", 64),
                arena.getDouble("z", 0.5),
                (float) arena.getDouble("yaw", 0),
                (float) arena.getDouble("pitch", 0)
        );
    }

    /**
     * Returns a location offset from the center by the given x and z deltas,
     * preserving the world and yaw/pitch (yaw is flipped for the opposite side).
     */
    private @NotNull Location offsetLocation(@NotNull Location center, double xOffset, double zOffset) {
        Location loc = center.clone().add(xOffset, 0, zOffset);
        loc.setYaw(center.getYaw() + (xOffset < 0 ? 180f : 0f));
        return loc;
    }

    /**
     * Returns the maximum allowed distance from the arena center before a
     * player is considered to be escaping.
     */
    public double getArenaRadius() {
        return config().get().getDouble("arena.radius", 20.0);
    }

    // ─────────────────────────── Session Record ───────────────────────────

    /**
     * Immutable snapshot of a duel session's core data. The {@code state} field
     * is mutable via direct field access on the record's holder (this manager).
     * Since records are immutable, we use a small mutable holder.
     */
    public static final class DuelSession {
        private final UUID duelId;
        private final UUID player1Id;
        private final UUID player2Id;
        private volatile DuelState state;
        private final SavedState saved1;
        private final SavedState saved2;

        DuelSession(UUID duelId, UUID player1Id, UUID player2Id,
                    DuelState state, SavedState saved1, SavedState saved2) {
            this.duelId = duelId;
            this.player1Id = player1Id;
            this.player2Id = player2Id;
            this.state = state;
            this.saved1 = saved1;
            this.saved2 = saved2;
        }

        public UUID duelId() { return duelId; }
        public UUID player1Id() { return player1Id; }
        public UUID player2Id() { return player2Id; }
        public DuelState state() { return state; }
        public SavedState saved1() { return saved1; }
        public SavedState saved2() { return saved2; }

        /** Returns the opponent's UUID for the given player. */
        public UUID opponentOf(@NotNull UUID playerId) {
            return playerId.equals(player1Id) ? player2Id : player1Id;
        }
    }
}
