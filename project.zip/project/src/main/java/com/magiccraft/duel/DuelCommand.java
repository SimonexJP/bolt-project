package com.magiccraft.duel;

import com.magiccraft.MagicPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Command executor for {@code /duello}.
 *
 * <p>Subcommands:
 * <ul>
 *   <li>{@code /duello <player>} — send a duel invitation</li>
 *   <li>{@code /duello accept}   — accept an incoming invitation</li>
 *   <li>{@code /duello deny}     — deny an incoming invitation</li>
 *   <li>{@code /duello cancel}   — cancel an outgoing invitation</li>
 * </ul>
 *
 * <p>Implements {@link TabCompleter} to provide online player name completion
 * for the base command and subcommand name completion.
 */
public class DuelCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBCOMMANDS = List.of("accept", "deny", "cancel");

    private final MagicPlugin plugin;

    public DuelCommand(@NotNull MagicPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                            @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessages().get("player-only"));
            return true;
        }

        try {
            if (args.length == 0) {
                sendUsage(player);
                return true;
            }

            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "accept" -> plugin.getDuelManager().acceptInvitation(player);
                case "deny"   -> plugin.getDuelManager().denyInvitation(player);
                case "cancel" -> plugin.getDuelManager().cancelInvitation(player);
                default       -> handleInvite(player, args[0]);
            }
        } catch (Exception e) {
            plugin.getLogger().severe("Error executing /duello for " + player.getName() + ": " + e.getMessage());
            e.printStackTrace();
            player.sendMessage(plugin.getMessages().get("command-error"));
        }
        return true;
    }

    /**
     * Resolves the target player from the first argument and sends a duel
     * invitation.
     */
    private void handleInvite(@NotNull Player sender, @NotNull String targetName) {
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            sender.sendMessage(plugin.getMessages().get("player-not-found", targetName));
            return;
        }
        plugin.getDuelManager().sendInvitation(sender, target);
    }

    private void sendUsage(@NotNull Player player) {
        player.sendMessage(plugin.getMessages().get("duel-usage"));
    }

    // ─────────────────────────── Tab Completion ───────────────────────────

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                                @NotNull String label, @NotNull String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> result = new ArrayList<>();

            // Subcommands.
            for (String sub : SUBCOMMANDS) {
                if (sub.startsWith(prefix)) result.add(sub);
            }

            // Online players (for invite target).
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    result.add(p.getName());
                }
            }
            return result;
        }

        // No further tab completion for subcommands.
        return List.of();
    }
}
