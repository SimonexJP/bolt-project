package com.magiccraft.duel;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Bukkit {@link Listener} that enforces duel rules:
 * <ul>
 *   <li>Cancels melee damage during duels (only spells / projectiles work)</li>
 *   <li>Handles player disconnect during a duel (auto-forfeit)</li>
 *   <li>Prevents commands other than spell commands during a duel</li>
 *   <li>Prevents leaving the arena during a duel</li>
 * </ul>
 */
public class DuelListener implements Listener {

    private final MagicPlugin plugin;

    public DuelListener(@NotNull MagicPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────── Magic-Only Combat ───────────────────────────

    /**
     * Cancels melee (direct) damage between duel participants when magic-only
     * mode is enabled. Projectile damage (spells) is allowed.
     */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onEntityDamageByEntity(@NotNull EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        DuelManager manager = plugin.getDuelManager();
        DuelManager.DuelSession session = manager.getSession(victim);
        if (session == null || session.state() != DuelManager.DuelState.ACTIVE) return;

        // Only restrict damage when the victim is in an active duel.
        // Allow projectile damage (spells, wands) — block direct melee only.
        if (event.getDamager() instanceof Player attacker) {
            // Melee attack — cancel if magic-only is enabled.
            if (manager.isMagicOnly(attacker) || manager.isMagicOnly(victim)) {
                event.setCancelled(true);
                attacker.sendMessage(plugin.getMessages().get("duel-melee-disabled"));
                return;
            }
        }
        // Projectiles (spell projectiles) are allowed to pass through.
    }

    // ─────────────────────────── Disconnect / Forfeit ───────────────────────────

    /**
     * When a player disconnects during a duel, they automatically forfeit and
     * the opponent wins.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(@NotNull PlayerQuitEvent event) {
        Player player = event.getPlayer();
        DuelManager manager = plugin.getDuelManager();

        // Clean up pending invites and active duels.
        if (manager.isInDuel(player)) {
            manager.handleDisconnect(player);
        }
    }

    // ─────────────────────────── Command Prevention ───────────────────────────

    /**
     * Prevents players from using commands other than spell commands during a
     * duel. This stops teleporting away, using /home, etc.
     */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommandPreprocess(@NotNull PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        DuelManager manager = plugin.getDuelManager();

        if (!manager.shouldBlockCommands(player)) return;

        String message = event.getMessage().toLowerCase(java.util.Locale.ROOT);
        List<String> allowed = plugin.getConfigManager()
                .get(ConfigManager.DUEL)
                .get()
                .getStringList("settings.allowed-commands");

        for (String allowedCmd : allowed) {
            if (message.startsWith(allowedCmd.toLowerCase(java.util.Locale.ROOT))) {
                return; // allow this command
            }
        }

        event.setCancelled(true);
        player.sendMessage(plugin.getMessages().get("duel-command-blocked"));
    }

    // ─────────────────────────── Arena Escape Prevention ───────────────────────────

    /**
     * Prevents players from moving outside the arena radius during a duel.
     * Teleport attempts are cancelled (except plugin-caused teleports used by
     * the duel system itself).
     */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onTeleport(@NotNull PlayerTeleportEvent event) {
        Player player = event.getPlayer();
        DuelManager manager = plugin.getDuelManager();

        if (!manager.shouldPreventEscape(player)) return;

        // Allow plugin-caused teleports (used by the duel system for arena setup).
        if (event.getCause() == PlayerTeleportEvent.TeleportCause.PLUGIN) return;
        // Allow ender pearls / chorus fruit? No — block all non-plugin teleports.
        event.setCancelled(true);
        player.sendMessage(plugin.getMessages().get("duel-escape-blocked"));
    }

    /**
     * Prevents players from walking outside the arena boundary during a duel.
     * If a player moves beyond the configured radius, they are pushed back.
     */
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onMove(@NotNull PlayerMoveEvent event) {
        Player player = event.getPlayer();
        DuelManager manager = plugin.getDuelManager();

        if (!manager.shouldPreventEscape(player)) return;

        Location to = event.getTo();
        if (to == null) return;

        DuelManager.DuelSession session = manager.getSession(player);
        if (session == null) return;

        Location arenaCenter = manager.getArenaLocation();
        double radius = manager.getArenaRadius();

        // Only check horizontal distance (x, z) — allow vertical movement (jumping, etc.).
        double dx = to.getX() - arenaCenter.getX();
        double dz = to.getZ() - arenaCenter.getZ();
        double distance = Math.sqrt(dx * dx + dz * dz);

        if (distance > radius) {
            // Cancel the movement — keep the player at the boundary.
            event.setCancelled(true);
            player.sendMessage(plugin.getMessages().get("duel-escape-blocked"));
        }
    }
}
