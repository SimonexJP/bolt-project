package com.magiccraft.data.database;

import com.magiccraft.MagicPlugin;
import com.magiccraft.config.ConfigManager;
import com.magiccraft.config.YamlConfig;
import com.magiccraft.data.model.PlayerData;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Picks the {@link Database} implementation based on database.yml and
 * delegates all operations to it.
 */
public class DatabaseManager implements Database {

    private final MagicPlugin plugin;
    private Database backend;

    public DatabaseManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void startup() {
        YamlConfig cfg = plugin.getConfigManager().database();
        String type = cfg.get().getString("database.type", "SQLITE").toUpperCase();
        if (type.equals("MYSQL")) {
            String host = cfg.get().getString("database.mysql.host", "localhost");
            int port = cfg.get().getInt("database.mysql.port", 3306);
            String name = cfg.get().getString("database.mysql.database", "magic");
            String user = cfg.get().getString("database.mysql.username", "root");
            String pass = cfg.get().getString("database.mysql.password", "");
            String params = cfg.get().getString("database.mysql.parameters", "useSSL=false");
            backend = new MySQLDatabase(plugin, host, port, name, user, pass, params);
            plugin.getLogger().info("Using MySQL database: " + host + ":" + port + "/" + name);
        } else {
            String file = cfg.get().getString("database.sqlite-file", "magic.db");
            backend = new SQLiteDatabase(plugin, file);
            plugin.getLogger().info("Using SQLite database: " + file);
        }
        backend.init().join();
    }

    @Override
    public CompletableFuture<Void> init() { return backend.init(); }

    @Override
    public CompletableFuture<@Nullable PlayerData> load(UUID uuid) { return backend.load(uuid); }

    @Override
    public CompletableFuture<Void> save(PlayerData data) { return backend.save(data); }

    @Override
    public CompletableFuture<Void> delete(UUID uuid) { return backend.delete(uuid); }

    @Override
    public void close() {
        if (backend != null) backend.close();
    }
}
