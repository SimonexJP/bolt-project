package com.magiccraft.data.database;

import com.magiccraft.data.model.PlayerData;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * Abstraction over the persistence layer.
 * All methods are async and return {@link CompletableFuture}.
 */
public interface Database {

    /** Initialize schema. Called once on enable. */
    CompletableFuture<Void> init();

    /** Load a player's data, or return null if absent. */
    CompletableFuture<@Nullable PlayerData> load(UUID uuid);

    /** Insert or update a player's data. */
    CompletableFuture<Void> save(PlayerData data);

    /** Remove all data for a player. */
    CompletableFuture<Void> delete(UUID uuid);

    /** Close the connection / pool. */
    void close();
}
