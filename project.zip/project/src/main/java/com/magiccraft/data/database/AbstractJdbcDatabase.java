package com.magiccraft.data.database;

import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.data.model.PlayerStatistics;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Shared JDBC helpers used by both the SQLite and MySQL implementations.
 */
public abstract class AbstractJdbcDatabase implements Database {

    protected final ExecutorService executor = Executors.newFixedThreadPool(4, r -> {
        Thread t = new Thread(r, "magic-db-worker");
        t.setDaemon(true);
        return t;
    });

    protected abstract Connection connection() throws SQLException;

    protected CompletableFuture<Void> runAsync(Runnable task) {
        return CompletableFuture.runAsync(task, executor);
    }

    protected <T> CompletableFuture<T> supplyAsync(java.util.function.Supplier<T> task) {
        return CompletableFuture.supplyAsync(task, executor);
    }

    protected PlayerData readPlayer(ResultSet rs) throws SQLException {
        UUID uuid = UUID.fromString(rs.getString("uuid"));
        PlayerData data = new PlayerData(uuid);
        String factionId = rs.getString("faction");
        if (factionId != null && !factionId.isEmpty()) {
            FactionType.fromId(factionId).ifPresent(data::setFaction);
        }
        data.setLevel(rs.getInt("level"));
        data.setXp(rs.getInt("xp"));
        data.setMana(rs.getInt("mana"));
        data.setMaxMana(rs.getInt("max_mana"));
        data.setLastLogin(rs.getLong("last_login"));
        data.setCapitalPunishmentCount(rs.getInt("capital_punishments"));

        String spells = rs.getString("unlocked_spells");
        if (spells != null && !spells.isEmpty()) {
            for (String s : spells.split(",")) {
                if (!s.isBlank()) data.unlockSpell(s.trim());
            }
        }

        PlayerStatistics stats = data.getStatistics();
        stats.setSpellsCast(rs.getInt("stat_spells_cast"));
        stats.setMobsKilled(rs.getInt("stat_mobs_killed"));
        stats.setXpGained(rs.getInt("stat_xp_gained"));
        stats.setDeaths(rs.getInt("stat_deaths"));
        stats.setPlaytimeMillis(rs.getLong("stat_playtime"));
        return data;
    }

    protected static final String CREATE_SQL = """
            CREATE TABLE IF NOT EXISTS magic_players (
                uuid VARCHAR(36) PRIMARY KEY,
                faction VARCHAR(32) NOT NULL DEFAULT '',
                level INT NOT NULL DEFAULT 1,
                xp INT NOT NULL DEFAULT 0,
                mana INT NOT NULL DEFAULT 100,
                max_mana INT NOT NULL DEFAULT 100,
                unlocked_spells TEXT NOT NULL DEFAULT '',
                last_login BIGINT NOT NULL DEFAULT 0,
                capital_punishments INT NOT NULL DEFAULT 0,
                stat_spells_cast INT NOT NULL DEFAULT 0,
                stat_mobs_killed INT NOT NULL DEFAULT 0,
                stat_xp_gained INT NOT NULL DEFAULT 0,
                stat_deaths INT NOT NULL DEFAULT 0,
                stat_playtime BIGINT NOT NULL DEFAULT 0
            )
            """;

    protected static final String MIGRATE_ADD_CAPITAL_SQL = """
            ALTER TABLE magic_players ADD COLUMN capital_punishments INT NOT NULL DEFAULT 0
            """;

    protected static final String INSERT_SQL = """
            INSERT INTO magic_players
                (uuid, faction, level, xp, mana, max_mana, unlocked_spells, last_login,
                 capital_punishments, stat_spells_cast, stat_mobs_killed, stat_xp_gained, stat_deaths, stat_playtime)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(uuid) DO UPDATE SET
                faction=excluded.faction, level=excluded.level, xp=excluded.xp,
                mana=excluded.mana, max_mana=excluded.max_mana,
                unlocked_spells=excluded.unlocked_spells, last_login=excluded.last_login,
                capital_punishments=excluded.capital_punishments,
                stat_spells_cast=excluded.stat_spells_cast, stat_mobs_killed=excluded.stat_mobs_killed,
                stat_xp_gained=excluded.stat_xp_gained, stat_deaths=excluded.stat_deaths,
                stat_playtime=excluded.stat_playtime
            """;

    protected static final String LOAD_SQL = """
            SELECT * FROM magic_players WHERE uuid = ?
            """;

    protected static final String DELETE_SQL = "DELETE FROM magic_players WHERE uuid = ?";
}
