package com.magiccraft.data.database;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.data.model.PlayerStatistics;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * SQLite-backed {@link Database}. Uses the bundled sqlite-jdbc driver.
 * The database file lives in the plugin data folder.
 */
public class SQLiteDatabase extends AbstractJdbcDatabase {

    private final MagicPlugin plugin;
    private final String fileName;
    private Connection connection;

    public SQLiteDatabase(MagicPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.fileName = fileName;
    }

    @Override
    protected synchronized Connection connection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            File dbFile = new File(plugin.getDataFolder(), fileName);
            String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
            connection = DriverManager.getConnection(url);
        }
        return connection;
    }

    @Override
    public CompletableFuture<Void> init() {
        return runAsync(() -> {
            try (Statement st = connection().createStatement()) {
                st.executeUpdate(CREATE_SQL);
                // Migrate: add capital_punishments column if missing (safe for existing DBs).
                try {
                    st.executeUpdate(MIGRATE_ADD_CAPITAL_SQL);
                } catch (SQLException ignored) {
                    // Column already exists — expected on non-first-run databases.
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite init failed: " + e.getMessage());
            }
        });
    }

    @Override
    public CompletableFuture<@Nullable PlayerData> load(UUID uuid) {
        return supplyAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(LOAD_SQL)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return readPlayer(rs);
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite load failed for " + uuid + ": " + e.getMessage());
            }
            return null;
        });
    }

    @Override
    public CompletableFuture<Void> save(PlayerData data) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(INSERT_SQL)) {
                bindPlayerUpsert(ps, data);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite save failed for " + data.getUuid() + ": " + e.getMessage());
            }
        });
    }

    @Override
    public CompletableFuture<Void> delete(UUID uuid) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(DELETE_SQL)) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite delete failed for " + uuid + ": " + e.getMessage());
            }
        });
    }

    @Override
    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing SQLite: " + e.getMessage());
        }
        executor.shutdown();
    }

    private void bindPlayerUpsert(PreparedStatement ps, PlayerData data) throws SQLException {
        ps.setString(1, data.getUuid().toString());
        ps.setString(2, data.getFaction() == null ? "" : data.getFaction().name());
        ps.setInt(3, data.getLevel());
        ps.setInt(4, data.getXp());
        ps.setInt(5, data.getMana());
        ps.setInt(6, data.getMaxMana());
        ps.setString(7, String.join(",", data.getUnlockedSpells()));
        ps.setLong(8, data.getLastLogin());
        ps.setInt(9, data.getCapitalPunishmentCount());
        PlayerStatistics s = data.getStatistics();
        ps.setInt(10, s.getSpellsCast());
        ps.setInt(11, s.getMobsKilled());
        ps.setInt(12, s.getXpGained());
        ps.setInt(13, s.getDeaths());
        ps.setLong(14, s.getPlaytimeMillis());
    }
}
