package com.magiccraft.data.database;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.data.model.PlayerStatistics;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * SQLite-backed {@link Database}. Uses the bundled sqlite-jdbc driver.
 * The database file lives in the plugin data folder.
 */
public class SQLiteDatabase extends AbstractJdbcDatabase {

    private final MagicPlugin plugin;
    private final String fileName;
    private Connection connection;

    public SQLiteDatabase(MagicPlugin plugin, String fileName) {
        this.plugin = plugin;
        this.fileName = fileName;
    }

    @Override
    protected synchronized Connection connection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            File dbFile = new File(plugin.getDataFolder(), fileName);
            String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
            connection = DriverManager.getConnection(url);
        }
        return connection;
    }

    @Override
    public CompletableFuture<Void> init() {
        return runAsync(() -> {
            try (Statement st = connection().createStatement()) {
                st.executeUpdate(CREATE_SQL);
                safeMigrate(st, MIGRATE_ADD_CAPITAL_SQL);
                safeMigrate(st, MIGRATE_ADD_PRESTIGE_SQL);
                safeMigrate(st, MIGRATE_ADD_PRESTIGE_POINTS_SQL);
                safeMigrate(st, MIGRATE_ADD_SKILL_POINTS_SQL);
                safeMigrate(st, MIGRATE_ADD_TALENTS_SQL);
                safeMigrate(st, MIGRATE_ADD_ACHIEVEMENTS_SQL);
                safeMigrate(st, MIGRATE_ADD_TITLE_SQL);
                safeMigrate(st, MIGRATE_ADD_AFFINITY_SQL);
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite init failed: " + e.getMessage());
            }
        });
    }

    private void safeMigrate(Statement st, String sql) {
        try { st.executeUpdate(sql); } catch (SQLException ignored) { }
    }

    @Override
    public CompletableFuture<@Nullable PlayerData> load(UUID uuid) {
        return supplyAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(LOAD_SQL)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return readPlayer(rs);
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite load failed for " + uuid + ": " + e.getMessage());
            }
            return null;
        });
    }

    @Override
    public CompletableFuture<Void> save(PlayerData data) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(INSERT_SQL)) {
                bindPlayerUpsert(ps, data);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite save failed for " + data.getUuid() + ": " + e.getMessage());
            }
        });
    }

    @Override
    public CompletableFuture<Void> delete(UUID uuid) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(DELETE_SQL)) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("SQLite delete failed for " + uuid + ": " + e.getMessage());
            }
        });
    }

    @Override
    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing SQLite: " + e.getMessage());
        }
        executor.shutdown();
    }

    private void bindPlayerUpsert(PreparedStatement ps, PlayerData data) throws SQLException {
        ps.setString(1, data.getUuid().toString());
        ps.setString(2, data.getFaction() == null ? "" : data.getFaction().name());
        ps.setInt(3, data.getLevel());
        ps.setInt(4, data.getXp());
        ps.setInt(5, data.getMana());
        ps.setInt(6, data.getMaxMana());
        ps.setString(7, String.join(",", data.getUnlockedSpells()));
        ps.setLong(8, data.getLastLogin());
        ps.setInt(9, data.getCapitalPunishmentCount());
        ps.setInt(10, data.getPrestigeLevel());
        ps.setInt(11, data.getPrestigePoints());
        ps.setInt(12, data.getSkillPoints());
        ps.setString(13, String.join(",", data.getLearnedTalents()));
        ps.setString(14, String.join(",", data.getEarnedAchievements()));
        ps.setString(15, data.getActiveTitle());
        ps.setString(16, affinityToString(data));
        PlayerStatistics s = data.getStatistics();
        ps.setInt(17, s.getSpellsCast());
        ps.setInt(18, s.getMobsKilled());
        ps.setInt(19, s.getXpGained());
        ps.setInt(20, s.getDeaths());
        ps.setLong(21, s.getPlaytimeMillis());
    }

    private static String affinityToString(PlayerData data) {
        StringBuilder sb = new StringBuilder();
        for (var entry : data.getAffinity().all().entrySet()) {
            if (entry.getValue() > 0) {
                if (sb.length() > 0) sb.append(",");
                sb.append(entry.getKey().name()).append(":").append(entry.getValue());
            }
        }
        return sb.toString();
    }
}
