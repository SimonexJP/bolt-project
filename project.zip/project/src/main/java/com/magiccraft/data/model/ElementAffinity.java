package com.magiccraft.data.model;

import com.magiccraft.core.enums.FactionType;

import java.util.EnumMap;
import java.util.Map;

/**
 * Tracks a player's affinity with each element. Affinity increases by
 * casting spells of that element and unlocks configurable bonuses and
 * cosmetic effects at defined thresholds.
 *
 * <p>Not thread-safe; access is mediated by PlayerManager on the main thread.
 */
public class ElementAffinity {

    public static final int MAX_AFFINITY = 1000;

    private final Map<FactionType, Integer> values = new EnumMap<>(FactionType.class);

    public ElementAffinity() {
        for (FactionType type : FactionType.values()) {
            values.put(type, 0);
        }
    }

    public int get(FactionType type) {
        return values.getOrDefault(type, 0);
    }

    public void set(FactionType type, int amount) {
        values.put(type, Math.max(0, Math.min(MAX_AFFINITY, amount)));
    }

    public void add(FactionType type, int amount) {
        set(type, get(type) + amount);
    }

    /** Bonus percentage (0.0 to 1.0) granted by current affinity for the element. */
    public double bonusPercent(FactionType type) {
        return (get(type) / (double) MAX_AFFINITY) * maxBonusPercent();
    }

    /** Configurable maximum bonus percentage. Overridden by AffinityManager at runtime. */
    public double maxBonusPercent() { return 0.20; }

    public Map<FactionType, Integer> all() {
        return new EnumMap<>(values);
    }

    public void fromMap(Map<FactionType, Integer> map) {
        for (var entry : map.entrySet()) {
            set(entry.getKey(), entry.getValue());
        }
    }
}
