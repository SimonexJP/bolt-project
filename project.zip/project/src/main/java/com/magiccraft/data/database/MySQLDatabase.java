package com.magiccraft.data.database;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.data.model.PlayerStatistics;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * MySQL-backed {@link Database}. Uses a simple pooled connection.
 * Schema uses ON DUPLICATE KEY UPDATE for upserts.
 */
public class MySQLDatabase extends AbstractJdbcDatabase {

    private final MagicPlugin plugin;
    private final String host;
    private final int port;
    private final String databaseName;
    private final String username;
    private final String password;
    private final String params;
    private Connection connection;

    private static final String MYSQL_INSERT = """
            INSERT INTO magic_players
                (uuid, faction, level, xp, mana, max_mana, unlocked_spells, last_login,
                 capital_punishments, stat_spells_cast, stat_mobs_killed, stat_xp_gained, stat_deaths, stat_playtime)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
                faction=VALUES(faction), level=VALUES(level), xp=VALUES(xp),
                mana=VALUES(mana), max_mana=VALUES(max_mana),
                unlocked_spells=VALUES(unlocked_spells), last_login=VALUES(last_login),
                capital_punishments=VALUES(capital_punishments),
                stat_spells_cast=VALUES(stat_spells_cast), stat_mobs_killed=VALUES(stat_mobs_killed),
                stat_xp_gained=VALUES(stat_xp_gained), stat_deaths=VALUES(stat_deaths),
                stat_playtime=VALUES(stat_playtime)
            """;

    public MySQLDatabase(MagicPlugin plugin, String host, int port, String databaseName,
                         String username, String password, String params) {
        this.plugin = plugin;
        this.host = host;
        this.port = port;
        this.databaseName = databaseName;
        this.username = username;
        this.password = password;
        this.params = params;
    }

    @Override
    protected synchronized Connection connection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            String url = "jdbc:mysql://" + host + ":" + port + "/" + databaseName + "?" + params;
            connection = DriverManager.getConnection(url, username, password);
        }
        return connection;
    }

    @Override
    public CompletableFuture<Void> init() {
        return runAsync(() -> {
            try (Statement st = connection().createStatement()) {
                st.executeUpdate(CREATE_SQL);
                try {
                    st.executeUpdate(MIGRATE_ADD_CAPITAL_SQL);
                } catch (SQLException ignored) {
                    // Column already exists.
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("MySQL init failed: " + e.getMessage());
            }
        });
    }

    @Override
    public CompletableFuture<@Nullable PlayerData> load(UUID uuid) {
        return supplyAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(LOAD_SQL)) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) return readPlayer(rs);
                }
            } catch (SQLException e) {
                plugin.getLogger().severe("MySQL load failed for " + uuid + ": " + e.getMessage());
            }
            return null;
        });
    }

    @Override
    public CompletableFuture<Void> save(PlayerData data) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(MYSQL_INSERT)) {
                bindUpsert(ps, data);
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("MySQL save failed for " + data.getUuid() + ": " + e.getMessage());
            }
        });
    }

    @Override
    public CompletableFuture<Void> delete(UUID uuid) {
        return runAsync(() -> {
            try (PreparedStatement ps = connection().prepareStatement(DELETE_SQL)) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().severe("MySQL delete failed for " + uuid + ": " + e.getMessage());
            }
        });
    }

    @Override
    public synchronized void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            plugin.getLogger().warning("Error closing MySQL: " + e.getMessage());
        }
        executor.shutdown();
    }

    private void bindUpsert(PreparedStatement ps, PlayerData data) throws SQLException {
        ps.setString(1, data.getUuid().toString());
        ps.setString(2, data.getFaction() == null ? "" : data.getFaction().name());
        ps.setInt(3, data.getLevel());
        ps.setInt(4, data.getXp());
        ps.setInt(5, data.getMana());
        ps.setInt(6, data.getMaxMana());
        ps.setString(7, String.join(",", data.getUnlockedSpells()));
        ps.setLong(8, data.getLastLogin());
        ps.setInt(9, data.getCapitalPunishmentCount());
        PlayerStatistics s = data.getStatistics();
        ps.setInt(10, s.getSpellsCast());
        ps.setInt(11, s.getMobsKilled());
        ps.setInt(12, s.getXpGained());
        ps.setInt(13, s.getDeaths());
        ps.setLong(14, s.getPlaytimeMillis());
    }
}
