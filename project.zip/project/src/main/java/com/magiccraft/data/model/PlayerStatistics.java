package com.magiccraft.data.model;

/**
 * Tracks a wizard's lifetime statistics. All fields are persisted.
 */
public class PlayerStatistics {

    private int spellsCast;
    private int mobsKilled;
    private int xpGained;
    private int deaths;
    private long playtimeMillis;

    public int getSpellsCast() { return spellsCast; }
    public void setSpellsCast(int spellsCast) { this.spellsCast = spellsCast; }
    public void addSpellCast() { this.spellsCast++; }

    public int getMobsKilled() { return mobsKilled; }
    public void setMobsKilled(int mobsKilled) { this.mobsKilled = mobsKilled; }
    public void addMobKill() { this.mobsKilled++; }

    public int getXpGained() { return xpGained; }
    public void setXpGained(int xpGained) { this.xpGained = xpGained; }
    public void addXp(int amount) { this.xpGained += amount; }

    public int getDeaths() { return deaths; }
    public void setDeaths(int deaths) { this.deaths = deaths; }
    public void addDeath() { this.deaths++; }

    public long getPlaytimeMillis() { return playtimeMillis; }
    public void setPlaytimeMillis(long playtimeMillis) { this.playtimeMillis = playtimeMillis; }
    public void addPlaytime(long millis) { this.playtimeMillis += millis; }
}
