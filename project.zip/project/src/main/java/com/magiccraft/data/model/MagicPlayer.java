package com.magiccraft.data.model;

import com.magiccraft.core.enums.Rank;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Convenience wrapper linking a Bukkit {@link Player} to their {@link PlayerData}.
 * Obtained from {@code PlayerManager}.
 */
public class MagicPlayer {

    private final Player player;
    private final PlayerData data;

    public MagicPlayer(Player player, PlayerData data) {
        this.player = player;
        this.data = data;
    }

    public Player getPlayer() { return player; }
    public PlayerData getData() { return data; }

    public UUID getUuid() { return data.getUuid(); }
    public int getLevel() { return data.getLevel(); }
    public int getXp() { return data.getXp(); }
    public int getMana() { return data.getMana(); }
    public int getMaxMana() { return data.getMaxMana(); }

    public Rank getRank() { return Rank.fromLevel(data.getLevel()); }

    public boolean hasFaction() { return data.getFaction() != null; }
}
