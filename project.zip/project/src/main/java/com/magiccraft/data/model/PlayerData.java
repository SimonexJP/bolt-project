package com.magiccraft.data.model;

import com.magiccraft.core.enums.FactionType;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Plain data holder for a player's persisted magic state.
 * <p>Not thread-safe; access is mediated by {@code PlayerManager} on the
 * main thread and by {@code DatabaseManager} on async workers.
 */
public class PlayerData {

    private final UUID uuid;
    private FactionType faction;
    private int level;
    private int xp;
    private int mana;
    private int maxMana;
    private final Set<String> unlockedSpells = new HashSet<>();
    private final PlayerStatistics statistics = new PlayerStatistics();
    private final ElementAffinity affinity = new ElementAffinity();
    private long lastLogin;
    private int capitalPunishmentCount;
    private int prestigeLevel;
    private int prestigePoints;
    private int skillPoints;
    private final Set<String> learnedTalents = ConcurrentHashMap.newKeySet();
    private final Set<String> earnedAchievements = ConcurrentHashMap.newKeySet();
    private final Set<String> activePassives = ConcurrentHashMap.newKeySet();
    private String activeTitle;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.level = 1;
        this.xp = 0;
        this.mana = 100;
        this.maxMana = 100;
        this.lastLogin = System.currentTimeMillis();
        this.capitalPunishmentCount = 0;
    }

    public UUID getUuid() { return uuid; }
    public FactionType getFaction() { return faction; }
    public void setFaction(FactionType faction) { this.faction = faction; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = xp; }
    public int getMana() { return mana; }
    public void setMana(int mana) { this.mana = mana; }
    public int getMaxMana() { return maxMana; }
    public void setMaxMana(int maxMana) { this.maxMana = maxMana; }
    public long getLastLogin() { return lastLogin; }
    public void setLastLogin(long lastLogin) { this.lastLogin = lastLogin; }

    public int getCapitalPunishmentCount() { return capitalPunishmentCount; }
    public void setCapitalPunishmentCount(int count) { this.capitalPunishmentCount = count; }
    public void incrementCapitalPunishment() { this.capitalPunishmentCount++; }

    public Set<String> getUnlockedSpells() {
        return Collections.unmodifiableSet(unlockedSpells);
    }

    public boolean unlockSpell(String id) {
        return unlockedSpells.add(id.toLowerCase());
    }

    public boolean hasSpell(String id) {
        return unlockedSpells.contains(id.toLowerCase());
    }

    public boolean lockSpell(String id) {
        return unlockedSpells.remove(id.toLowerCase());
    }

    public PlayerStatistics getStatistics() { return statistics; }

    public ElementAffinity getAffinity() { return affinity; }

    public int getPrestigeLevel() { return prestigeLevel; }
    public void setPrestigeLevel(int prestigeLevel) { this.prestigeLevel = prestigeLevel; }

    public int getPrestigePoints() { return prestigePoints; }
    public void setPrestigePoints(int prestigePoints) { this.prestigePoints = prestigePoints; }
    public void addPrestigePoints(int amount) { this.prestigePoints += amount; }

    public int getSkillPoints() { return skillPoints; }
    public void setSkillPoints(int skillPoints) { this.skillPoints = skillPoints; }
    public void addSkillPoints(int amount) { this.skillPoints += amount; }
    public boolean spendSkillPoints(int amount) {
        if (skillPoints < amount) return false;
        skillPoints -= amount;
        return true;
    }

    public Set<String> getLearnedTalents() { return Collections.unmodifiableSet(learnedTalents); }
    public boolean learnTalent(String id) { return learnedTalents.add(id.toLowerCase()); }
    public boolean hasTalent(String id) { return learnedTalents.contains(id.toLowerCase()); }
    public void clearTalents() { learnedTalents.clear(); }

    public Set<String> getEarnedAchievements() { return Collections.unmodifiableSet(earnedAchievements); }
    public boolean earnAchievement(String id) { return earnedAchievements.add(id.toLowerCase()); }
    public boolean hasAchievement(String id) { return earnedAchievements.contains(id.toLowerCase()); }

    public String getActiveTitle() { return activeTitle; }
    public void setActiveTitle(String activeTitle) { this.activeTitle = activeTitle; }

    public boolean isPassiveActive(String spellId) { return activePassives.contains(spellId.toLowerCase()); }
    public void setPassiveActive(String spellId, boolean active) {
        if (active) activePassives.add(spellId.toLowerCase());
        else activePassives.remove(spellId.toLowerCase());
    }
    public Set<String> getActivePassives() { return Collections.unmodifiableSet(activePassives); }
}
