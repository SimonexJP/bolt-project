package com.magiccraft.data.model;

import com.magiccraft.core.enums.FactionType;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Plain data holder for a player's persisted magic state.
 * <p>Not thread-safe; access is mediated by {@code PlayerManager} on the
 * main thread and by {@code DatabaseManager} on async workers.
 */
public class PlayerData {

    private final UUID uuid;
    private FactionType faction;
    private int level;
    private int xp;
    private int mana;
    private int maxMana;
    private final Set<String> unlockedSpells = new HashSet<>();
    private final PlayerStatistics statistics = new PlayerStatistics();
    private long lastLogin;
    private int capitalPunishmentCount;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        this.level = 1;
        this.xp = 0;
        this.mana = 100;
        this.maxMana = 100;
        this.lastLogin = System.currentTimeMillis();
        this.capitalPunishmentCount = 0;
    }

    public UUID getUuid() { return uuid; }
    public FactionType getFaction() { return faction; }
    public void setFaction(FactionType faction) { this.faction = faction; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
    public int getXp() { return xp; }
    public void setXp(int xp) { this.xp = xp; }
    public int getMana() { return mana; }
    public void setMana(int mana) { this.mana = mana; }
    public int getMaxMana() { return maxMana; }
    public void setMaxMana(int maxMana) { this.maxMana = maxMana; }
    public long getLastLogin() { return lastLogin; }
    public void setLastLogin(long lastLogin) { this.lastLogin = lastLogin; }

    public int getCapitalPunishmentCount() { return capitalPunishmentCount; }
    public void setCapitalPunishmentCount(int count) { this.capitalPunishmentCount = count; }
    public void incrementCapitalPunishment() { this.capitalPunishmentCount++; }

    public Set<String> getUnlockedSpells() {
        return Collections.unmodifiableSet(unlockedSpells);
    }

    public boolean unlockSpell(String id) {
        return unlockedSpells.add(id.toLowerCase());
    }

    public boolean hasSpell(String id) {
        return unlockedSpells.contains(id.toLowerCase());
    }

    public PlayerStatistics getStatistics() { return statistics; }
}
