package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** Main menu GUI: entry point to all other GUIs. */
public class MainGui extends AbstractGui {

    public MainGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.MAIN; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-main-title");
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.GRAY_STAINED_GLASS_PANE);
        inv.setItem(11, icon(Material.BOOK, "&dProfile", List.of("&7View your wizard details.")));
        inv.setItem(13, icon(Material.NETHER_STAR, "&dFaction", List.of("&7Choose or view your faction.")));
        inv.setItem(15, icon(Material.ENCHANTED_BOOK, "&dSpells", List.of("&7Browse your unlocked spells.")));
        inv.setItem(22, icon(Material.EMERALD, "&dStatistics", List.of("&7See your lifetime stats.")));
        inv.setItem(26, icon(Material.BARRIER, plugin.getMessages().raw("gui-close")));
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        int slot = event.getRawSlot();
        switch (slot) {
            case 11 -> plugin.getGuiManager().open(player, GuiManager.PROFILE);
            case 13 -> plugin.getGuiManager().open(player, GuiManager.FACTION);
            case 15 -> plugin.getGuiManager().open(player, GuiManager.SPELLS);
            case 22 -> plugin.getGuiManager().open(player, GuiManager.STATISTICS);
            case 26 -> player.closeInventory();
        }
    }
}
