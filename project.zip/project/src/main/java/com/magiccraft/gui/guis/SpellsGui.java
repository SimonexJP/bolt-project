package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerData;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/** Spell list GUI: shows unlocked spells for the player's faction. */
public class SpellsGui extends AbstractGui {

    public SpellsGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.SPELLS; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-spells-title", player.getName());
    }

    @Override
    public int size() { return 54; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null || !mp.hasFaction()) {
            inv.setItem(22, icon(Material.BARRIER, "&cChoose a faction first."));
            backItem(inv, 49);
            return;
        }
        PlayerData data = mp.getData();
        FactionType faction = data.getFaction();
        List<String> allSpells = plugin.getFactionManager().unlockedSpellsUpTo(faction, 100);
        int slot = 10;
        for (String spellId : allSpells) {
            if (slot >= 44) break;
            boolean unlocked = data.hasSpell(spellId);
            String name = plugin.getSpellManager().displayName(spellId);
            Material mat = plugin.getSpellManager().icon(spellId);
            List<String> lore = new ArrayList<>();
            lore.add(plugin.getSpellManager().description(spellId));
            lore.add("");
            lore.add("&7Mana: &b" + plugin.getSpellManager().manaCost(spellId));
            lore.add("&7Cooldown: &b" + plugin.getSpellManager().cooldownSeconds(spellId) + "s");
            if (unlocked) {
                lore.add("&aUnlocked");
            } else {
                int unlockLvl = plugin.getSpellManager().unlockLevel(spellId, faction);
                lore.add("&cLocked &7(requires level &e" + unlockLvl + "&7)");
                mat = Material.GRAY_DYE;
            }
            inv.setItem(slot, icon(mat, (unlocked ? "" : "&8") + name, lore));
            slot = nextSlot(slot);
        }
        backItem(inv, 49);
    }

    private int nextSlot(int slot) {
        int col = slot % 9;
        int row = slot / 9;
        col++;
        if (col > 7) { col = 1; row++; }
        return row * 9 + col;
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        if (event.getRawSlot() == 49) {
            plugin.getGuiManager().open(player, GuiManager.MAIN);
        }
    }
}
