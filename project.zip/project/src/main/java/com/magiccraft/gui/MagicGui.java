package com.magiccraft.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.jetbrains.annotations.NotNull;

/**
 * Contract for an inventory GUI. Each GUI owns its own inventory and
 * click-handling logic.
 */
public interface MagicGui {

    /** Title of the inventory (already colorized), with player context for placeholders. */
    @NotNull String title(@NotNull Player player);

    /** Size in slots (multiple of 9). */
    int size();

    /** Handle a click event. */
    void onClick(@NotNull InventoryClickEvent event, @NotNull Player player);

    /** Optional identifier for the GUI manager to route clicks. */
    @NotNull String id();
}
