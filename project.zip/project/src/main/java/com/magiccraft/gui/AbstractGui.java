package com.magiccraft.gui;

import com.magiccraft.MagicPlugin;
import com.magiccraft.util.TextUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Base GUI with item-builder helpers and a render-into-inventory contract.
 * Subclasses implement {@link #renderInto(Player, Inventory)} and
 * {@link #onClick(InventoryClickEvent, Player)}.
 */
public abstract class AbstractGui implements MagicGui {

    protected final MagicPlugin plugin;

    protected AbstractGui(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public abstract void renderInto(@NotNull Player player, @NotNull Inventory inv);

    /** Builds a colored, lore-bearing icon. */
    protected ItemStack icon(@NotNull Material material, @NotNull String name, @Nullable List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(TextUtil.color(name));
            if (lore != null && !lore.isEmpty()) {
                List<String> colored = new ArrayList<>(lore.size());
                for (String line : lore) colored.add(TextUtil.color(line));
                meta.setLore(colored);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    protected ItemStack icon(@NotNull Material material, @NotNull String name) {
        return icon(material, name, null);
    }

    protected void fillBorder(@NotNull Inventory inv, @NotNull Material filler) {
        int size = inv.getSize();
        ItemStack fill = icon(filler, " ");
        for (int i = 0; i < size; i++) {
            int row = i / 9;
            int col = i % 9;
            if (row == 0 || row == (size / 9) - 1 || col == 0 || col == 8) {
                inv.setItem(i, fill);
            }
        }
    }

    protected void backItem(@NotNull Inventory inv, int slot) {
        inv.setItem(slot, icon(Material.ARROW, plugin.getMessages().raw("gui-back")));
    }

    protected void closeItem(@NotNull Inventory inv, int slot) {
        inv.setItem(slot, icon(Material.BARRIER, plugin.getMessages().raw("gui-close")));
    }
}
