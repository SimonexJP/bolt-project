package com.magiccraft.gui;

import com.magiccraft.MagicPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Registry + router for GUIs. Opens a GUI by id and routes clicks to it.
 * GUIs are created fresh on each open so per-player state is clean.
 */
public class GuiManager implements Listener {

    public static final String MAIN = "main";
    public static final String PROFILE = "profile";
    public static final String SPELLS = "spells";
    public static final String FACTION = "faction";
    public static final String ADMIN = "admin";
    public static final String PROGRESSION = "progression";
    public static final String STATISTICS = "statistics";

    private final MagicPlugin plugin;
    private final Map<String, Function<MagicPlugin, MagicGui>> factories = new HashMap<>();

    public GuiManager(MagicPlugin plugin) {
        this.plugin = plugin;
    }

    public void register(String id, Function<MagicPlugin, MagicGui> factory) {
        factories.put(id.toLowerCase(), factory);
    }

    public void open(@NotNull Player player, @NotNull String id) {
        try {
            Function<MagicPlugin, MagicGui> factory = factories.get(id.toLowerCase());
            if (factory == null) return;
            MagicGui gui = factory.apply(plugin);
            MagicGuiHolder holder = new MagicGuiHolder(gui, player);
            Inventory inv = Bukkit.createInventory(holder, gui.size(), gui.title(player));
            holder.bind(inv);
            if (gui instanceof AbstractGui ag) {
                ag.renderInto(player, inv);
            }
            player.openInventory(inv);
        } catch (Exception e) {
            plugin.getLogger().severe("Error opening GUI '" + id + "': " + e.getMessage());
            e.printStackTrace();
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        Inventory inv = event.getInventory();
        if (!(inv.getHolder() instanceof MagicGuiHolder holder)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        event.setCancelled(true);
        try {
            holder.gui().onClick(event, player);
        } catch (Exception e) {
            plugin.getLogger().severe("Error handling GUI click: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
