package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/** Progression GUI: shows the level path and rank tiers. */
public class ProgressionGui extends AbstractGui {

    public ProgressionGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.PROGRESSION; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-progression-title", player.getName());
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.GREEN_STAINED_GLASS_PANE);
        var mp = plugin.getPlayerManager().getOrNull(player);
        int currentLevel = mp != null ? mp.getLevel() : 1;
        int currentXp = mp != null ? mp.getXp() : 0;
        int needed = plugin.getLevelManager().xpForLevel(currentLevel);

        inv.setItem(11, icon(Material.EXPERIENCE_BOTTLE, "&dCurrent Level &f" + currentLevel,
                List.of("&7XP: &f" + currentXp + "/" + needed,
                        "&7Rank: &f" + Rank.fromLevel(currentLevel).getDisplayName())));

        int slot = 13;
        for (Rank rank : Rank.values()) {
            boolean reached = currentLevel >= rank.getMinLevel();
            Material mat = reached ? Material.EMERALD : Material.COAL;
            List<String> lore = new ArrayList<>();
            lore.add("&7Levels &f" + rank.getMinLevel() + " - " + rank.getMaxLevel());
            lore.add(reached ? "&aAchieved" : "&cNot yet achieved");
            inv.setItem(slot, icon(mat, (reached ? "&a" : "&7") + rank.getDisplayName(), lore));
            slot++;
        }
        backItem(inv, 22);
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        if (event.getRawSlot() == 22) plugin.getGuiManager().open(player, GuiManager.PROFILE);
    }
}
