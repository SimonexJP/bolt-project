package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.data.model.MagicPlayer;
import com.magiccraft.data.model.PlayerStatistics;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** Statistics GUI: lifetime counts. */
public class StatisticsGui extends AbstractGui {

    public StatisticsGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.STATISTICS; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-statistics-title", player.getName());
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.BLUE_STAINED_GLASS_PANE);
        var mp = plugin.getPlayerManager().getOrNull(player);
        PlayerStatistics stats = mp != null ? mp.getData().getStatistics() : null;
        int spells = stats != null ? stats.getSpellsCast() : 0;
        int mobs = stats != null ? stats.getMobsKilled() : 0;
        int xp = stats != null ? stats.getXpGained() : 0;
        int deaths = stats != null ? stats.getDeaths() : 0;
        long playtime = stats != null ? stats.getPlaytimeMillis() : 0;

        inv.setItem(10, icon(Material.BLAZE_POWDER, "&dSpells Cast", List.of("&f" + spells)));
        inv.setItem(12, icon(Material.ZOMBIE_HEAD, "&dMobs Killed", List.of("&f" + mobs)));
        inv.setItem(14, icon(Material.EXPERIENCE_BOTTLE, "&dTotal XP Gained", List.of("&f" + xp)));
        inv.setItem(16, icon(Material.SKELETON_SKULL, "&dDeaths", List.of("&f" + deaths)));
        inv.setItem(22, icon(Material.CLOCK, "&dPlaytime", List.of("&f" + (playtime / 60000) + " min")));
        backItem(inv, 18);
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        if (event.getRawSlot() == 18) plugin.getGuiManager().open(player, GuiManager.MAIN);
    }
}
