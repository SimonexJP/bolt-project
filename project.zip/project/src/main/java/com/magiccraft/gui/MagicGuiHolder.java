package com.magiccraft.gui;

import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * {@link InventoryHolder} that tags an inventory as belonging to a MagicPlugin GUI,
 * so click events can be routed back to the right handler.
 */
public class MagicGuiHolder implements InventoryHolder {

    private final MagicGui gui;
    private final Player player;
    private Inventory inventory;

    public MagicGuiHolder(MagicGui gui, Player player) {
        this.gui = gui;
        this.player = player;
    }

    public MagicGui gui() { return gui; }
    public Player player() { return player; }

    void bind(Inventory inventory) { this.inventory = inventory; }

    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
