package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.Rank;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** Profile GUI: shows level, XP, faction, mana, rank, and progression entry. */
public class ProfileGui extends AbstractGui {

    public ProfileGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.PROFILE; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-profile-title", player.getName());
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.PURPLE_STAINED_GLASS_PANE);
        var mp = plugin.getPlayerManager().getOrNull(player);
        if (mp == null) {
            inv.setItem(13, icon(Material.BARRIER, "&cNo data loaded."));
            backItem(inv, 22);
            return;
        }
        String faction = mp.hasFaction() ? mp.getData().getFaction().name() : "None";
        Rank rank = mp.getRank();
        int xpNeeded = plugin.getLevelManager().xpForLevel(mp.getLevel());
        inv.setItem(11, icon(Material.EXPERIENCE_BOTTLE, "&dLevel &f" + mp.getLevel(),
                List.of("&7Rank: &f" + rank.getDisplayName(), "&7XP: &f" + mp.getXp() + "/" + xpNeeded)));
        inv.setItem(13, icon(Material.BLAZE_POWDER, "&dFaction", List.of("&7" + faction)));
        inv.setItem(15, icon(Material.LAPIS_LAZULI, "&dMana",
                List.of("&7" + mp.getMana() + "/" + mp.getMaxMana())));
        inv.setItem(20, icon(Material.LADDER, "&dProgression", List.of("&7View your level path.")));
        inv.setItem(24, icon(Material.EMERALD, "&dStatistics", List.of("&7See your stats.")));
        backItem(inv, 22);
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        int slot = event.getRawSlot();
        switch (slot) {
            case 20 -> plugin.getGuiManager().open(player, GuiManager.PROGRESSION);
            case 24 -> plugin.getGuiManager().open(player, GuiManager.STATISTICS);
            case 22 -> plugin.getGuiManager().open(player, GuiManager.MAIN);
        }
    }
}
