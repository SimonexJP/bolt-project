package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** Admin panel GUI: quick links to admin actions (handled mostly via commands). */
public class AdminGui extends AbstractGui {

    public AdminGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.ADMIN; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-admin-title");
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.RED_STAINED_GLASS_PANE);
        inv.setItem(11, icon(Material.PAPER, "&cReload Configs", List.of("&7/magicadmin reload")));
        inv.setItem(13, icon(Material.STICK, "&cGive Wand", List.of("&7/magicadmin givewand <player>")));
        inv.setItem(15, icon(Material.EXPERIENCE_BOTTLE, "&cManage Player", List.of(
                "&7/magicadmin setlevel <player> <level>",
                "&7/magicadmin addxp <player> <amount>",
                "&7/magicadmin resetplayer <player>",
                "&7/magicadmin setfaction <player> <faction>")));
        closeItem(inv, 22);
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        if (event.getRawSlot() == 22) player.closeInventory();
    }
}
