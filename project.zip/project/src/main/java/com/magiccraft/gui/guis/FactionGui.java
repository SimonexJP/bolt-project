package com.magiccraft.gui.guis;

import com.magiccraft.MagicPlugin;
import com.magiccraft.core.enums.FactionType;
import com.magiccraft.factions.Faction;
import com.magiccraft.gui.AbstractGui;
import com.magiccraft.gui.GuiManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/** Faction selection GUI. Locked once chosen (admin can force-change). */
public class FactionGui extends AbstractGui {

    public FactionGui(MagicPlugin plugin) { super(plugin); }

    @Override
    public @NotNull String id() { return GuiManager.FACTION; }

    @Override
    public @NotNull String title(@NotNull Player player) {
        return plugin.getMessages().raw("gui-faction-title");
    }

    @Override
    public int size() { return 27; }

    @Override
    public void renderInto(@NotNull Player player, @NotNull Inventory inv) {
        fillBorder(inv, Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        int[] slots = {11, 12, 13, 14, 15};
        FactionType[] types = FactionType.values();
        for (int i = 0; i < types.length && i < slots.length; i++) {
            Faction f = plugin.getFactionManager().get(types[i]).orElse(null);
            if (f == null) continue;
            Material mat = safeMaterial(f.getWandMaterial());
            inv.setItem(slots[i], icon(mat, f.getDisplayName(),
                    List.of(f.getDescription(), "", "&7Click to join this faction.")));
        }
        backItem(inv, 22);
    }

    @Override
    public void onClick(@NotNull InventoryClickEvent event, @NotNull Player player) {
        int slot = event.getRawSlot();
        int[] slots = {11, 12, 13, 14, 15};
        FactionType[] types = FactionType.values();
        for (int i = 0; i < slots.length; i++) {
            if (slot == slots[i] && i < types.length) {
                plugin.getFactionService().joinFaction(player, types[i]);
                player.closeInventory();
                return;
            }
        }
        if (slot == 22) plugin.getGuiManager().open(player, GuiManager.MAIN);
    }

    private Material safeMaterial(String name) {
        try { return Material.valueOf(name.toUpperCase()); }
        catch (IllegalArgumentException e) { return Material.STICK; }
    }
}
