plugins {
    id("java")
}

// Dummy for IDE; real config lives in root build.gradle.kts
