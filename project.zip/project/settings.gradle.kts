rootProject.name = "MagicPlugin"
